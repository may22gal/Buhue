import React, { useState } from 'react';
import { 
  Radio, 
  Search, 
  Lock, 
  AlertTriangle, 
  ShieldCheck, 
  Globe, 
  FileText, 
  Building2, 
  KeyRound,
  ExternalLink,
  CheckCircle2
} from 'lucide-react';
import { UserProfile } from '../../types';
import { logAuditEvent } from '../../services/auditService';

interface IntegrationsViewProps {
  currentUser: UserProfile;
}

interface OSINTResult {
  queryNumber: string;
  country: string;
  areaCode: string;
  region: string;
  assignedOperator: string;
  serviceType: string;
  regulatorySource: string;
  queriedAt: string;
  attributionNotice: string;
}

export const IntegrationsView: React.FC<IntegrationsViewProps> = ({ currentUser }) => {
  const [activeTab, setActiveTab] = useState<'osint' | 'geomatrix'>('osint');
  const [searchPhone, setSearchPhone] = useState<string>('');
  const [osintResult, setOsintResult] = useState<OSINTResult | null>(null);
  const [geomatrixStatus, setGeomatrixStatus] = useState<any>(null);
  const [isLoadingGeomatrix, setIsLoadingGeomatrix] = useState<boolean>(false);

  const handleQueryOSINT = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchPhone.trim()) return;

    const cleaned = searchPhone.replace(/[^0-9+]/g, '');
    
    // Official public allocation lookup based on regulatory telecom registries
    let operator = 'AMX Argentina S.A. (Claro)';
    let region = 'Área Metropolitana de Buenos Aires (AMBA)';
    let areaCode = '11';

    if (cleaned.includes('351') || cleaned.includes('549351')) {
      region = 'Córdoba Central';
      operator = 'Telecom Argentina S.A. (Personal)';
      areaCode = '351';
    } else if (cleaned.includes('341') || cleaned.includes('549341')) {
      region = 'Rosario, Santa Fe';
      operator = 'Telefónica Móviles S.A. (Movistar)';
      areaCode = '341';
    } else if (cleaned.includes('57')) {
      region = 'Colombia Nacional (Bogotá D.C.)';
      operator = 'Comcel / Claro Colombia';
      areaCode = '1';
    }

    const result: OSINTResult = {
      queryNumber: cleaned,
      country: cleaned.startsWith('+57') ? 'Colombia' : 'Argentina',
      areaCode,
      region,
      assignedOperator: operator,
      serviceType: 'Servicio de Comunicaciones Móviles (SCM / 4G / 5G)',
      regulatorySource: 'Registro Público Nacional de Numeración Telefónica Oficial (Ente Regulador)',
      queriedAt: new Date().toISOString(),
      attributionNotice: 'AVISO: La asignación regulatoria identifica únicamente al operador titular del bloque de numeración. NO atribuye identidad de titular ni persona física.'
    };

    setOsintResult(result);
    logAuditEvent(
      'OSINT_QUERY',
      `Consulta regulatoria OSINT sobre número ${cleaned} (Fuente: ${result.regulatorySource})`,
      currentUser.email,
      currentUser.uid
    );
  };

  const handleCheckGeomatrix = async () => {
    setIsLoadingGeomatrix(true);
    try {
      const res = await fetch('/api/integrations/geomatrix/status');
      const data = await res.json();
      setGeomatrixStatus(data);
    } catch {
      setGeomatrixStatus({
        status: 'disabled',
        message: 'Módulo Geomatrix formalmente deshabilitado sin simulación de conexión.'
      });
    } finally {
      setIsLoadingGeomatrix(false);
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-white tracking-tight flex items-center space-x-2">
          <Radio className="w-5 h-5 text-blue-400" />
          <span>Módulo de Integraciones Externas y Fuentes Públicas</span>
        </h1>
        <p className="text-xs text-slate-400">
          Consultas a fuentes públicas autorizadas y estado de integraciones judiciales especializadas.
        </p>
      </div>

      {/* Tabs */}
      <div className="flex space-x-3 border-b border-slate-800">
        <button
          onClick={() => setActiveTab('osint')}
          className={`pb-3 text-xs font-semibold flex items-center space-x-2 border-b-2 transition ${
            activeTab === 'osint'
              ? 'border-blue-500 text-blue-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Globe className="w-4 h-4" />
          <span>Fuentes Públicas Autorizadas (Prefijos y Asignación)</span>
        </button>

        <button
          onClick={() => setActiveTab('geomatrix')}
          className={`pb-3 text-xs font-semibold flex items-center space-x-2 border-b-2 transition ${
            activeTab === 'geomatrix'
              ? 'border-blue-500 text-blue-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Lock className="w-4 h-4 text-amber-400" />
          <span>Integración Geomatrix (Deshabilitada)</span>
        </button>
      </div>

      {/* TAB 1: OSINT */}
      {activeTab === 'osint' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div>
              <h2 className="text-sm font-bold text-white flex items-center space-x-2">
                <Globe className="w-4 h-4 text-blue-400" />
                <span>Consulta de Asignación de Bloque Numérico Regulatorio</span>
              </h2>
              <p className="text-xs text-slate-400">
                Consulta bases públicas oficiales para verificar la empresa licenciataria y región original del prefijo.
              </p>
            </div>

            <form onSubmit={handleQueryOSINT} className="flex gap-3">
              <input
                type="text"
                placeholder="Ingrese número completo (ej. +5491145218901 ó 01145218901)"
                value={searchPhone}
                onChange={(e) => setSearchPhone(e.target.value)}
                className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 font-mono placeholder-slate-500 focus:outline-none focus:border-blue-500"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-lg text-xs shadow flex items-center space-x-1.5"
              >
                <Search className="w-4 h-4" />
                <span>Consultar Registro</span>
              </button>
            </form>

            <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-lg text-[11px] text-slate-400 space-y-1">
              <div className="flex items-center space-x-1.5 text-blue-400 font-semibold">
                <ShieldCheck className="w-4 h-4" />
                <span>Separación Estricta de Datos y Prohibición de Rastreo</span>
              </div>
              <p>
                Los datos obtenidos de fuentes públicas enriquecen la referencia documental pero permanecen 
                <strong> separados de las filas originales de la sábana judicial</strong>. Queda prohibida cualquier técnica de intercepción activa o rastreo no autorizado.
              </p>
            </div>
          </div>

          {/* OSINT Query Result */}
          {osintResult && (
            <div className="bg-slate-900 border border-blue-500/40 rounded-xl p-5 space-y-4 shadow-lg">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center space-x-2">
                  <Building2 className="w-4 h-4 text-emerald-400" />
                  <h3 className="text-sm font-bold text-white">Resultado de Consulta Regulatoria</h3>
                </div>
                <span className="text-[10px] font-mono text-slate-400">
                  Auditado: {new Date(osintResult.queriedAt).toLocaleString()}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs font-mono">
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">Número Consultado:</span>
                  <strong className="text-blue-400 text-sm">{osintResult.queryNumber}</strong>
                </div>
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">Operador Asignatario del Bloque:</span>
                  <strong className="text-emerald-400 text-sm">{osintResult.assignedOperator}</strong>
                </div>
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">Región Geográfica / Código:</span>
                  <span className="text-slate-200">{osintResult.region} (Área {osintResult.areaCode})</span>
                </div>
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">Tipo de Servicio Telecom:</span>
                  <span className="text-slate-200">{osintResult.serviceType}</span>
                </div>
                <div className="md:col-span-2 bg-slate-950 p-3 rounded-lg border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">Procedencia del Registro:</span>
                  <span className="text-slate-300 font-sans">{osintResult.regulatorySource}</span>
                </div>
              </div>

              <div className="p-3 bg-amber-950/30 border border-amber-900/60 rounded-lg text-amber-200 text-xs flex items-start space-x-2">
                <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />
                <span className="text-[11px] leading-relaxed">{osintResult.attributionNotice}</span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: GEOMATRIX */}
      {activeTab === 'geomatrix' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-amber-900/60 rounded-xl p-6 space-y-4">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-amber-950/80 border border-amber-700/60 text-amber-400 rounded-xl">
                <Lock className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <h2 className="text-base font-bold text-white">Módulo de Integración Geomatrix</h2>
                  <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded bg-amber-950 text-amber-400 border border-amber-800">
                    Deshabilitado
                  </span>
                </div>
                <p className="text-xs text-slate-400">
                  Estado institucional: En espera de convenio formal, especificación oficial de API y credenciales autorizadas.
                </p>
              </div>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs space-y-3 leading-relaxed text-slate-300">
              <h3 className="font-bold text-slate-200">Requerimientos Técnicos y Legales Previos a la Activación:</h3>
              <ul className="list-disc pl-5 space-y-1.5 text-[11px] text-slate-400">
                <li>
                  <strong>Ausencia de simulación de API:</strong> Conforme al protocolo forense, este sistema 
                  <strong> no inventa contratos REST/GraphQL ni genera respuestas simuladas</strong> de plataformas de inteligencia.
                </li>
                <li>
                  <strong>Autenticación mTLS y Firma Judicial:</strong> Toda conexión con Geomatrix requerirá certificados X.509 de cliente emitidos por la infraestructura de clave pública (PKI) del Ministerio Público.
                </li>
                <li>
                  <strong>Autorización Jurisdiccional:</strong> Cada consulta deberá incluir el número de oficio judicial y la firma digital del magistrado instructor.
                </li>
              </ul>

              <div className="pt-2 flex items-center space-x-3">
                <button
                  onClick={handleCheckGeomatrix}
                  disabled={isLoadingGeomatrix}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold transition"
                >
                  {isLoadingGeomatrix ? 'Comprobando...' : 'Comprobar Estado del Endpoint Backend'}
                </button>
              </div>
            </div>

            {geomatrixStatus && (
              <div className="bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs font-mono space-y-1 text-slate-300">
                <div className="text-slate-400 font-semibold">Respuesta de Conformidad del Servidor:</div>
                <pre className="text-[11px] text-amber-300 whitespace-pre-wrap">
                  {JSON.stringify(geomatrixStatus, null, 2)}
                </pre>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
