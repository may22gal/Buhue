import * as XLSX from 'xlsx';
import { ColumnMapping, NormalizedCDR, ImportValidationReport, CDREventType, CDRRecordStatus } from '../types';

export async function computeFileSha256(file: File): Promise<string> {
  const buffer = await file.arrayBuffer();
  const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

/**
 * Converts Degrees Minutes Seconds (DMS) string e.g. "28°46'52\"N" or "106°10'8\"W"
 * or decimal strings to numeric decimal degrees (WGS84).
 */
export function parseCoordinateDMS(raw: string | undefined | null): number | null {
  if (!raw) return null;
  const s = raw.toString().trim();
  if (s === '-' || s === '' || s.toLowerCase() === 'null') return null;

  // Try direct decimal parse first e.g. "-106.1688" or "28.7811"
  if (/^-?\d+(\.\d+)?$/.test(s)) {
    const val = parseFloat(s);
    return isNaN(val) ? null : val;
  }

  // DMS regex: matches e.g. 28°46'52"N, 106°10'8"W, 28°46'52.4"N, etc.
  // Also handles spaces, single quotes, double quotes, degrees symbol
  const dmsRegex = /([0-9]+(?:\.[0-9]+)?)[°\s]+([0-9]+(?:\.[0-9]+)?)['\s]+([0-9]+(?:\.[0-9]+)?)"?\s*([NSEWnsew])?/;
  const match = s.match(dmsRegex);
  if (match) {
    const deg = parseFloat(match[1]);
    const min = parseFloat(match[2]);
    const sec = parseFloat(match[3]);
    const dir = (match[4] || '').toUpperCase();

    let dec = deg + min / 60 + sec / 3600;
    if (dir === 'S' || dir === 'W') {
      dec = -dec;
    }
    return Math.round(dec * 1000000) / 1000000;
  }

  return null;
}

export function autoDetectColumnMapping(headers: string[]): ColumnMapping {
  const norm = (s: string) => s.toLowerCase().trim().replace(/[^a-z0-9]/g, '');

  const findBest = (patterns: string[]): string => {
    for (const p of patterns) {
      const match = headers.find(h => norm(h).includes(p));
      if (match) return match;
    }
    return '';
  };

  return {
    targetPhoneCol: findBest(['telefono', 'target', 'lineainvestigada', 'numblanco']),
    eventTypeCol: findBest(['tipo', 'trafico', 'evento', 'service', 'eventtype']),
    sourceNumberCol: findBest(['numeroa', 'origen', 'calling', 'telefonoa', 'src', 'llamante']),
    destinationNumberCol: findBest(['numerob', 'destino', 'called', 'telefonob', 'dst', 'llamado', 'destinatario']),
    dateCol: findBest(['fecha', 'date', 'fec']),
    timeCol: findBest(['hora', 'time', 'hor']),
    timestampCol: findBest(['fechahora', 'timestamp', 'datetime', 'inicio']),
    durationCol: findBest(['duracion', 'duracionseg', 'dur', 'segundos', 'duration', 'tiempo']),
    imeiCol: findBest(['imei', 'serie', 'dispositivo']),
    latitudeCol: findBest(['latitud', 'lat', 'ubicaciongeografica', 'latitude', 'y']),
    longitudeCol: findBest(['longitud', 'long', 'lng', 'lon', 'longitude', 'x']),
    azimuthCol: findBest(['azimuth', 'azimut', 'angulo', 'orientacion', 'sector']),
    cellIdCol: findBest(['celda', 'cell', 'cgi', 'site', 'antena', 'bts', 'ci']),
    operatorCol: findBest(['operador', 'operator', 'carrier', 'compania'])
  };
}

export function normalizePhoneNumber(rawNumber: string, defaultCountryPrefix: string = '+52'): {
  normalized: string;
  transformations: string[];
  isValid: boolean;
} {
  const transformations: string[] = [];
  if (!rawNumber) {
    return { normalized: '', transformations: ['Número vacío'], isValid: false };
  }

  const str = rawNumber.toString().trim();

  // Handle data connection targets like "internet.itelcel.com"
  if (str.toLowerCase().includes('internet') || str.toLowerCase().includes('itelcel') || str.toLowerCase().includes('apn')) {
    return { normalized: str.toLowerCase(), transformations: ['Destino de paquete de datos (APN Operadora)'], isValid: true };
  }

  let cleaned = str.replace(/[^0-9+]/g, '').trim();

  if (cleaned.startsWith('+')) {
    return { normalized: cleaned, transformations: ['Formato internacional con prefijo +'], isValid: cleaned.length >= 8 };
  }

  // Mexico 10-digit standard (e.g. 6141769216 -> +52 614 176 9216)
  if (defaultCountryPrefix === '+52') {
    if (cleaned.length === 10) {
      cleaned = '+52' + cleaned;
      transformations.push('Adición de prefijo internacional México (+52) a número de 10 dígitos');
    } else if (cleaned.length === 12 && cleaned.startsWith('52')) {
      cleaned = '+' + cleaned;
    } else if (cleaned.length === 13 && cleaned.startsWith('521')) {
      // old Mexican mobile 521 prefix
      cleaned = '+52' + cleaned.substring(3);
      transformations.push('Conversión de antiguo prefijo móvil 521 a estándar +52');
    } else {
      cleaned = '+52' + cleaned;
    }
  } else if (defaultCountryPrefix === '+54') {
    // Argentina standard
    if (cleaned.startsWith('0')) {
      cleaned = cleaned.substring(1);
      transformations.push('Eliminación de 0 inicial');
    }
    if (cleaned.startsWith('15')) {
      cleaned = '11' + cleaned.substring(2);
    }
    if (!cleaned.startsWith('54')) {
      cleaned = '+549' + cleaned;
      transformations.push('Adición de prefijo internacional móvil Argentina (+549)');
    } else {
      cleaned = '+' + cleaned;
    }
  } else {
    // Other countries
    const cleanPrefix = defaultCountryPrefix.replace('+', '');
    if (!cleaned.startsWith(cleanPrefix)) {
      cleaned = defaultCountryPrefix + cleaned;
      transformations.push(`Adición de prefijo de país (${defaultCountryPrefix})`);
    } else {
      cleaned = '+' + cleaned;
    }
  }

  const isValid = cleaned.length >= 8 && cleaned.length <= 16;
  return { normalized: cleaned, transformations, isValid };
}

export function parseEventTypeDetails(raw: string): {
  eventType: CDREventType;
  tipo2: string;
  colorTag: string;
  isMirror: boolean;
  mirrorType: 'NONE' | 'TRANSITO' | 'TRANSFER';
} {
  const s = (raw || '').toUpperCase().trim();

  // Espejos: VOZ TRANSITO y VOZ TRANSFER (vital forensic pattern from user Image 3)
  if (s.includes('TRANSITO') || s.includes('TRANSIT')) {
    return {
      eventType: 'VOZ_TRANSITO',
      tipo2: 'Espejo (Tránsito)',
      colorTag: 'Naranja',
      isMirror: true,
      mirrorType: 'TRANSITO'
    };
  }
  if (s.includes('TRANSFER') || s.includes('TRANSF')) {
    return {
      eventType: 'VOZ_TRANSFER',
      tipo2: 'Espejo (Transfer)',
      colorTag: 'Morado',
      isMirror: true,
      mirrorType: 'TRANSFER'
    };
  }

  // Datos / Internet (from user Image 1 & 2)
  if (s.includes('DATOS') || s.includes('DATA') || s.includes('INTERNET') || s.includes('GPRS') || s.includes('LTE')) {
    return {
      eventType: 'DATOS',
      tipo2: 'Internet',
      colorTag: 'Amarillo',
      isMirror: false,
      mirrorType: 'NONE'
    };
  }

  // Voz Entrante (LL-E / Azul)
  if (s.includes('VOZ ENTRANTE') || s.includes('ENTRANTE') || s.includes('LL-E') || s.includes('INCOMING') || s.includes('MT')) {
    return {
      eventType: 'LLAMADA_ENTRANTE',
      tipo2: 'LL-E',
      colorTag: 'Azul',
      isMirror: false,
      mirrorType: 'NONE'
    };
  }

  // Voz Saliente (LL-S / Verde)
  if (s.includes('VOZ SALIENTE') || s.includes('SALIENTE') || s.includes('LL-S') || s.includes('OUTGOING') || s.includes('MO')) {
    return {
      eventType: 'LLAMADA_SALIENTE',
      tipo2: 'LL-S',
      colorTag: 'Verde',
      isMirror: false,
      mirrorType: 'NONE'
    };
  }

  // SMS
  if (s.includes('SMS')) {
    if (s.includes('SAL') || s.includes('MO') || s.includes('OUT')) {
      return { eventType: 'SMS_SALIENTE', tipo2: 'SMS-S', colorTag: 'Magenta', isMirror: false, mirrorType: 'NONE' };
    }
    return { eventType: 'SMS_ENTRANTE', tipo2: 'SMS-E', colorTag: 'Cian', isMirror: false, mirrorType: 'NONE' };
  }

  return {
    eventType: 'OTRO',
    tipo2: raw || 'Otro',
    colorTag: 'Gris',
    isMirror: false,
    mirrorType: 'NONE'
  };
}

/**
 * Parses date and time from either separate columns (Fecha + Hora) or combined timestamp.
 * Handles formats: DD/MM/YYYY, YYYY-MM-DD, HH:MM:SS, etc.
 */
export function parseDateTime(rawDate: string, rawTime: string): { iso: string; dateStr: string; timeStr: string } | null {
  const dStr = (rawDate || '').toString().trim();
  const tStr = (rawTime || '').toString().trim();

  if (!dStr && !tStr) return null;

  let year: number, month: number, day: number;

  if (dStr.includes('/')) {
    // DD/MM/YYYY or MM/DD/YYYY
    const parts = dStr.split('/');
    if (parts.length === 3) {
      day = parseInt(parts[0], 10);
      month = parseInt(parts[1], 10) - 1;
      year = parseInt(parts[2], 10);
      if (year < 100) year += 2000;
    } else {
      return null;
    }
  } else if (dStr.includes('-')) {
    // YYYY-MM-DD or DD-MM-YYYY
    const parts = dStr.split('-');
    if (parts[0].length === 4) {
      year = parseInt(parts[0], 10);
      month = parseInt(parts[1], 10) - 1;
      day = parseInt(parts[2], 10);
    } else {
      day = parseInt(parts[0], 10);
      month = parseInt(parts[1], 10) - 1;
      year = parseInt(parts[2], 10);
    }
  } else {
    const parsed = new Date(dStr);
    if (!isNaN(parsed.getTime())) {
      return {
        iso: parsed.toISOString(),
        dateStr: dStr,
        timeStr: tStr || parsed.toTimeString().substring(0, 8)
      };
    }
    return null;
  }

  let hours = 0, minutes = 0, seconds = 0;
  if (tStr) {
    const tParts = tStr.split(':');
    hours = parseInt(tParts[0], 10) || 0;
    minutes = parseInt(tParts[1], 10) || 0;
    seconds = parseInt(tParts[2], 10) || 0;
  }

  const dt = new Date(Date.UTC(year, month, day, hours, minutes, seconds));
  if (isNaN(dt.getTime())) return null;

  return {
    iso: dt.toISOString(),
    dateStr: dStr,
    timeStr: tStr
  };
}

export async function parseSheetFile(
  file: File,
  mapping: ColumnMapping,
  countryPrefix: string = '+52',
  _timezoneOffsetHours: number = -6,
  caseId: string = ''
): Promise<{ records: NormalizedCDR[]; report: ImportValidationReport }> {
  const hash = await computeFileSha256(file);
  const data = await file.arrayBuffer();
  const workbook = XLSX.read(data, { type: 'array', cellDates: true });
  const firstSheetName = workbook.SheetNames[0];
  const worksheet = workbook.Sheets[firstSheetName];
  const rows: Record<string, any>[] = XLSX.utils.sheet_to_json(worksheet, { defval: '' });

  const records: NormalizedCDR[] = [];
  const targetCounter: Record<string, number> = {};
  const duplicateMap = new Set<string>();

  let validCount = 0;
  let rejectedCount = 0;
  let incompleteCount = 0;
  let duplicateCount = 0;
  let mirrorCount = 0;
  let dataCount = 0;
  let voiceCount = 0;
  const rejectionReasons: Record<string, number> = {};

  const addRejection = (reason: string) => {
    rejectionReasons[reason] = (rejectionReasons[reason] || 0) + 1;
  };

  rows.forEach((row, index) => {
    const rowNumber = index + 2;

    const rawTarget = String(row[mapping.targetPhoneCol] ?? '').trim();
    const rawSrc = String(row[mapping.sourceNumberCol] ?? '').trim();
    const rawDst = String(row[mapping.destinationNumberCol] ?? '').trim();
    const rawEvent = String(row[mapping.eventTypeCol] ?? '').trim();
    const rawDate = String(row[mapping.dateCol] ?? '').trim();
    const rawTime = String(row[mapping.timeCol] ?? '').trim();
    const rawTimestampCombined = String(row[mapping.timestampCol] ?? '').trim();
    const rawDur = String(row[mapping.durationCol] ?? '').trim();
    const rawImei = String(row[mapping.imeiCol] ?? '').trim();
    const rawLat = String(row[mapping.latitudeCol] ?? '').trim();
    const rawLng = String(row[mapping.longitudeCol] ?? '').trim();
    const rawAz = String(row[mapping.azimuthCol] ?? '').trim();
    const rawCell = String(row[mapping.cellIdCol] ?? '').trim();
    const rawOp = String(row[mapping.operatorCol] ?? '').trim();

    const validationNotes: string[] = [];
    const transformations: string[] = [];
    let status: CDRRecordStatus = 'VALID';

    // 1. Phone numbers
    const normSrc = normalizePhoneNumber(rawSrc, countryPrefix);
    const normDst = normalizePhoneNumber(rawDst, countryPrefix);

    transformations.push(...normSrc.transformations.map(t => `Número A: ${t}`));
    transformations.push(...normDst.transformations.map(t => `Número B: ${t}`));

    if (!normSrc.isValid && !normDst.isValid && !rawSrc.includes('internet') && !rawDst.includes('internet')) {
      status = 'REJECTED';
      validationNotes.push('Número A y Número B no válidos');
      addRejection('Número de teléfono inválido');
    }

    // 2. Event Type, Tipo 2, and Color Tag (Matching Image 1, 2, and 3)
    const eventDetails = parseEventTypeDetails(rawEvent);
    if (eventDetails.isMirror) {
      mirrorCount++;
      validationNotes.push(`Registro de Espejo telefónico (${eventDetails.tipo2}): requiere aislamiento en conteos de volumen para no duplicar llamadas`);
    }
    if (eventDetails.eventType === 'DATOS') {
      dataCount++;
    } else if (eventDetails.eventType.startsWith('LLAMADA') || eventDetails.isMirror) {
      voiceCount++;
    }

    // 3. Date & Time
    let parsedDt = parseDateTime(rawDate || rawTimestampCombined, rawTime);
    if (!parsedDt && rawTimestampCombined) {
      parsedDt = parseDateTime(rawTimestampCombined, '');
    }

    if (!parsedDt) {
      status = 'REJECTED';
      validationNotes.push('Fecha u hora inválida');
      addRejection('Fecha u hora inválida');
    }

    // 4. Coordinates (DMS e.g. 28°46'52"N, 106°10'8"W or decimal or null)
    let lat = parseCoordinateDMS(rawLat);
    let lng = parseCoordinateDMS(rawLng);

    // If coordinates were combined in a single column like "28°46'52"N / 106°10'8"W"
    if ((lat === null || lng === null) && rawLat && (rawLat.includes('/') || rawLat.includes('\n'))) {
      const parts = rawLat.split(/[\/\n]+/);
      if (parts.length >= 2) {
        lat = parseCoordinateDMS(parts[0]);
        lng = parseCoordinateDMS(parts[1]);
      }
    }

    if (lat === null || lng === null) {
      incompleteCount++;
      if (rawLat === '-' || rawLat === '' || rawLng === '-' || rawLng === '') {
        validationNotes.push('Sin coordenadas de celda (tráfico sin georreferencia o registro de tránsito)');
      } else {
        validationNotes.push('Coordenadas DMS no reconocibles');
      }
      if (status !== 'REJECTED') status = 'WARNING';
    } else {
      transformations.push(`Coordenadas DMS convertidas a WGS84: Lat ${lat.toFixed(6)}, Lng ${lng.toFixed(6)}`);
    }

    // 5. Azimuth
    let azimuth: number | null = null;
    if (rawAz && rawAz !== '-') {
      const cleanAz = rawAz.replace('°', '').replace(',', '.').trim();
      const pAz = parseFloat(cleanAz);
      if (!isNaN(pAz) && pAz >= 0 && pAz <= 360) {
        azimuth = pAz;
      }
    }

    // 6. Duration
    const durSec = parseInt(rawDur.replace(/[^0-9]/g, ''), 10) || 0;

    // 7. IMEI clean
    const cleanImei = rawImei && rawImei !== '-' ? rawImei.replace(/[^0-9]/g, '') : null;

    // 8. Cell ID inference if missing
    let cellId = rawCell;
    if (!cellId && lat !== null && lng !== null) {
      cellId = `CEL-${lat.toFixed(3)}_${lng.toFixed(3)}${azimuth !== null ? `_A${azimuth}` : ''}`;
    }
    if (!cellId) cellId = 'SIN_CELDA';

    // 9. Duplicates
    const dupKey = `${normSrc.normalized}|${normDst.normalized}|${parsedDt?.iso ?? ''}|${durSec}|${eventDetails.eventType}`;
    let isDuplicate = false;
    if (duplicateMap.has(dupKey)) {
      isDuplicate = true;
      duplicateCount++;
      validationNotes.push('Advertencia: Registro idéntico detectado');
      if (status !== 'REJECTED') status = 'WARNING';
    } else {
      duplicateMap.add(dupKey);
    }

    if (status === 'VALID') validCount++;
    if (status === 'REJECTED') rejectedCount++;

    // Track targets
    const tgt = rawTarget || normSrc.normalized;
    if (tgt && !tgt.includes('internet')) {
      targetCounter[tgt] = (targetCounter[tgt] || 0) + 1;
    }

    records.push({
      id: `cdr-${rowNumber.toString().padStart(6, '0')}`,
      importId: `imp-${hash.substring(0, 8)}`,
      rowNumber,
      caseId,
      targetPhone: rawTarget || normSrc.normalized,
      sourceNumber: normSrc.normalized || rawSrc,
      rawSourceNumber: rawSrc,
      destinationNumber: normDst.normalized || rawDst,
      rawDestinationNumber: rawDst,
      timestamp: parsedDt?.iso ?? new Date().toISOString(),
      rawDate: rawDate || (parsedDt?.dateStr ?? ''),
      rawTime: rawTime || (parsedDt?.timeStr ?? ''),
      rawTimestamp: `${rawDate} ${rawTime}`.trim() || rawTimestampCombined,
      eventType: eventDetails.eventType,
      rawEventType: rawEvent,
      tipo2: eventDetails.tipo2,
      colorTag: eventDetails.colorTag,
      durationSeconds: durSec,
      rawDuration: rawDur,
      imei: cleanImei,
      rawImei: rawImei,
      cellId,
      rawCellId: rawCell,
      operator: rawOp || (rawDst.includes('itelcel') ? 'Telcel México' : 'Operador Autorizado'),
      latitude: lat,
      longitude: lng,
      rawLatitude: rawLat,
      rawLongitude: rawLng,
      azimuth,
      rawAzimuth: rawAz,
      sourceFile: file.name,
      status,
      validationNotes,
      transformations,
      isDuplicate,
      isMirror: eventDetails.isMirror,
      mirrorType: eventDetails.mirrorType
    });
  });

  const detectedTargets = Object.entries(targetCounter)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(e => e[0]);

  const report: ImportValidationReport = {
    importId: `imp-${hash.substring(0, 8)}`,
    caseId,
    filename: file.name,
    fileHashSha256: hash,
    fileSizeBytes: file.size,
    totalRows: rows.length,
    validCount,
    rejectedCount,
    incompleteCount,
    duplicateCount,
    mirrorCount,
    dataCount,
    voiceCount,
    operatorDetected: records.some(r => r.destinationNumber.includes('itelcel')) ? 'Telcel México (Radiomóvil Dipsa)' : 'Operador Telefónico',
    countryPrefix,
    timezone: 'America/Chihuahua (UTC-6 / CST)',
    importedAt: new Date().toISOString(),
    detectedTargets,
    rejectionReasons
  };

  return { records, report };
}
