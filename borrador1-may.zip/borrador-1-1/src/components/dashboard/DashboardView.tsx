import React from 'react';
import { 
  FileSpreadsheet, 
  PhoneCall, 
  Radio, 
  ShieldCheck, 
  AlertCircle, 
  Clock, 
  MapPin, 
  ArrowRight,
  Database,
  Fingerprint,
  FileCheck
} from 'lucide-react';
import { ProsecutionCase, NormalizedCDR, ImportValidationReport } from '../../types';
import { NavTab } from '../layout/Sidebar';

interface DashboardViewProps {
  currentCase: ProsecutionCase | null;
  records: NormalizedCDR[];
  report: ImportValidationReport | null;
  onNavigate: (tab: NavTab) => void;
  onLoadSyntheticData: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  currentCase,
  records,
  report,
  onNavigate,
  onLoadSyntheticData
}) => {
  const validRecords = records.filter(r => r.status === 'VALID');
  const warningRecords = records.filter(r => r.status === 'WARNING');
  const rejectedRecords = records.filter(r => r.status === 'REJECTED');
  const uniqueTowers = new Set(records.filter(r => r.latitude !== null).map(r => r.cellId)).size;
  const uniqueNumbers = new Set([
    ...records.map(r => r.sourceNumber),
    ...records.map(r => r.destinationNumber)
  ]).size;

  return (
    <div className="space-y-6">
      {/* Top Welcome / Case Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-blue-950/40 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center space-x-2.5">
              <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-blue-950 text-blue-300 border border-blue-800">
                {currentCase?.caseNumber || 'EXP-SIN-ASIGNAR'}
              </span>
              <h1 className="text-lg font-bold text-white tracking-tight">
                {currentCase?.title || 'Expediente Judicial de Análisis Pericial'}
              </h1>
            </div>
            <p className="text-xs text-slate-400 max-w-3xl leading-relaxed">
              {currentCase?.description || 'Causa penal en etapa de instrucción preliminar.'}
            </p>
            <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400 pt-1">
              <span><strong>Fiscalía:</strong> {currentCase?.fiscalUnit || 'Fiscalía Penal Ordinaria'}</span>
              <span><strong>Fiscal a cargo:</strong> {currentCase?.leadProsecutor || 'Pendiente de asignación'}</span>
              <span><strong>Estado:</strong> <span className="text-emerald-400 uppercase font-semibold">{currentCase?.status.replace('_', ' ')}</span></span>
            </div>
          </div>

          <div className="flex flex-wrap gap-2 shrink-0">
            <button
              onClick={() => onNavigate('import')}
              className="px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg flex items-center space-x-2 shadow transition"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span>Importar Sábana</span>
            </button>
            {records.length === 0 && (
              <button
                onClick={onLoadSyntheticData}
                className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold rounded-lg flex items-center space-x-2 transition"
              >
                <Database className="w-4 h-4 text-amber-400" />
                <span>Cargar Datos Sintéticos</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3.5">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Eventos Totales</span>
            <Database className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white">{records.length.toLocaleString()}</div>
          <div className="text-[11px] text-slate-500">Registros en memoria</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Válidos Pericial</span>
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-400">{validRecords.length.toLocaleString()}</div>
          <div className="text-[11px] text-emerald-500/80">E.164 y Fechas OK</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Números Únicos</span>
            <PhoneCall className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-purple-300">{uniqueNumbers.toLocaleString()}</div>
          <div className="text-[11px] text-slate-500">Origen y Destino</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Antenas Mapeadas</span>
            <Radio className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-cyan-300">{uniqueTowers.toLocaleString()}</div>
          <div className="text-[11px] text-slate-500">Celdas con WGS84</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Duplicados / Alertas</span>
            <AlertCircle className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-amber-400">{warningRecords.length.toLocaleString()}</div>
          <div className="text-[11px] text-amber-500/80">Aislados de conteos</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Hash Evidencia</span>
            <Fingerprint className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-xs font-mono font-bold text-indigo-300 truncate" title={report?.fileHashSha256 || 'Pendiente'}>
            {report?.fileHashSha256 ? `${report.fileHashSha256.substring(0, 10)}...` : 'Sin archivo'}
          </div>
          <div className="text-[11px] text-indigo-400/80">SHA-256 Verificado</div>
        </div>
      </div>

      {/* Grid: Active Sheet Metadata & Quick Navigation Modules */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Ingestion & Provenance Status */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <FileCheck className="w-4 h-4 text-blue-400" />
              <h2 className="text-sm font-bold text-white">Estado de la Sábana Cargada en Causa</h2>
            </div>
            {report && (
              <span className="text-[11px] font-mono text-slate-400">
                Importado: {new Date(report.importedAt).toLocaleDateString()} {new Date(report.importedAt).toLocaleTimeString()}
              </span>
            )}
          </div>

          {report ? (
            <div className="space-y-3.5">
              <div className="bg-slate-950/80 border border-slate-800/80 rounded-lg p-3 text-xs space-y-2">
                <div className="flex justify-between items-center pb-2 border-b border-slate-800">
                  <span className="text-slate-400">Archivo Original:</span>
                  <span className="font-mono text-slate-200 font-semibold">{report.filename}</span>
                </div>
                <div className="flex justify-between items-center pb-2 border-b border-slate-800">
                  <span className="text-slate-400">Hash SHA-256 de Origen:</span>
                  <span className="font-mono text-emerald-400 text-[11px] select-all">{report.fileHashSha256}</span>
                </div>
                <div className="flex justify-between items-center pb-2 border-b border-slate-800">
                  <span className="text-slate-400">Operador Detectado:</span>
                  <span className="text-slate-200 font-medium">{report.operatorDetected}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Zona Horaria Aplicada:</span>
                  <span className="text-slate-200">{report.timezone}</span>
                </div>
              </div>

              {/* Progress bar of validity */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Proporción de Depuración Forense:</span>
                  <span className="text-emerald-400 font-semibold">
                    {records.length > 0 ? ((validRecords.length / records.length) * 100).toFixed(1) : 0}% Válidos
                  </span>
                </div>
                <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden flex">
                  <div 
                    className="bg-emerald-500 h-full" 
                    style={{ width: `${records.length > 0 ? (validRecords.length / records.length) * 100 : 0}%` }}
                    title={`${validRecords.length} válidos`}
                  />
                  <div 
                    className="bg-amber-500 h-full" 
                    style={{ width: `${records.length > 0 ? (warningRecords.length / records.length) * 100 : 0}%` }}
                    title={`${warningRecords.length} advertencias/duplicados`}
                  />
                  <div 
                    className="bg-rose-500 h-full" 
                    style={{ width: `${records.length > 0 ? (rejectedRecords.length / records.length) * 100 : 0}%` }}
                    title={`${rejectedRecords.length} rechazados`}
                  />
                </div>
                <div className="flex justify-between text-[11px] text-slate-500 pt-0.5">
                  <span className="text-emerald-400">● {validRecords.length} Válidos</span>
                  <span className="text-amber-400">● {warningRecords.length} Con advertencias / Duplicados</span>
                  <span className="text-rose-400">● {rejectedRecords.length} Rechazados</span>
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  onClick={() => onNavigate('explorer')}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg flex items-center space-x-1.5 transition"
                >
                  <span>Explorar Registros Depurados</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ) : (
            <div className="text-center py-10 space-y-3 bg-slate-950/40 border border-dashed border-slate-800 rounded-xl">
              <Database className="w-10 h-10 text-slate-600 mx-auto" />
              <div className="space-y-1">
                <h3 className="text-sm font-semibold text-slate-300">No hay sábana telefónica importada en este expediente</h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Importe un archivo oficial CSV o XLSX suministrado por la operadora telefónica o cargue el dataset pericial de prueba.
                </p>
              </div>
              <div className="flex justify-center gap-3 pt-2">
                <button
                  onClick={() => onNavigate('import')}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg"
                >
                  Importar Archivo
                </button>
                <button
                  onClick={onLoadSyntheticData}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg border border-slate-700"
                >
                  Cargar Datos de Muestra
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right Col: Quick Module Cards & Forensic Assurance */}
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">Flujo de Análisis Judicial</h3>
            
            <div className="space-y-2">
              <button
                onClick={() => onNavigate('analysis')}
                className="w-full p-3 bg-slate-950/70 hover:bg-slate-800/80 border border-slate-800 rounded-lg text-left transition flex items-center justify-between group"
              >
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-blue-950/80 text-blue-400 rounded-lg">
                    <PhoneCall className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold text-slate-200 group-hover:text-blue-400">Análisis por Número</h4>
                    <p className="text-[11px] text-slate-500">Contactos frecuentes, ratio llamadas/SMS</p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-slate-300 transition" />
              </button>

              <button
                onClick={() => onNavigate('map')}
                className="w-full p-3 bg-slate-950/70 hover:bg-slate-800/80 border border-slate-800 rounded-lg text-left transition flex items-center justify-between group"
              >
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-emerald-950/80 text-emerald-400 rounded-lg">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold text-slate-200 group-hover:text-emerald-400">Cartografía de Antenas</h4>
                    <p className="text-[11px] text-slate-500">Celdas activadas, azimut, última antena</p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-slate-300 transition" />
              </button>

              <button
                onClick={() => onNavigate('reports')}
                className="w-full p-3 bg-slate-950/70 hover:bg-slate-800/80 border border-slate-800 rounded-lg text-left transition flex items-center justify-between group"
              >
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-purple-950/80 text-purple-400 rounded-lg">
                    <FileCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold text-slate-200 group-hover:text-purple-400">Generar Dictamen Pericial</h4>
                    <p className="text-[11px] text-slate-500">Informe PDF imprimible con limitaciones</p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-slate-300 transition" />
              </button>
            </div>
          </div>

          {/* Legal Protocol Assurance Box */}
          <div className="bg-slate-950 border border-slate-800/90 rounded-xl p-4 text-xs space-y-2 text-slate-400">
            <div className="flex items-center space-x-1.5 text-blue-400 font-semibold text-xs">
              <ShieldCheck className="w-4 h-4" />
              <span>Garantías Forenses Incorporadas</span>
            </div>
            <ul className="space-y-1.5 text-[11px] text-slate-400 pl-4 list-disc">
              <li>Cálculo de Hash SHA-256 de origen previo a cualquier manipulación.</li>
              <li>Transformaciones documentadas sin sobreescritura destructiva de originales.</li>
              <li>Las celdas NO se interpretan como coordenadas GPS puntuales.</li>
              <li>Auditoría inmutable de accesos y consultas judiciales.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
