import React, { useState } from 'react';
import { 
  Briefcase, 
  Plus, 
  Search, 
  Users, 
  Calendar, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Phone,
  FileSpreadsheet
} from 'lucide-react';
import { ProsecutionCase, UserProfile, CaseStatus } from '../../types';
import { logAuditEvent } from '../../services/auditService';

interface CasesViewProps {
  cases: ProsecutionCase[];
  currentCase: ProsecutionCase | null;
  onSelectCase: (c: ProsecutionCase) => void;
  onAddCase: (c: ProsecutionCase) => void;
  currentUser: UserProfile;
}

export const CasesView: React.FC<CasesViewProps> = ({
  cases,
  currentCase,
  onSelectCase,
  onAddCase,
  currentUser
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('TODOS');
  const [showCreateModal, setShowCreateModal] = useState(false);

  // Form state
  const [newCaseNumber, setNewCaseNumber] = useState('');
  const [newTitle, setNewTitle] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newFiscalUnit, setNewFiscalUnit] = useState('Unidad Fiscal Especializada en Delitos Complejos');
  const [newLeadProsecutor, setNewLeadProsecutor] = useState('');
  const [newTargetNumbers, setNewTargetNumbers] = useState('');
  const [formError, setFormError] = useState('');

  const filteredCases = cases.filter(c => {
    const matchesSearch = 
      c.caseNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.leadProsecutor.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'TODOS' || c.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleCreateCase = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCaseNumber.trim() || !newTitle.trim()) {
      setFormError('El número de expediente y la carátula son obligatorios');
      return;
    }

    const targets = newTargetNumbers
      .split('\n')
      .map(s => s.trim())
      .filter(s => s.length > 0);

    const newCase: ProsecutionCase = {
      id: `case-${Date.now()}`,
      caseNumber: newCaseNumber.trim().toUpperCase(),
      title: newTitle.trim(),
      description: newDescription.trim(),
      fiscalUnit: newFiscalUnit.trim(),
      leadProsecutor: newLeadProsecutor.trim() || currentUser.displayName,
      status: 'en_analisis',
      assignedUsers: [currentUser.uid],
      createdBy: currentUser.uid,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      targetNumbers: targets
    };

    onAddCase(newCase);
    logAuditEvent(
      'CASE_CREATE',
      `Creación de nuevo expediente judicial: ${newCase.caseNumber} - ${newCase.title}`,
      currentUser.email,
      currentUser.uid,
      newCase.id
    );

    setShowCreateModal(false);
    setNewCaseNumber('');
    setNewTitle('');
    setNewDescription('');
    setNewTargetNumbers('');
    setFormError('');
  };

  const getStatusBadge = (status: CaseStatus) => {
    switch (status) {
      case 'en_analisis':
        return (
          <span className="flex items-center space-x-1 px-2.5 py-0.5 rounded text-xs font-semibold bg-blue-950/80 text-blue-400 border border-blue-800">
            <Clock className="w-3 h-3" />
            <span>EN ANÁLISIS</span>
          </span>
        );
      case 'abierto':
        return (
          <span className="flex items-center space-x-1 px-2.5 py-0.5 rounded text-xs font-semibold bg-emerald-950/80 text-emerald-400 border border-emerald-800">
            <CheckCircle2 className="w-3 h-3" />
            <span>ABIERTO</span>
          </span>
        );
      case 'cerrado':
        return (
          <span className="flex items-center space-x-1 px-2.5 py-0.5 rounded text-xs font-semibold bg-slate-800 text-slate-300">
            <span>CERRADO</span>
          </span>
        );
      case 'archivado':
        return (
          <span className="flex items-center space-x-1 px-2.5 py-0.5 rounded text-xs font-semibold bg-amber-950/80 text-amber-400 border border-amber-800">
            <span>ARCHIVADO</span>
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Header and Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center space-x-2">
            <Briefcase className="w-5 h-5 text-blue-400" />
            <span>Gestión de Expedientes Judiciales</span>
          </h1>
          <p className="text-xs text-slate-400">
            Registro, asignación pericial y control de acceso por fiscalía y causa.
          </p>
        </div>

        {currentUser.role !== 'consulta' && (
          <button
            onClick={() => setShowCreateModal(true)}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg flex items-center space-x-2 shadow transition self-start"
          >
            <Plus className="w-4 h-4" />
            <span>Nuevo Expediente</span>
          </button>
        )}
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:w-96">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Buscar por número de causa, carátula o fiscal..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500"
          />
        </div>

        <div className="flex items-center space-x-2 w-full md:w-auto">
          <span className="text-xs text-slate-400">Estado:</span>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500 cursor-pointer"
          >
            <option value="TODOS">Todos los estados</option>
            <option value="en_analisis">En Análisis</option>
            <option value="abierto">Abierto</option>
            <option value="cerrado">Cerrado</option>
            <option value="archivado">Archivado</option>
          </select>
        </div>
      </div>

      {/* Cases Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredCases.map((c) => {
          const isSelected = currentCase?.id === c.id;
          return (
            <div
              key={c.id}
              className={`bg-slate-900 border rounded-xl p-5 flex flex-col justify-between space-y-4 transition ${
                isSelected
                  ? 'border-blue-500 shadow-md shadow-blue-950/40 bg-gradient-to-b from-slate-900 to-blue-950/20'
                  : 'border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <span className="font-mono text-xs font-bold text-blue-400 px-2 py-0.5 rounded bg-blue-950 border border-blue-800/80">
                    {c.caseNumber}
                  </span>
                  {getStatusBadge(c.status)}
                </div>

                <div>
                  <h3 className="text-sm font-bold text-white leading-snug line-clamp-2">
                    {c.title}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 line-clamp-3 leading-relaxed">
                    {c.description}
                  </p>
                </div>

                <div className="bg-slate-950/70 border border-slate-800/70 rounded-lg p-3 text-xs space-y-1.5 text-slate-400">
                  <div className="flex justify-between">
                    <span>Fiscalía:</span>
                    <span className="text-slate-200 font-medium truncate max-w-[170px]" title={c.fiscalUnit}>
                      {c.fiscalUnit}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Fiscal a cargo:</span>
                    <span className="text-slate-200 font-medium">{c.leadProsecutor}</span>
                  </div>
                  {c.targetNumbers && c.targetNumbers.length > 0 && (
                    <div className="pt-1 border-t border-slate-800/80">
                      <span className="text-[11px] text-slate-500 block mb-1">Números Objetivo:</span>
                      <div className="flex flex-wrap gap-1">
                        {c.targetNumbers.map((num, i) => (
                          <span key={i} className="font-mono text-[10px] bg-slate-900 text-purple-300 px-1.5 py-0.5 rounded border border-purple-900/50">
                            {num}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-slate-800">
                <span className="text-[11px] text-slate-500 flex items-center space-x-1">
                  <Calendar className="w-3 h-3" />
                  <span>{new Date(c.createdAt).toLocaleDateString()}</span>
                </span>

                <button
                  onClick={() => onSelectCase(c)}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition ${
                    isSelected
                      ? 'bg-blue-600 text-white cursor-default'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                  }`}
                >
                  {isSelected ? 'Expediente Activo' : 'Seleccionar'}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {filteredCases.length === 0 && (
        <div className="text-center py-12 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
          <Briefcase className="w-8 h-8 text-slate-600 mx-auto" />
          <p className="text-sm text-slate-400">No se encontraron expedientes con los criterios seleccionados.</p>
        </div>
      )}

      {/* Modal: Create Case */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h2 className="text-base font-bold text-white flex items-center space-x-2">
                <Briefcase className="w-5 h-5 text-blue-400" />
                <span>Alta de Expediente Judicial</span>
              </h2>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-slate-400 hover:text-white text-lg font-bold"
              >
                ×
              </button>
            </div>

            {formError && (
              <div className="p-3 bg-rose-950/80 border border-rose-800 rounded-lg text-rose-300 text-xs flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleCreateCase} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-400 mb-1 font-medium">Identificador de Causa / Número de Expediente *</label>
                <input
                  type="text"
                  placeholder="Ej: EXP-2026-F04-891"
                  value={newCaseNumber}
                  onChange={(e) => setNewCaseNumber(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-blue-500 font-mono"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-medium">Carátula / Título del Caso *</label>
                <input
                  type="text"
                  placeholder="Ej: Investigación por Defraudación y Comunicaciones Sospechosas"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-medium">Fiscalía / Unidad Interviniente</label>
                <input
                  type="text"
                  value={newFiscalUnit}
                  onChange={(e) => setNewFiscalUnit(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-medium">Fiscal Responsable</label>
                <input
                  type="text"
                  placeholder="Nombre y cargo del magistrado instructor"
                  value={newLeadProsecutor}
                  onChange={(e) => setNewLeadProsecutor(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-medium">Descripción de Hechos Investigados</label>
                <textarea
                  rows={3}
                  placeholder="Breve reseña fáctica del oficio de intervención judicial..."
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-blue-500 leading-relaxed"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-medium">
                  Números Blanco / Teléfonos Investigados (uno por línea)
                </label>
                <textarea
                  rows={2}
                  placeholder="+5491145218901&#10;+5491167823419"
                  value={newTargetNumbers}
                  onChange={(e) => setNewTargetNumbers(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-blue-500 font-mono"
                />
              </div>

              <div className="flex justify-end space-x-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium rounded-lg"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-lg shadow"
                >
                  Registrar Expediente
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
