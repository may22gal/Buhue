import React, { useState } from 'react';
import { 
  UploadCloud, 
  FileSpreadsheet, 
  CheckCircle, 
  AlertTriangle, 
  ArrowRight, 
  RefreshCw, 
  Fingerprint, 
  ShieldCheck, 
  SlidersHorizontal,
  Download,
  Layers,
  Smartphone,
  Globe
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { 
  ColumnMapping, 
  NormalizedCDR, 
  ImportValidationReport, 
  ProsecutionCase, 
  UserProfile 
} from '../../types';
import { 
  autoDetectColumnMapping, 
  parseSheetFile, 
  computeFileSha256 
} from '../../services/cdrParser';
import { generateSampleCsvContent } from '../../services/sampleData';
import { logAuditEvent } from '../../services/auditService';

interface ImportViewProps {
  currentCase: ProsecutionCase | null;
  onImportComplete: (records: NormalizedCDR[], report: ImportValidationReport) => void;
  currentUser: UserProfile;
}

export const ImportView: React.FC<ImportViewProps> = ({
  currentCase,
  onImportComplete,
  currentUser
}) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileSha256, setFileSha256] = useState<string>('');
  const [fileHeaders, setFileHeaders] = useState<string[]>([]);
  const [rawPreviewRows, setRawPreviewRows] = useState<Record<string, any>[]>([]);
  
  // Mapping configuration
  const [mapping, setMapping] = useState<ColumnMapping>({
    targetPhoneCol: '',
    eventTypeCol: '',
    sourceNumberCol: '',
    destinationNumberCol: '',
    dateCol: '',
    timeCol: '',
    timestampCol: '',
    durationCol: '',
    imeiCol: '',
    latitudeCol: '',
    longitudeCol: '',
    azimuthCol: '',
    cellIdCol: '',
    operatorCol: ''
  });

  // Normalization settings - default to +52 (Mexico, matching user sheet)
  const [countryPrefix, setCountryPrefix] = useState<string>('+52');
  const [timezoneOffset, setTimezoneOffset] = useState<number>(-6);
  
  // Processing state
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [stage, setStage] = useState<'upload' | 'preview_map' | 'completed'>('upload');
  const [validationReport, setValidationReport] = useState<ImportValidationReport | null>(null);
  const [errorMessage, setErrorMessage] = useState<string>('');

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      await loadFile(file);
    }
  };

  const loadFile = async (file: File) => {
    setIsProcessing(true);
    setErrorMessage('');
    try {
      setSelectedFile(file);
      const hash = await computeFileSha256(file);
      setFileSha256(hash);

      const data = await file.arrayBuffer();
      const workbook = XLSX.read(data, { type: 'array', cellDates: true });
      const firstSheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[firstSheetName];
      const json: Record<string, any>[] = XLSX.utils.sheet_to_json(worksheet, { defval: '' });

      if (json.length === 0) {
        setErrorMessage('El archivo no contiene filas de datos o está vacío.');
        setIsProcessing(false);
        return;
      }

      const headers = Object.keys(json[0]);
      setFileHeaders(headers);
      setRawPreviewRows(json.slice(0, 8));

      // Auto-detect columns (matching Imagen 1, 2, 3)
      const detected = autoDetectColumnMapping(headers);
      setMapping(detected);

      setStage('preview_map');
    } catch (err: unknown) {
      console.error(err);
      setErrorMessage('Error al leer el archivo. Compruebe que sea un CSV o XLSX válido.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleProcessSheet = async () => {
    if (!selectedFile) return;
    if (!mapping.sourceNumberCol && !mapping.destinationNumberCol) {
      setErrorMessage('Debe relacionar al menos una columna de número (Número A o Número B).');
      return;
    }
    if (!mapping.dateCol && !mapping.timestampCol) {
      setErrorMessage('Debe relacionar la columna de Fecha.');
      return;
    }

    setIsProcessing(true);
    setErrorMessage('');

    try {
      const { records, report } = await parseSheetFile(
        selectedFile,
        mapping,
        countryPrefix,
        timezoneOffset,
        currentCase?.id || 'case-default'
      );

      setValidationReport(report);
      onImportComplete(records, report);
      setStage('completed');

      logAuditEvent(
        'FILE_IMPORT',
        `Importación de sábana: ${selectedFile.name} (${records.length} registros, ${report.mirrorCount} espejos detectados)`,
        currentUser.email,
        currentUser.uid,
        currentCase?.id
      );
    } catch (err: unknown) {
      console.error(err);
      setErrorMessage('Ocurrió un error al procesar la sábana telefónica.');
    } finally {
      setIsProcessing(false);
    }
  };

  const downloadSampleTemplate = () => {
    const csv = generateSampleCsvContent();
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'Sabana_Original_Autorizada_Telcel_Ejemplo.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center space-x-2">
            <UploadCloud className="w-5 h-5 text-blue-400" />
            <span>Módulo de Importación y Normalización Forense</span>
          </h1>
          <p className="text-xs text-slate-400">
            Ingesta controlada de sábanas telefónicas en CSV o XLSX (soporte nativo para Telcel México, coordenadas DMS y espejos).
          </p>
        </div>

        <button
          onClick={downloadSampleTemplate}
          className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 rounded-lg text-xs font-medium flex items-center space-x-2 transition self-start"
        >
          <Download className="w-4 h-4 text-blue-400" />
          <span>Descargar CSV Ejemplo (Imagen 1 y 2)</span>
        </button>
      </div>

      {errorMessage && (
        <div className="p-3.5 bg-rose-950/80 border border-rose-800 rounded-xl text-rose-300 text-xs flex items-center space-x-2">
          <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Stage 1: File Upload */}
      {stage === 'upload' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 space-y-6">
          <div className="border-2 border-dashed border-slate-700 hover:border-blue-500 rounded-xl p-8 text-center space-y-4 bg-slate-950/40 transition">
            <FileSpreadsheet className="w-12 h-12 text-blue-400 mx-auto" />
            <div className="space-y-1">
              <h3 className="text-sm font-bold text-white">Seleccione la sábana telefónica pericial</h3>
              <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
                Compatible con sábanas oficiales de <strong>Telcel México</strong>, Movistar, Claro, etc. Convierte automáticamente coordenadas sexagesimales (DMS como <code>28°46'52"N</code>) y clasifica registros espejos.
              </p>
            </div>

            <div className="pt-2">
              <label className="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg shadow cursor-pointer transition">
                <span>Examinar archivo local (CSV o XLSX)...</span>
                <input
                  type="file"
                  accept=".csv,.xlsx,.xls"
                  onChange={handleFileChange}
                  className="hidden"
                />
              </label>
            </div>
            
            <p className="text-[11px] text-slate-500">
              * Se calculará inmediatamente el hash SHA-256 para preservar la cadena de custodia.
            </p>
          </div>
        </div>
      )}

      {/* Stage 2: Preview & Interactive Column Mapping */}
      {stage === 'preview_map' && selectedFile && (
        <div className="space-y-6">
          {/* File Provenance Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center space-x-2">
                <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-bold text-white font-mono">{selectedFile.name}</span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">
                  {(selectedFile.size / 1024).toFixed(1)} KB
                </span>
              </div>
              <div className="flex items-center space-x-2 text-[11px] text-slate-400">
                <Fingerprint className="w-3.5 h-3.5 text-blue-400" />
                <span className="font-mono text-emerald-400 text-[11px]">SHA-256: {fileSha256}</span>
              </div>
            </div>

            <button
              onClick={() => {
                setStage('upload');
                setSelectedFile(null);
              }}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium rounded-lg"
            >
              Cambiar Archivo
            </button>
          </div>

          {/* Raw Preview Table */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                1. Vista Previa de Filas Originales de la Sábana
              </h3>
              <span className="text-[11px] text-slate-500">Total columnas: {fileHeaders.length}</span>
            </div>

            <div className="overflow-x-auto border border-slate-800 rounded-lg">
              <table className="w-full text-[11px] text-left text-slate-300">
                <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800 font-mono">
                  <tr>
                    <th className="px-3 py-2 w-10 text-slate-500">#</th>
                    {fileHeaders.map((h, i) => (
                      <th key={i} className="px-3 py-2 whitespace-nowrap text-blue-300">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono">
                  {rawPreviewRows.map((row, idx) => (
                    <tr key={idx} className="hover:bg-slate-800/30">
                      <td className="px-3 py-1.5 text-slate-500">{idx + 1}</td>
                      {fileHeaders.map((h, cIdx) => (
                        <td key={cIdx} className="px-3 py-1.5 whitespace-nowrap text-slate-300">
                          {String(row[h] ?? '')}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Column Mapping Form */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="space-y-0.5">
              <h3 className="text-sm font-bold text-white flex items-center space-x-2">
                <SlidersHorizontal className="w-4 h-4 text-blue-400" />
                <span>2. Mapeo de Columnas de la Sábana con el Esquema Interno</span>
              </h3>
              <p className="text-xs text-slate-400">
                Verifique que cada campo de la imagen coincida con la columna correspondiente del archivo.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3.5 text-xs">
              <div>
                <label className="block text-slate-400 font-medium mb-1">
                  Teléfono Objetivo (Columna A)
                </label>
                <select
                  value={mapping.targetPhoneCol}
                  onChange={(e) => setMapping({ ...mapping, targetPhoneCol: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-blue-500"
                >
                  <option value="">-- No mapear --</option>
                  {fileHeaders.map(h => (
                    <option key={h} value={h}>{h}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">
                  Tipo de Evento (Columna B) *
                </label>
                <select
                  value={mapping.eventTypeCol}
                  onChange={(e) => setMapping({ ...mapping, eventTypeCol: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-blue-500"
                >
                  <option value="">-- Seleccionar columna --</option>
                  {fileHeaders.map(h => (
                    <option key={h} value={h}>{h}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">
                  Número A / Origen (Columna C) *
                </label>
                <select
                  value={mapping.sourceNumberCol}
                  onChange={(e) => setMapping({ ...mapping, sourceNumberCol: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-blue-500"
                >
                  <option value="">-- Seleccionar columna --</option>
                  {fileHeaders.map(h => (
                    <option key={h} value={h}>{h}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">
                  Número B / Destino (Columna D) *
                </label>
                <select
                  value={mapping.destinationNumberCol}
                  onChange={(e) => setMapping({ ...mapping, destinationNumberCol: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-blue-500"
                >
                  <option value="">-- Seleccionar columna --</option>
                  {fileHeaders.map(h => (
                    <option key={h} value={h}>{h}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">
                  Fecha (Columna E) *
                </label>
                <select
                  value={mapping.dateCol}
                  onChange={(e) => setMapping({ ...mapping, dateCol: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-blue-500"
                >
                  <option value="">-- Columna Fecha --</option>
                  {fileHeaders.map(h => (
                    <option key={h} value={h}>{h}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">
                  Hora (Columna F) *
                </label>
                <select
                  value={mapping.timeCol}
                  onChange={(e) => setMapping({ ...mapping, timeCol: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-blue-500"
                >
                  <option value="">-- Columna Hora --</option>
                  {fileHeaders.map(h => (
                    <option key={h} value={h}>{h}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">
                  Duración en Segundos (Columna G)
                </label>
                <select
                  value={mapping.durationCol}
                  onChange={(e) => setMapping({ ...mapping, durationCol: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-blue-500"
                >
                  <option value="">-- Columna Duración --</option>
                  {fileHeaders.map(h => (
                    <option key={h} value={h}>{h}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1 flex items-center space-x-1">
                  <Smartphone className="w-3 h-3 text-purple-400" />
                  <span>IMEI del Dispositivo (Columna H)</span>
                </label>
                <select
                  value={mapping.imeiCol}
                  onChange={(e) => setMapping({ ...mapping, imeiCol: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-blue-500"
                >
                  <option value="">-- Columna IMEI --</option>
                  {fileHeaders.map(h => (
                    <option key={h} value={h}>{h}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">
                  LATITUD (DMS o Decimal - Columna I)
                </label>
                <select
                  value={mapping.latitudeCol}
                  onChange={(e) => setMapping({ ...mapping, latitudeCol: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-blue-500"
                >
                  <option value="">-- Columna Latitud --</option>
                  {fileHeaders.map(h => (
                    <option key={h} value={h}>{h}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">
                  LONGITUD (DMS o Decimal - Columna J)
                </label>
                <select
                  value={mapping.longitudeCol}
                  onChange={(e) => setMapping({ ...mapping, longitudeCol: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-blue-500"
                >
                  <option value="">-- Columna Longitud --</option>
                  {fileHeaders.map(h => (
                    <option key={h} value={h}>{h}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">
                  Azimuth (Columna K)
                </label>
                <select
                  value={mapping.azimuthCol}
                  onChange={(e) => setMapping({ ...mapping, azimuthCol: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-blue-500"
                >
                  <option value="">-- Columna Azimuth --</option>
                  {fileHeaders.map(h => (
                    <option key={h} value={h}>{h}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">
                  País de Jurisdicción
                </label>
                <select
                  value={countryPrefix}
                  onChange={(e) => setCountryPrefix(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-blue-500"
                >
                  <option value="+52">México (+52 - Formato 10 dígitos)</option>
                  <option value="+54">Argentina (+54 / +549)</option>
                  <option value="+57">Colombia (+57)</option>
                  <option value="+56">Chile (+56)</option>
                  <option value="+34">España (+34)</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end pt-4 border-t border-slate-800 space-x-3">
              <button
                onClick={() => setStage('upload')}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium rounded-lg"
              >
                Volver
              </button>
              <button
                onClick={handleProcessSheet}
                disabled={isProcessing}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg shadow flex items-center space-x-2 disabled:opacity-50"
              >
                {isProcessing ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Depurando sábana...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle className="w-4 h-4" />
                    <span>Ejecutar Normalización e Ingesta</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Stage 3: Ingestion Completed Report */}
      {stage === 'completed' && validationReport && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-6">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full bg-emerald-950 border border-emerald-500/50 flex items-center justify-center text-emerald-400">
              <CheckCircle className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Sábana Telefónica Normalizada y Cargada Exitosamente</h2>
              <p className="text-xs text-slate-400">
                Se aplicó la categorización de columnas Tipo 2 y Color, aislación de espejos y conversión DMS a WGS84.
              </p>
            </div>
          </div>

          {/* Validation Metrics Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <div className="text-slate-500 text-[11px]">Total Procesados</div>
              <div className="text-lg font-bold font-mono text-white">{validationReport.totalRows}</div>
            </div>
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <div className="text-slate-500 text-[11px]">Llamadas de Voz</div>
              <div className="text-lg font-bold font-mono text-blue-400">{validationReport.voiceCount}</div>
            </div>
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <div className="text-slate-500 text-[11px]">Paquetes de Datos (APN)</div>
              <div className="text-lg font-bold font-mono text-amber-400">{validationReport.dataCount}</div>
            </div>
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <div className="text-slate-500 text-[11px]">Espejos Detectados (Img 3)</div>
              <div className="text-lg font-bold font-mono text-purple-400">{validationReport.mirrorCount}</div>
            </div>
          </div>

          {/* Technical Evidence Box */}
          <div className="bg-slate-950/70 border border-slate-800 rounded-lg p-4 space-y-2 text-xs">
            <div className="flex items-center space-x-2 text-blue-400 font-semibold">
              <ShieldCheck className="w-4 h-4" />
              <span>Constancia de Cadena de Custodia</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px] font-mono">
              <div>
                <span className="text-slate-500 block">Archivo de Procedencia:</span>
                <span className="text-slate-300">{validationReport.filename}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Identificador de Importación:</span>
                <span className="text-slate-300">{validationReport.importId}</span>
              </div>
              <div className="md:col-span-2">
                <span className="text-slate-500 block">Hash SHA-256 (Inalterable):</span>
                <span className="text-emerald-400 select-all">{validationReport.fileHashSha256}</span>
              </div>
            </div>
          </div>

          <div className="flex justify-between items-center pt-2">
            <button
              onClick={() => {
                setStage('upload');
                setSelectedFile(null);
                setValidationReport(null);
              }}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium rounded-lg"
            >
              Importar Otra Sábana
            </button>

            <span className="text-xs text-emerald-400 font-medium">
              ✓ Registros listos para análisis en Explorador, Mapa y Reportes
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
