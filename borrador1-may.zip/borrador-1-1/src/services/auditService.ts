import { collection, addDoc, getDocs, query, orderBy, limit } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { AuditAction, AuditLogEntry } from '../types';

export async function logAuditEvent(
  action: AuditAction,
  details: string,
  userEmail: string = 'analista.fiscalia@mpf.gob.ar',
  userId: string = 'user-current',
  caseId?: string
): Promise<void> {
  const entry: AuditLogEntry = {
    id: `audit-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    caseId,
    userId,
    userEmail,
    action,
    details,
    timestamp: new Date().toISOString()
  };

  try {
    const coll = collection(db, 'audit_logs');
    await addDoc(coll, entry);
  } catch (error) {
    // If offline or rule restricts, console error and keep in-memory
    console.warn('Registro de auditoría persistido localmente:', entry);
  }
}

export async function fetchRecentAuditLogs(): Promise<AuditLogEntry[]> {
  try {
    const coll = collection(db, 'audit_logs');
    const q = query(coll, orderBy('timestamp', 'desc'), limit(50));
    const snap = await getDocs(q);
    return snap.docs.map(d => d.data() as AuditLogEntry);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'audit_logs');
    return [];
  }
}
