import React, { useState, useMemo, useRef } from 'react';
import { 
  Network, 
  Printer, 
  Download, 
  ZoomIn, 
  ZoomOut, 
  Maximize2, 
  ShieldCheck, 
  Smartphone, 
  PhoneCall, 
  MessageSquare, 
  Layers, 
  Globe,
  QrCode,
  Calendar,
  Filter
} from 'lucide-react';
import { NormalizedCDR, UserProfile, PhoneTag } from '../../types';
import { logAuditEvent } from '../../services/auditService';

interface NetworkLinkDiagramViewProps {
  records: NormalizedCDR[];
  currentUser: UserProfile;
  targetNumberProp?: string;
  phoneTags?: Record<string, PhoneTag>;
}

export const NetworkLinkDiagramView: React.FC<NetworkLinkDiagramViewProps> = ({
  records,
  currentUser,
  targetNumberProp,
  phoneTags
}) => {
  const [targetNumber, setTargetNumber] = useState<string>(
    targetNumberProp || '6271218386'
  );

  const getContactTag = (num: string): PhoneTag | undefined => {
    if (!phoneTags) return undefined;
    const clean = num.replace(/[^0-9]/g, '');
    const short10 = clean.slice(-10);
    return phoneTags[num] || phoneTags[clean] || (short10 ? phoneTags[short10] : undefined);
  };
  const [viewMode, setViewMode] = useState<'uayc_bilateral' | 'constellation'>('uayc_bilateral');
  const [showDataStream, setShowDataStream] = useState<boolean>(true);
  const diagramRef = useRef<HTMLDivElement>(null);

  // Filter records relevant to this target
  const targetRecords = useMemo(() => {
    return records.filter(r => 
      r.targetPhone.includes(targetNumber) ||
      r.sourceNumber.includes(targetNumber) ||
      r.destinationNumber.includes(targetNumber) ||
      r.rawSourceNumber.includes(targetNumber) ||
      r.rawDestinationNumber.includes(targetNumber)
    );
  }, [records, targetNumber]);

  // Extract separate call/message events by contact
  const networkData = useMemo(() => {
    // 1. Group events by counterpart
    const contactsMap = new Map<string, {
      name: string;
      outgoingCalls: { date: string; time: string; dur?: number; type: string }[];
      incomingCalls: { date: string; time: string; dur?: number; type: string }[];
      incomingMessages: { date: string; time: string; type: string }[];
      outgoingMessages: { date: string; time: string; type: string }[];
      isSpecialService?: boolean;
    }>();

    // Data packets stream
    const dataStream: { date: string; time: string; dur: number }[] = [];

    targetRecords.forEach(r => {
      if (r.eventType === 'DATOS' || r.destinationNumber.includes('itelcel') || r.rawDestinationNumber.includes('itelcel')) {
        dataStream.push({
          date: r.rawDate || r.timestamp.substring(0, 10),
          time: r.rawTime || r.timestamp.substring(11, 19),
          dur: r.durationSeconds
        });
        return;
      }

      // Determine counterpart
      let counterpart = '';
      let isOutgoing = false;

      if (r.rawSourceNumber.includes(targetNumber)) {
        counterpart = r.rawDestinationNumber;
        isOutgoing = true;
      } else {
        counterpart = r.rawSourceNumber;
        isOutgoing = false;
      }

      if (!counterpart || counterpart.includes(targetNumber)) {
        counterpart = r.destinationNumber.replace('+52', '');
      }

      const existing = contactsMap.get(counterpart) || {
        name: counterpart,
        outgoingCalls: [],
        incomingCalls: [],
        incomingMessages: [],
        outgoingMessages: [],
        isSpecialService: ['Telcel', 'TELCEL', 'UNOTV.COM', 'BUZON', '142323', '47288'].includes(counterpart)
      };

      const dt = r.rawDate || r.timestamp.substring(0, 10);
      const tm = r.rawTime || r.timestamp.substring(11, 19);

      if (r.eventType === 'LLAMADA_SALIENTE') {
        existing.outgoingCalls.push({ date: dt, time: tm, dur: r.durationSeconds, type: 'LL-S' });
      } else if (r.eventType === 'LLAMADA_ENTRANTE') {
        existing.incomingCalls.push({ date: dt, time: tm, dur: r.durationSeconds, type: 'LL-E' });
      } else if (r.eventType === 'SMS_ENTRANTE') {
        existing.incomingMessages.push({ date: dt, time: tm, type: 'M-E' });
      } else if (r.eventType === 'SMS_SALIENTE') {
        existing.outgoingMessages.push({ date: dt, time: tm, type: 'M-S' });
      } else if (r.isMirror) {
        existing.outgoingCalls.push({ date: dt, time: tm, dur: r.durationSeconds, type: 'LL-Transito' });
      }

      contactsMap.set(counterpart, existing);
    });

    // Left side: Frequent contacts with 2-way communication or multiple outgoing calls
    // (Matching Image 1: 6271134588, 6271474227, 6271449752, 6271148264, 6271231031, 6271030501, 6271430295)
    const leftContacts: typeof contactsMap extends Map<string, infer V> ? V[] : never = [];
    const rightContacts: typeof contactsMap extends Map<string, infer V> ? V[] : never = [];

    contactsMap.forEach((val) => {
      if (val.outgoingCalls.length > 0 && !val.isSpecialService) {
        leftContacts.push(val);
      } else {
        rightContacts.push(val);
      }
    });

    // Sort left contacts by total activity
    leftContacts.sort((a, b) => 
      (b.outgoingCalls.length + b.incomingCalls.length) - (a.outgoingCalls.length + a.incomingCalls.length)
    );

    return { leftContacts, rightContacts, dataStream };
  }, [targetRecords, targetNumber]);

  const handlePrint = () => {
    logAuditEvent(
      'EXPORT_REPORT',
      `Impresión pericial de Red de Vínculos UAYC para línea ${targetNumber}`,
      currentUser.email,
      currentUser.uid
    );
    window.print();
  };

  return (
    <div className="space-y-4">
      {/* Top Action Bar (hidden in print) */}
      <div className="no-print bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 shadow-sm">
        <div>
          <div className="flex items-center space-x-2">
            <Network className="w-5 h-5 text-amber-400" />
            <h1 className="text-lg font-bold text-white tracking-tight">
              Red de Vínculos de Comunicación (Dictamen Pericial Final UAYC)
            </h1>
          </div>
          <p className="text-xs text-slate-400">
            Diagrama forense bilateral institucional fiel al formato de la Unidad de Análisis y Criminalística.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* View mode toggle */}
          <div className="bg-slate-950 p-1 rounded-lg border border-slate-800 flex items-center space-x-1 text-xs">
            <button
              onClick={() => setViewMode('uayc_bilateral')}
              className={`px-3 py-1 rounded-md font-medium transition ${
                viewMode === 'uayc_bilateral' 
                  ? 'bg-blue-600 text-white shadow' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Diagrama Formal UAYC (Imagen 1)
            </button>
            <button
              onClick={() => setViewMode('constellation')}
              className={`px-3 py-1 rounded-md font-medium transition ${
                viewMode === 'constellation' 
                  ? 'bg-blue-600 text-white shadow' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Grafo Radial y Flujo Datos (Imagen 2)
            </button>
          </div>

          <button
            onClick={handlePrint}
            className="px-4 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-semibold rounded-lg text-xs flex items-center space-x-1.5 shadow transition"
          >
            <Printer className="w-4 h-4" />
            <span>Imprimir Lámina Pericial (Página 1 de 1)</span>
          </button>
        </div>
      </div>

      {/* Target and Date Range Bar (no-print) */}
      <div className="no-print bg-slate-900 border border-slate-800 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-3">
          <span className="text-slate-400 font-medium">Línea Telefónica Objetivo:</span>
          <input
            type="text"
            value={targetNumber}
            onChange={(e) => setTargetNumber(e.target.value)}
            className="bg-slate-950 border border-blue-500/50 rounded-lg px-3 py-1 font-mono font-bold text-blue-300 focus:outline-none focus:border-blue-400"
          />
          <button
            onClick={() => setTargetNumber('6271218386')}
            className="text-[11px] text-amber-400 hover:underline"
          >
            Cargar línea exacta de imagen: 6271218386
          </button>
        </div>

        <div className="text-[11px] text-slate-400 flex items-center space-x-2">
          <Calendar className="w-3.5 h-3.5 text-blue-400" />
          <span>Período pericial: <strong>22/01/2025 al 31/01/2025</strong></span>
        </div>
      </div>

      {/* VIEW 1: Formal Bilateral UAYC Diagram (Matching Image 1) */}
      {viewMode === 'uayc_bilateral' && (
        <div 
          ref={diagramRef}
          className="bg-white text-slate-900 border border-slate-300 rounded-xl shadow-2xl p-6 md:p-8 max-w-[1200px] mx-auto min-h-[850px] flex flex-col justify-between font-sans select-none print:border-none print:shadow-none print:p-0 print:m-0"
          style={{ width: '100%', aspectRatio: '1.414' }}
        >
          {/* Official Document Border Header */}
          <div className="border border-slate-700 p-2 text-center rounded-sm bg-slate-50/50">
            <h2 className="text-xs md:text-sm font-bold uppercase tracking-tight text-slate-900">
              Red de vínculos de comunicación en llamadas y mensajes de texto, de la línea telefónica {targetNumber}
              <br />
              del día 22/01/2025 al 31/01/2025.
            </h2>
          </div>

          {/* Central Bilateral Network Diagram */}
          <div className="relative flex-1 flex items-center justify-between my-4 px-2">
            {/* LEFT COLUMN: Interlocutors with 2-way calls & outgoing communications */}
            <div className="w-[44%] space-y-3.5 z-10">
              {networkData.leftContacts.slice(0, 7).map((contact) => {
                const tag = getContactTag(contact.name);
                return (
                  <div key={contact.name} className="flex items-center space-x-2 text-[10px] leading-tight">
                    {/* Phone Icon & Label */}
                    <div className="flex flex-col items-center shrink-0 w-18 text-center">
                      <div className="w-6 h-6 rounded bg-amber-100 border border-amber-600 flex items-center justify-center text-amber-800 shadow-xs">
                        <Smartphone className="w-3.5 h-3.5" />
                      </div>
                      <span className="font-mono font-bold text-[9px] text-slate-900 mt-0.5 truncate max-w-[72px]">
                        {contact.name}
                      </span>
                      {tag && (
                        <span 
                          className={`text-[8px] font-sans font-bold px-1 py-0.5 rounded mt-0.5 truncate max-w-[72px] border ${
                            tag.category === 'INVESTIGACION' ? 'bg-rose-100 text-rose-800 border-rose-300' :
                            tag.category === 'FAMILIAR' ? 'bg-blue-100 text-blue-800 border-blue-300' :
                            tag.category === 'TRANSPORTE' ? 'bg-emerald-100 text-emerald-800 border-emerald-300' :
                            tag.category === 'COMERCIO' ? 'bg-amber-100 text-amber-800 border-amber-300' :
                            tag.category === 'LEGAL' ? 'bg-purple-100 text-purple-800 border-purple-300' :
                            'bg-slate-100 text-slate-800 border-slate-300'
                          }`} 
                          title={`${tag.alias} (${tag.category})`}
                        >
                          🏷️ {tag.alias}
                        </span>
                      )}
                    </div>

                    {/* Call and Message Event Lists (Blue for incoming, Red for outgoing) */}
                    <div className="flex-1 bg-slate-50 border border-slate-200 rounded p-1.5 space-y-1 font-mono text-[8.5px] max-h-24 overflow-y-auto">
                      {/* Outgoing Calls (Red) */}
                      {contact.outgoingCalls.length > 0 && (
                        <div className="text-rose-700 font-semibold space-y-0.5 border-l-2 border-rose-500 pl-1">
                          {contact.outgoingCalls.map((c, i) => (
                            <div key={i} className="truncate">
                              {c.type} {c.date} {c.time}
                            </div>
                          ))}
                        </div>
                      )}
                      {/* Incoming Calls & Messages (Blue) */}
                      {(contact.incomingCalls.length > 0 || contact.incomingMessages.length > 0) && (
                        <div className="text-blue-700 font-semibold space-y-0.5 border-l-2 border-blue-500 pl-1">
                          {contact.incomingCalls.map((c, i) => (
                            <div key={i} className="truncate">
                              {c.type} {c.date} {c.time}
                            </div>
                          ))}
                          {contact.incomingMessages.map((m, i) => (
                            <div key={i} className="truncate">
                              {m.type} {m.date} {m.time}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Visual Connection Lines to Center */}
                    <div className="w-8 flex flex-col justify-center space-y-1">
                      {contact.outgoingCalls.length > 0 && (
                        <div className="h-0.5 bg-rose-500 w-full relative">
                          <span className="absolute -left-1 -top-1 border-t-4 border-t-transparent border-b-4 border-b-transparent border-r-4 border-r-rose-500" />
                        </div>
                      )}
                      {(contact.incomingCalls.length > 0 || contact.incomingMessages.length > 0) && (
                        <div className="h-0.5 bg-blue-600 w-full relative">
                          <span className="absolute -right-1 -top-1 border-t-4 border-t-transparent border-b-4 border-b-transparent border-l-4 border-l-blue-600" />
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* CENTER: Investigated Target Phone Node */}
            <div className="flex flex-col items-center justify-center shrink-0 z-20 px-3">
              <div className="relative">
                <div className="w-20 h-20 rounded-full bg-blue-100 border-2 border-blue-400 flex items-center justify-center shadow-lg">
                  <div className="w-14 h-14 rounded-full bg-white border border-blue-300 flex items-center justify-center text-blue-900">
                    <Smartphone className="w-8 h-8 text-slate-800" />
                  </div>
                </div>
              </div>
              <div className="font-mono font-bold text-xs text-slate-900 mt-2 px-2.5 py-0.5 rounded bg-blue-50 border border-blue-200 shadow-xs text-center">
                <div>{targetNumber}</div>
                {getContactTag(targetNumber) && (
                  <div className="text-[9px] font-sans font-bold text-blue-700">
                    🏷️ {getContactTag(targetNumber)?.alias}
                  </div>
                )}
              </div>
              <span className="text-[9px] text-blue-800 font-semibold uppercase tracking-wider mt-0.5">
                Línea Investigada
              </span>
            </div>

            {/* RIGHT COLUMN: Incoming Contacts, Short Codes, and Services */}
            <div className="w-[44%] space-y-3 z-10">
              {networkData.rightContacts.slice(0, 8).map((contact) => {
                const tag = getContactTag(contact.name);
                return (
                  <div key={contact.name} className="flex items-center space-x-2 text-[10px] leading-tight flex-row-reverse">
                    {/* Phone / Service Icon & Label */}
                    <div className="flex flex-col items-center shrink-0 w-18 text-center">
                      <div className="w-6 h-6 rounded bg-amber-100 border border-amber-600 flex items-center justify-center text-amber-800 shadow-xs">
                        <Smartphone className="w-3.5 h-3.5" />
                      </div>
                      <span className="font-mono font-bold text-[9px] text-slate-900 mt-0.5 truncate max-w-[72px]" title={contact.name}>
                        {contact.name}
                      </span>
                      {tag && (
                        <span 
                          className={`text-[8px] font-sans font-bold px-1 py-0.5 rounded mt-0.5 truncate max-w-[72px] border ${
                            tag.category === 'INVESTIGACION' ? 'bg-rose-100 text-rose-800 border-rose-300' :
                            tag.category === 'FAMILIAR' ? 'bg-blue-100 text-blue-800 border-blue-300' :
                            tag.category === 'TRANSPORTE' ? 'bg-emerald-100 text-emerald-800 border-emerald-300' :
                            tag.category === 'COMERCIO' ? 'bg-amber-100 text-amber-800 border-amber-300' :
                            tag.category === 'LEGAL' ? 'bg-purple-100 text-purple-800 border-purple-300' :
                            'bg-slate-100 text-slate-800 border-slate-300'
                          }`} 
                          title={`${tag.alias} (${tag.category})`}
                        >
                          🏷️ {tag.alias}
                        </span>
                      )}
                    </div>

                    {/* Event list (predominantly Blue incoming) */}
                    <div className="flex-1 bg-slate-50 border border-slate-200 rounded p-1.5 space-y-0.5 font-mono text-[8.5px] max-h-24 overflow-y-auto text-blue-700 font-semibold border-r-2 border-blue-500 pr-1">
                      {contact.incomingCalls.map((c, i) => (
                        <div key={i} className="truncate">
                          {c.type} {c.date} {c.time}
                        </div>
                      ))}
                      {contact.incomingMessages.map((m, i) => (
                        <div key={i} className="truncate">
                          {m.type} {m.date} {m.time}
                        </div>
                      ))}
                    </div>

                    {/* Visual Connection Line */}
                    <div className="w-8 flex flex-col justify-center">
                      <div className="h-0.5 bg-blue-600 w-full relative">
                        <span className="absolute -left-1 -top-1 border-t-4 border-t-transparent border-b-4 border-b-transparent border-r-4 border-r-blue-600" />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Bottom Bar: Simbología (Left) and Official UAYC Seal (Right) */}
          <div className="flex items-end justify-between pt-2 border-t border-slate-300 text-[10px]">
            {/* Simbología Box (matching Image 1) */}
            <div className="border border-slate-700 p-2.5 rounded-sm bg-slate-50 text-[9.5px] space-y-1 w-52 leading-tight">
              <strong className="block text-slate-900 border-b border-slate-300 pb-0.5 uppercase tracking-wider text-[10px]">
                Simbología
              </strong>
              <div className="space-y-0.5 font-sans">
                <div><span className="text-rose-600 font-bold">Rojo:</span> Saliente</div>
                <div><span className="text-blue-600 font-bold">Azul:</span> Entrante</div>
                <div><strong>LL:</strong> Llamada Entrante</div>
                <div><strong>LL-S:</strong> Llamada Saliente</div>
                <div><strong>M-E:</strong> Mensaje Entrante</div>
              </div>
              <div className="pt-1 border-t border-slate-300 text-[9px] text-slate-600">
                <span>Ejemplo: LL-E, Fecha, Hora</span>
                <div className="flex items-center space-x-1 mt-0.5 font-mono text-blue-700 font-bold">
                  <span className="w-3 h-0.5 bg-blue-600 inline-block" />
                  <span>22/01/2025 11:44:49</span>
                </div>
              </div>
            </div>

            {/* Official UAYC Seal & QR Code */}
            <div className="flex items-center space-x-4">
              <div className="flex flex-col items-center">
                <div className="w-14 h-14 rounded-full border-2 border-slate-800 p-1 flex flex-col items-center justify-center text-center">
                  <span className="text-[11px] font-black tracking-widest text-blue-900">UAYC</span>
                  <span className="text-[6.5px] font-semibold text-slate-600 uppercase">Criminalística</span>
                </div>
                <span className="text-[8px] font-mono font-bold text-slate-700 mt-0.5">MPF CHIHUAHUA</span>
              </div>

              <div className="flex flex-col items-center">
                <QrCode className="w-10 h-10 text-slate-800" />
                <span className="font-mono text-[9px] font-bold text-slate-800">A07</span>
              </div>
            </div>
          </div>

          {/* Footer Pagination */}
          <div className="text-center text-[10px] text-slate-500 pt-1 font-sans">
            Página 1 de 1
          </div>
        </div>
      )}

      {/* VIEW 2: Radial Constellation & Data Stream (Matching Image 2) */}
      {viewMode === 'constellation' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center space-x-2">
              <Network className="w-4 h-4 text-amber-400" />
              <span>Constelación de Vínculos y Flujo de Paquetes de Datos IP</span>
            </h3>
            <button
              onClick={() => setShowDataStream(!showDataStream)}
              className="text-xs text-blue-400 hover:underline"
            >
              {showDataStream ? 'Ocultar Flujo de Datos' : 'Mostrar Flujo de Datos (Internet)'}
            </button>
          </div>

          {/* Top Data Stream (matching top of Image 2) */}
          {showDataStream && networkData.dataStream.length > 0 && (
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-3 space-y-1.5">
              <div className="flex items-center justify-between text-xs text-amber-400 font-semibold border-b border-slate-800 pb-1">
                <span className="flex items-center space-x-1.5">
                  <Globe className="w-3.5 h-3.5" />
                  <span>Flujo Cronológico de Sesiones de Datos (internet.itelcel.com)</span>
                </span>
                <span className="font-mono text-[10px] text-slate-400">
                  {networkData.dataStream.length} sesiones IP
                </span>
              </div>
              <div className="max-h-40 overflow-y-auto font-mono text-[10px] text-slate-300 space-y-0.5 pr-2">
                {networkData.dataStream.map((d, idx) => (
                  <div key={idx} className="flex justify-between hover:bg-slate-900 px-1 py-0.5 rounded">
                    <span>Datos {d.date} {d.time}</span>
                    <span className="text-amber-400 font-bold">{d.dur} seg</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Interactive Radial Graph */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-6 min-h-[480px] flex items-center justify-center relative overflow-hidden">
            {/* Center Node */}
            <div className="relative z-10 flex flex-col items-center">
              <div className="w-20 h-20 rounded-full bg-blue-600/30 border-2 border-blue-400 flex items-center justify-center text-white shadow-xl shadow-blue-900/50">
                <Smartphone className="w-8 h-8 text-blue-300" />
              </div>
              <span className="font-mono font-bold text-xs text-white mt-2 bg-slate-900 px-2 py-0.5 rounded border border-blue-500/50">
                {targetNumber}
              </span>
            </div>

            {/* Orbiting Contact Nodes */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              {[...networkData.leftContacts, ...networkData.rightContacts].slice(0, 14).map((c, i, arr) => {
                const angle = (i / arr.length) * 2 * Math.PI;
                const radius = 170;
                const x = Math.cos(angle) * radius;
                const y = Math.sin(angle) * radius;
                const hasOutgoing = c.outgoingCalls.length > 0;

                const tag = getContactTag(c.name);

                return (
                  <div
                    key={c.name}
                    className="absolute pointer-events-auto transform -translate-x-1/2 -translate-y-1/2 flex flex-col items-center group cursor-pointer"
                    style={{ left: `calc(50% + ${x}px)`, top: `calc(50% + ${y}px)` }}
                  >
                    <div className={`w-9 h-9 rounded-full border-2 flex items-center justify-center shadow-md transition ${
                      hasOutgoing ? 'bg-rose-950/80 border-rose-500 text-rose-300' : 'bg-blue-950/80 border-blue-500 text-blue-300'
                    }`}>
                      <Smartphone className="w-4 h-4" />
                    </div>
                    <span className="font-mono text-[9px] font-bold text-slate-300 bg-slate-900/90 px-1 rounded mt-1 shadow truncate max-w-[80px]">
                      {c.name}
                    </span>
                    {tag && (
                      <span className="text-[8px] font-sans font-bold text-amber-300 bg-amber-950/90 px-1 rounded border border-amber-800/80 mt-0.5 truncate max-w-[80px]">
                        🏷️ {tag.alias}
                      </span>
                    )}

                    {/* Hover Card */}
                    <div className="opacity-0 group-hover:opacity-100 transition absolute bottom-full mb-2 bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-[10px] text-white shadow-xl whitespace-nowrap z-30 pointer-events-none">
                      <div className="font-bold flex items-center space-x-1.5">
                        <span>{c.name}</span>
                        {tag && (
                          <span className="bg-amber-900/60 text-amber-300 px-1.5 py-0.2 rounded font-sans text-[9px] border border-amber-700">
                            🏷️ {tag.alias} ({tag.category})
                          </span>
                        )}
                      </div>
                      <div className="text-rose-400 mt-1">Salientes: {c.outgoingCalls.length}</div>
                      <div className="text-blue-400">Entrantes: {c.incomingCalls.length + c.incomingMessages.length}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
