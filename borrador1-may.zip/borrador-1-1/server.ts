import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import crypto from 'crypto';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '100mb' }));
  app.use(express.urlencoded({ extended: true, limit: '100mb' }));

  // Health check endpoint
  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      service: 'analisis-telefonico-judicial-backend',
      environment: process.env.NODE_ENV || 'development',
      timestamp: new Date().toISOString()
    });
  });

  // Server-side cryptographic hash computation for forensic evidence
  app.post('/api/forensic/hash', (req, res) => {
    try {
      const { content, encoding } = req.body;
      if (!content) {
        return res.status(400).json({ error: 'Falta el contenido del archivo para calcular el hash' });
      }

      const buffer = Buffer.from(content, encoding === 'base64' ? 'base64' : 'utf-8');
      const hashSha256 = crypto.createHash('sha256').update(buffer).digest('hex');
      const hashMd5 = crypto.createHash('md5').update(buffer).digest('hex');

      return res.json({
        sha256: hashSha256,
        md5: hashMd5,
        byteLength: buffer.length,
        timestamp: new Date().toISOString()
      });
    } catch (err: unknown) {
      console.error('Error calculando hash forense:', err);
      const msg = err instanceof Error ? err.message : String(err);
      return res.status(500).json({ error: 'Error interno al procesar el hash', details: msg });
    }
  });

  // Retention & Legal Compliance configuration metadata endpoint
  app.get('/api/compliance/retention-policy', (_req, res) => {
    res.json({
      legalFramework: 'Código Procesal Penal - Preservación de Evidencia Digital',
      defaultRetentionYears: 5,
      status: 'Propuesta preliminar sujeta a aprobación de Fiscalía General',
      chainOfCustodyStandard: 'ISO/IEC 27037:2012 Directrices para la identificación, recolección y preservación de evidencia digital',
      aiProhibitionNotice: 'Estricta prohibición de envío de datos sensibles a modelos de lenguaje o terceros sin orden judicial expresa',
      immutableAuditEnabled: true
    });
  });

  // Geomatrix status check (Institutional integration stub)
  app.get('/api/integrations/geomatrix/status', (_req, res) => {
    res.json({
      integration: 'Geomatrix',
      status: 'disabled',
      configured: false,
      message: 'Módulo Geomatrix formalmente deshabilitado. Se requiere convenio interinstitucional, credenciales seguras y especificación de API autorizada.',
      requiresCredentials: true,
      authLevel: 'SECRET_RESTRICTED'
    });
  });

  // Vite development middleware or static production serve
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Análisis Telefónico] Servidor institucional escuchando en http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Fallo fatal al iniciar el servidor:', err);
  process.exit(1);
});
