export type UserRole = 'admin' | 'analista' | 'consulta';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  role: UserRole;
  department: string;
  createdAt: string;
}

export type CaseStatus = 'abierto' | 'en_analisis' | 'cerrado' | 'archivado';

export interface ProsecutionCase {
  id: string;
  caseNumber: string;
  title: string;
  description: string;
  fiscalUnit: string;
  leadProsecutor: string;
  status: CaseStatus;
  assignedUsers: string[];
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  targetNumbers: string[];
  phoneTags?: Record<string, PhoneTag>;
}

export type PhoneTagCategory = 'FAMILIAR' | 'INVESTIGACION' | 'COMERCIO' | 'TRANSPORTE' | 'LEGAL' | 'OTRO';

export interface PhoneTag {
  phoneNumber: string;
  alias: string;
  category: PhoneTagCategory;
  notes?: string;
  updatedAt: string;
  updatedBy: string;
}

export type CDREventType = 
  | 'LLAMADA_SALIENTE'
  | 'LLAMADA_ENTRANTE'
  | 'DATOS'
  | 'SMS_SALIENTE'
  | 'SMS_ENTRANTE'
  | 'VOZ_TRANSITO'
  | 'VOZ_TRANSFER'
  | 'OTRO';

export type CDRRecordStatus = 'VALID' | 'WARNING' | 'REJECTED';

export interface NormalizedCDR {
  id: string;
  importId: string;
  rowNumber: number;
  caseId: string;
  targetPhone: string;
  sourceNumber: string; // Número A
  rawSourceNumber: string;
  destinationNumber: string; // Número B (o internet.itelcel.com)
  rawDestinationNumber: string;
  timestamp: string; // ISO-8601
  rawDate: string;
  rawTime: string;
  rawTimestamp: string;
  eventType: CDREventType;
  rawEventType: string;
  tipo2: string; // LL-E, LL-S, Internet, Espejo (Tránsito), Espejo (Transfer), etc.
  colorTag: string; // Azul, Verde, Amarillo, Naranja, Morado
  durationSeconds: number;
  rawDuration: string;
  imei: string | null;
  rawImei: string;
  cellId: string;
  rawCellId: string;
  operator: string;
  latitude: number | null; // Decimal degrees WGS84
  longitude: number | null; // Decimal degrees WGS84
  rawLatitude?: string; // e.g. 28°46'52"N
  rawLongitude?: string; // e.g. 106°10'8"W
  azimuth: number | null; // 0-360 degrees
  rawAzimuth?: string;
  sourceFile: string;
  status: CDRRecordStatus;
  validationNotes: string[];
  transformations: string[];
  isDuplicate?: boolean;
  isMirror?: boolean; // Espejo (Voz Tránsito o Transferencia)
  mirrorType?: 'NONE' | 'TRANSITO' | 'TRANSFER';
}

export interface ColumnMapping {
  targetPhoneCol: string; // Teléfono
  eventTypeCol: string; // Tipo
  sourceNumberCol: string; // Número A
  destinationNumberCol: string; // Número B
  dateCol: string; // Fecha
  timeCol: string; // Hora
  timestampCol: string; // Fecha y Hora combinada (si existe)
  durationCol: string; // Duracion
  imeiCol: string; // IMEI
  latitudeCol: string; // LATITUD o Ubicación Geográfica
  longitudeCol: string; // LONGITUD
  azimuthCol: string; // Azimuth
  cellIdCol: string;
  operatorCol: string;
}

export interface ImportValidationReport {
  importId: string;
  caseId: string;
  filename: string;
  fileHashSha256: string;
  fileSizeBytes: number;
  totalRows: number;
  validCount: number;
  rejectedCount: number;
  incompleteCount: number;
  duplicateCount: number;
  mirrorCount: number; // Conteo de registros espejos (Tránsito/Transfer)
  dataCount: number; // Conteo de conexiones a Internet/Datos
  voiceCount: number; // Conteo de llamadas de voz
  operatorDetected: string;
  countryPrefix: string;
  timezone: string;
  importedAt: string;
  detectedTargets: string[];
  rejectionReasons: { [reason: string]: number };
}

export interface CellTowerSummary {
  cellId: string;
  operator: string;
  latitude: number;
  longitude: number;
  azimuth: number | null;
  totalEvents: number;
  firstSeen: string;
  lastSeen: string;
  uniqueContacts: number;
  incomingCount: number;
  outgoingCount: number;
  dataCount: number;
  events: NormalizedCDR[];
}

export interface FrequentContact {
  phoneNumber: string;
  normalizedNumber: string;
  totalEvents: number;
  callCount: number;
  smsCount: number;
  dataCount: number;
  totalDurationSeconds: number;
  incomingCount: number;
  outgoingCount: number;
  firstEvent: string;
  lastEvent: string;
  associatedCells: string[];
  associatedImeis: string[];
  alias?: string;
  category?: PhoneTagCategory;
}

export interface AnalysisFilterState {
  targetNumber: string;
  selectedContact: string;
  direction: 'TODOS' | 'ENTRANTE' | 'SALIENTE';
  eventType: 'TODOS' | 'LLAMADAS' | 'SMS' | 'DATOS' | 'ESPEJOS';
  mirrorFilter: 'EXCLUDE_MIRRORS' | 'INCLUDE_ALL' | 'ONLY_MIRRORS';
  imeiFilter: string;
  startDate: string;
  endDate: string;
  startHour: number;
  endHour: number;
  operator: string;
  cellId: string;
  minDuration: number;
  searchTerm: string;
}

export type AuditAction = 
  | 'LOGIN'
  | 'LOGOUT'
  | 'CASE_CREATE'
  | 'CASE_UPDATE'
  | 'FILE_IMPORT'
  | 'FILTER_QUERY'
  | 'EXPORT_CSV'
  | 'EXPORT_REPORT'
  | 'VIEW_ANTENNA'
  | 'OSINT_QUERY'
  | 'TAG_PHONE';

export interface AuditLogEntry {
  id: string;
  caseId?: string;
  userId: string;
  userEmail: string;
  action: AuditAction;
  details: string;
  timestamp: string;
}
