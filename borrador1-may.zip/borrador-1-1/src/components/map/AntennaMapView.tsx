import React, { useEffect, useRef, useState, useMemo } from 'react';
import L from 'leaflet';
import { 
  MapPin, 
  Radio, 
  Play, 
  Pause, 
  RotateCcw, 
  Clock, 
  AlertTriangle, 
  Compass, 
  X, 
  Layers,
  PhoneCall,
  ShieldAlert
} from 'lucide-react';
import { NormalizedCDR, CellTowerSummary } from '../../types';
import { computeCellTowerSummaries, findLastRecordedAntenna } from '../../services/analysisEngine';

interface AntennaMapViewProps {
  records: NormalizedCDR[];
}

export const AntennaMapView: React.FC<AntennaMapViewProps> = ({ records }) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);
  const sequenceLayerRef = useRef<L.LayerGroup | null>(null);

  const [selectedTower, setSelectedTower] = useState<CellTowerSummary | null>(null);
  const [isPlayingSequence, setIsPlayingSequence] = useState<boolean>(false);
  const [sequenceStep, setSequenceStep] = useState<number>(0);
  const [showAzimuthSectors, setShowAzimuthSectors] = useState<boolean>(true);

  // Compute cell summaries with coordinates
  const towers = useMemo(() => {
    return computeCellTowerSummaries(records);
  }, [records]);

  // Last recorded antenna
  const lastRecorded = useMemo(() => {
    return findLastRecordedAntenna(records);
  }, [records]);

  // Chronological chronological sequence of events with valid coordinates
  const chronologicalEvents = useMemo(() => {
    return records
      .filter(r => r.status !== 'REJECTED' && r.latitude !== null && r.longitude !== null)
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  }, [records]);

  // Calculate max events for sizing
  const maxEvents = useMemo(() => {
    return Math.max(...towers.map(t => t.totalEvents), 1);
  }, [towers]);

  // Initialize Leaflet Map
  useEffect(() => {
    if (!mapContainerRef.current) return;
    if (mapInstanceRef.current) return;

    // Default center (e.g. Buenos Aires or first tower)
    const initialLat = towers[0]?.latitude || -34.6037;
    const initialLng = towers[0]?.longitude || -58.3816;

    const map = L.map(mapContainerRef.current, {
      center: [initialLat, initialLng],
      zoom: 12,
      attributionControl: false
    });

    // Dark / CartoDB tiles fitting the judicial interface
    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
      maxZoom: 19,
      subdomains: 'abcd'
    }).addTo(map);

    L.control.attribution({ position: 'bottomright', prefix: 'CartoDB / OpenStreetMap' }).addTo(map);

    markersLayerRef.current = L.layerGroup().addTo(map);
    sequenceLayerRef.current = L.layerGroup().addTo(map);

    mapInstanceRef.current = map;

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // Update Markers & Azimuth sectors
  useEffect(() => {
    const map = mapInstanceRef.current;
    const layer = markersLayerRef.current;
    if (!map || !layer) return;

    layer.clearLayers();

    if (towers.length === 0) return;

    const bounds = L.latLngBounds([]);

    towers.forEach(tower => {
      const isSelected = selectedTower?.cellId === tower.cellId;
      const isLatest = lastRecorded?.cellId === tower.cellId;

      bounds.extend([tower.latitude, tower.longitude]);

      // Calculate radius based on event frequency (min 8px, max 24px)
      const ratio = tower.totalEvents / maxEvents;
      const radius = 8 + ratio * 16;

      // Color scheme based on frequency & status
      let fillColor = '#3b82f6'; // blue
      if (ratio > 0.6) fillColor = '#ef4444'; // red high frequency
      else if (ratio > 0.3) fillColor = '#f59e0b'; // amber
      if (isLatest) fillColor = '#10b981'; // green latest

      // Draw illustrative azimuth sector cone if azimuth is available
      if (showAzimuthSectors && tower.azimuth !== null) {
        const azRad = (tower.azimuth * Math.PI) / 180;
        const spreadRad = (60 * Math.PI) / 180; // 60-degree beam width illustrative sector
        const beamDist = 0.007; // approx 700 meters visually

        const p1: [number, number] = [tower.latitude, tower.longitude];
        const p2: [number, number] = [
          tower.latitude + beamDist * Math.cos(azRad - spreadRad / 2),
          tower.longitude + beamDist * Math.sin(azRad - spreadRad / 2)
        ];
        const p3: [number, number] = [
          tower.latitude + beamDist * Math.cos(azRad + spreadRad / 2),
          tower.longitude + beamDist * Math.sin(azRad + spreadRad / 2)
        ];

        const sector = L.polygon([p1, p2, p3], {
          color: fillColor,
          weight: 1.5,
          opacity: 0.8,
          fillColor: fillColor,
          fillOpacity: isSelected ? 0.45 : 0.2
        });

        sector.bindTooltip(`Sector Azimut ${tower.azimuth}° (Ilustrativo)`, { sticky: true });
        layer.addLayer(sector);
      }

      // Circle Marker for Antenna Tower Site
      const circle = L.circleMarker([tower.latitude, tower.longitude], {
        radius,
        fillColor,
        color: isSelected ? '#ffffff' : '#0f172a',
        weight: isSelected ? 3 : 1.5,
        opacity: 1,
        fillOpacity: 0.9
      });

      circle.bindTooltip(
        `<div class="p-1 font-sans text-xs">
          <strong>${tower.cellId}</strong> (${tower.operator})<br/>
          Eventos: <strong>${tower.totalEvents}</strong><br/>
          Azimut: <strong>${tower.azimuth !== null ? tower.azimuth + '°' : 'No disponible'}</strong>
        </div>`,
        { sticky: true }
      );

      circle.on('click', () => {
        setSelectedTower(tower);
      });

      layer.addLayer(circle);
    });

    if (bounds.isValid()) {
      map.fitBounds(bounds, { padding: [40, 40], maxZoom: 14 });
    }
  }, [towers, selectedTower, lastRecorded, maxEvents, showAzimuthSectors]);

  // Sequential timeline playback effect
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isPlayingSequence) {
      timer = setInterval(() => {
        setSequenceStep(prev => {
          if (prev >= chronologicalEvents.length - 1) {
            setIsPlayingSequence(false);
            return 0;
          }
          return prev + 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isPlayingSequence, chronologicalEvents]);

  // Highlight step in sequence
  useEffect(() => {
    const seqLayer = sequenceLayerRef.current;
    const map = mapInstanceRef.current;
    if (!seqLayer || !map) return;

    seqLayer.clearLayers();

    if (chronologicalEvents.length === 0 || sequenceStep < 0) return;

    const currentEv = chronologicalEvents[sequenceStep];
    if (currentEv && currentEv.latitude && currentEv.longitude) {
      const pulseMarker = L.circleMarker([currentEv.latitude, currentEv.longitude], {
        radius: 20,
        fillColor: '#8b5cf6',
        color: '#ffffff',
        weight: 3,
        opacity: 0.9,
        fillOpacity: 0.5
      });
      seqLayer.addLayer(pulseMarker);
    }
  }, [sequenceStep, chronologicalEvents]);

  const currentSequenceEvent = chronologicalEvents[sequenceStep];

  return (
    <div className="space-y-4">
      {/* Top Bar with Mandatory Judicial Disclaimer */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center space-x-2">
            <Radio className="w-5 h-5 text-blue-400" />
            <span>Cartografía Pericial de Antenas y Celdas de Telefonía</span>
          </h1>
          <p className="text-xs text-slate-400">
            Georreferenciación de torres celulares activadas por las comunicaciones en la sábana judicial.
          </p>
        </div>

        <div className="flex items-center space-x-3 self-start">
          <label className="flex items-center space-x-2 text-xs text-slate-300 cursor-pointer bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800">
            <input
              type="checkbox"
              checked={showAzimuthSectors}
              onChange={(e) => setShowAzimuthSectors(e.target.checked)}
              className="rounded text-blue-600 focus:ring-0"
            />
            <span className="flex items-center space-x-1">
              <Compass className="w-3.5 h-3.5 text-amber-400" />
              <span>Mostrar Sectores de Azimut</span>
            </span>
          </label>
        </div>
      </div>

      {/* Institutional Legal Warning Notice */}
      <div className="bg-amber-950/40 border border-amber-900/80 rounded-xl p-3 text-xs flex items-start space-x-2.5 text-amber-200">
        <ShieldAlert className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />
        <div className="space-y-0.5 leading-relaxed">
          <strong className="font-semibold text-amber-300">
            Consideración Pericial Obligatoria (No confundir antena con ubicación GPS exacta):
          </strong>
          <p className="text-[11px] text-amber-200/90">
            La posición graficada corresponde a la <strong>torre física fija de la operadora</strong> que cursó la señal. 
            El sector angular refleja la orientación geométrica teórica del azimut (cuando consta en el reporte) y 
            <strong> NO constituye un área de cobertura electromagnética medida ni la posición física verificada de una persona o dispositivo</strong>.
          </p>
        </div>
      </div>

      {/* Main Map Canvas and Overlays */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Map Container */}
        <div className="lg:col-span-3 bg-slate-900 border border-slate-800 rounded-xl overflow-hidden relative shadow-lg h-[580px] flex flex-col">
          <div ref={mapContainerRef} className="w-full h-full z-0" />

          {/* Sequential Player Floating Widget */}
          {chronologicalEvents.length > 0 && (
            <div className="absolute top-3 left-3 z-10 bg-slate-950/90 backdrop-blur-xs border border-slate-800 rounded-xl p-3 text-xs text-slate-200 shadow-xl max-w-sm space-y-2">
              <div className="flex items-center justify-between font-semibold text-xs border-b border-slate-800 pb-1.5">
                <span className="flex items-center space-x-1.5 text-blue-400">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Secuencia Histórica de Activaciones</span>
                </span>
                <span className="font-mono text-[10px] text-slate-400">
                  Paso {sequenceStep + 1} de {chronologicalEvents.length}
                </span>
              </div>

              {currentSequenceEvent && (
                <div className="text-[11px] font-mono space-y-1">
                  <div>
                    <span className="text-slate-400">Fecha/Hora: </span>
                    <strong className="text-white">
                      {currentSequenceEvent.timestamp.replace('T', ' ').substring(0, 19)}
                    </strong>
                  </div>
                  <div>
                    <span className="text-slate-400">Celda: </span>
                    <strong className="text-cyan-300">{currentSequenceEvent.cellId}</strong>
                    <span className="text-slate-500"> ({currentSequenceEvent.operator})</span>
                  </div>
                  <div className="truncate">
                    <span className="text-slate-400">Comunicación: </span>
                    <span className="text-blue-300">{currentSequenceEvent.sourceNumber}</span>
                    <span className="text-slate-500"> → </span>
                    <span className="text-purple-300">{currentSequenceEvent.destinationNumber}</span>
                  </div>
                </div>
              )}

              <div className="flex items-center space-x-2 pt-1">
                <button
                  onClick={() => setIsPlayingSequence(!isPlayingSequence)}
                  className="px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white font-medium rounded text-[11px] flex items-center space-x-1 shadow transition"
                >
                  {isPlayingSequence ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                  <span>{isPlayingSequence ? 'Pausar' : 'Reproducir'}</span>
                </button>
                <button
                  onClick={() => {
                    setIsPlayingSequence(false);
                    setSequenceStep(0);
                  }}
                  className="p-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded"
                  title="Reiniciar secuencia"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
                <input
                  type="range"
                  min={0}
                  max={chronologicalEvents.length - 1}
                  value={sequenceStep}
                  onChange={(e) => {
                    setIsPlayingSequence(false);
                    setSequenceStep(parseInt(e.target.value, 10));
                  }}
                  className="w-full accent-blue-500 cursor-pointer"
                />
              </div>
            </div>
          )}

          {/* Map Legend */}
          <div className="absolute bottom-3 left-3 z-10 bg-slate-950/90 backdrop-blur-xs border border-slate-800 rounded-lg p-2.5 text-[11px] text-slate-300 shadow-md flex items-center space-x-4">
            <span className="font-semibold text-slate-400 uppercase text-[10px]">Frecuencia:</span>
            <span className="flex items-center space-x-1">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-500 inline-block" />
              <span>Baja</span>
            </span>
            <span className="flex items-center space-x-1">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block" />
              <span>Media</span>
            </span>
            <span className="flex items-center space-x-1">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block" />
              <span>Alta</span>
            </span>
            <span className="flex items-center space-x-1">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block" />
              <span>Última Registrada</span>
            </span>
          </div>
        </div>

        {/* Right Column: Last Antenna Recorded & Selected Antenna Drawer */}
        <div className="space-y-4">
          {/* Last Recorded Antenna Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 px-2 py-0.5 rounded bg-emerald-950/80 border border-emerald-800">
                Última Antena Registrada
              </span>
              <Radio className="w-4 h-4 text-emerald-400" />
            </div>

            {lastRecorded ? (
              <div className="space-y-2 text-xs">
                <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 font-mono space-y-1">
                  <div className="text-sm font-bold text-white">{lastRecorded.cellId}</div>
                  <div className="text-slate-400">Operador: <strong className="text-slate-200">{lastRecorded.operator}</strong></div>
                  {lastRecorded.azimuth !== null && (
                    <div className="text-slate-400">Azimut: <strong className="text-amber-400">{lastRecorded.azimuth}°</strong></div>
                  )}
                  <div className="text-slate-400">WGS84: <span className="text-slate-300">{lastRecorded.latitude?.toFixed(4)}, {lastRecorded.longitude?.toFixed(4)}</span></div>
                </div>

                <div className="text-[11px] text-slate-400 space-y-1">
                  <div>
                    <span className="text-slate-500 block">Momento del último evento:</span>
                    <strong className="text-emerald-400 font-mono">
                      {lastRecorded.timestamp.replace('T', ' ').substring(0, 19)}
                    </strong>
                  </div>
                  {lastRecorded.event && (
                    <div className="pt-1 border-t border-slate-800 text-[10px]">
                      <span>Interacción: {lastRecorded.event.sourceNumber} → {lastRecorded.event.destinationNumber}</span>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <p className="text-xs text-slate-500">No hay eventos con coordenadas válidas registradas.</p>
            )}
          </div>

          {/* Selected Tower Detail Card */}
          {selectedTower ? (
            <div className="bg-slate-900 border border-blue-500/50 rounded-xl p-4 space-y-3 shadow-lg">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <div className="flex items-center space-x-2">
                  <MapPin className="w-4 h-4 text-blue-400" />
                  <h3 className="text-sm font-bold text-white font-mono">{selectedTower.cellId}</h3>
                </div>
                <button
                  onClick={() => setSelectedTower(null)}
                  className="text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-2 text-xs">
                <div className="grid grid-cols-2 gap-2 bg-slate-950 p-2.5 rounded-lg border border-slate-800 font-mono text-[11px]">
                  <div>
                    <span className="text-slate-500 block">Operador:</span>
                    <span className="text-slate-200 font-bold">{selectedTower.operator}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Eventos Cursados:</span>
                    <span className="text-blue-400 font-bold">{selectedTower.totalEvents}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Azimut:</span>
                    <span className="text-amber-400 font-bold">
                      {selectedTower.azimuth !== null ? `${selectedTower.azimuth}°` : 'No informado'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Números Únicos:</span>
                    <span className="text-purple-400 font-bold">{selectedTower.uniqueContacts}</span>
                  </div>
                </div>

                <div className="text-[11px] text-slate-400 space-y-1">
                  <div>
                    <span className="text-slate-500">Primera vez vista: </span>
                    <span className="font-mono text-slate-300">{selectedTower.firstSeen.replace('T', ' ').substring(0, 16)}</span>
                  </div>
                  <div>
                    <span className="text-slate-500">Última vez vista: </span>
                    <span className="font-mono text-slate-300">{selectedTower.lastSeen.replace('T', ' ').substring(0, 16)}</span>
                  </div>
                </div>

                {/* Associated CDR list preview */}
                <div className="pt-2 border-t border-slate-800 space-y-1.5">
                  <span className="text-[11px] font-semibold text-slate-300 block">
                    Últimas comunicaciones cursadas por esta antena:
                  </span>
                  <div className="max-h-40 overflow-y-auto space-y-1 pr-1 font-mono text-[10px]">
                    {selectedTower.events.slice(0, 8).map(ev => (
                      <div key={ev.id} className="p-1.5 bg-slate-950 rounded border border-slate-800 flex justify-between items-center">
                        <span className="text-slate-400">{ev.timestamp.replace('T', ' ').substring(11, 19)}</span>
                        <span className="text-blue-400">{ev.sourceNumber.slice(-8)}</span>
                        <span className="text-slate-500">→</span>
                        <span className="text-purple-400">{ev.destinationNumber.slice(-8)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 text-center space-y-2 text-slate-400 text-xs">
              <MapPin className="w-8 h-8 text-slate-600 mx-auto" />
              <p>Haga clic en cualquier marcador del mapa para inspeccionar los eventos y azimut de esa celda.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
