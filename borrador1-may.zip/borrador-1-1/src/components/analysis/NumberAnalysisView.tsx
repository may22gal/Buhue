import React, { useState, useMemo } from 'react';
import { 
  PhoneCall, 
  MessageSquare, 
  Clock, 
  ArrowDownLeft, 
  ArrowUpRight, 
  Radio, 
  FileText, 
  Users, 
  Calendar, 
  Activity, 
  ListFilter,
  Eye,
  X,
  Smartphone,
  Globe,
  Layers,
  AlertTriangle,
  Tag,
  Edit3,
  Trash2,
  Plus,
  BookmarkCheck,
  ShieldAlert
} from 'lucide-react';
import { 
  NormalizedCDR, 
  AnalysisFilterState, 
  FrequentContact, 
  UserProfile,
  PhoneTag,
  PhoneTagCategory
} from '../../types';
import { 
  computeFrequentContacts, 
  filterCDRRecords, 
  computeCellTowerSummaries 
} from '../../services/analysisEngine';
import { logAuditEvent } from '../../services/auditService';

interface NumberAnalysisViewProps {
  records: NormalizedCDR[];
  targetNumbers: string[];
  currentUser: UserProfile;
  phoneTags?: Record<string, PhoneTag>;
  onSavePhoneTag?: (tag: PhoneTag) => void;
  onDeletePhoneTag?: (phoneNumber: string) => void;
}

export const NumberAnalysisView: React.FC<NumberAnalysisViewProps> = ({
  records,
  targetNumbers,
  currentUser,
  phoneTags,
  onSavePhoneTag,
  onDeletePhoneTag
}) => {
  const [selectedTarget, setSelectedTarget] = useState<string>(
    targetNumbers[0] || (records[0]?.sourceNumber || '+526141769216')
  );

  const [filters, setFilters] = useState<AnalysisFilterState>({
    targetNumber: selectedTarget,
    selectedContact: '',
    direction: 'TODOS',
    eventType: 'TODOS',
    mirrorFilter: 'EXCLUDE_MIRRORS', // Default to exclude mirror transit legs to avoid double count
    imeiFilter: 'TODOS',
    startDate: '',
    endDate: '',
    startHour: 0,
    endHour: 23,
    operator: 'TODOS',
    cellId: 'TODAS',
    minDuration: 0,
    searchTerm: ''
  });

  const [drillDownContact, setDrillDownContact] = useState<FrequentContact | null>(null);

  // Tagging modal state
  const [taggingContact, setTaggingContact] = useState<FrequentContact | null>(null);
  const [tagForm, setTagForm] = useState<{
    alias: string;
    category: PhoneTagCategory;
    notes: string;
  }>({
    alias: '',
    category: 'INVESTIGACION',
    notes: ''
  });

  // Distinct phone numbers in dataset (excluding data APN)
  const availableNumbers = useMemo(() => {
    const set = new Set<string>();
    records.forEach(r => {
      if (r.status !== 'REJECTED') {
        if (!r.sourceNumber.includes('itelcel')) set.add(r.sourceNumber);
        if (!r.destinationNumber.includes('itelcel')) set.add(r.destinationNumber);
      }
    });
    return Array.from(set).sort();
  }, [records]);

  // Detected IMEIs for this target
  const targetImeis = useMemo(() => {
    const set = new Set<string>();
    records.forEach(r => {
      if (r.imei && r.imei !== '-' && (r.sourceNumber === selectedTarget || r.destinationNumber === selectedTarget || r.targetPhone === selectedTarget)) {
        set.add(r.imei);
      }
    });
    return Array.from(set);
  }, [records, selectedTarget]);

  // Filter records based on selected target and general filters
  const targetRecords = useMemo(() => {
    const f: AnalysisFilterState = { ...filters, targetNumber: selectedTarget };
    return filterCDRRecords(records, f, false);
  }, [records, filters, selectedTarget]);

  // Compute frequent contacts for the selected target (with phoneTags applied)
  const frequentContacts = useMemo(() => {
    return computeFrequentContacts(targetRecords, selectedTarget, phoneTags);
  }, [targetRecords, selectedTarget, phoneTags]);

  // Compute antennas used by this target
  const targetAntennas = useMemo(() => {
    return computeCellTowerSummaries(targetRecords);
  }, [targetRecords]);

  // Summary statistics for this target
  const stats = useMemo(() => {
    let calls = 0;
    let sms = 0;
    let dataEvents = 0;
    let totalSec = 0;
    let incoming = 0;
    let outgoing = 0;
    let mirrors = 0;

    targetRecords.forEach(r => {
      if (r.isMirror) {
        mirrors++;
      } else if (r.eventType === 'DATOS') {
        dataEvents++;
      } else if (r.eventType.startsWith('LLAMADA')) {
        calls++;
        totalSec += r.durationSeconds;
        if (r.sourceNumber === selectedTarget) outgoing++;
        else incoming++;
      } else if (r.eventType.startsWith('SMS')) {
        sms++;
        if (r.sourceNumber === selectedTarget) outgoing++;
        else incoming++;
      }
    });

    return {
      total: targetRecords.length,
      calls,
      sms,
      dataEvents,
      mirrors,
      totalDurationMinutes: Math.round(totalSec / 60),
      incoming,
      outgoing
    };
  }, [targetRecords, selectedTarget]);

  // Hourly distribution
  const hourlyDistribution = useMemo(() => {
    const hours = Array(24).fill(0);
    targetRecords.forEach(r => {
      const h = new Date(r.timestamp).getUTCHours();
      hours[h]++;
    });
    return hours;
  }, [targetRecords]);

  const maxHourEvents = Math.max(...hourlyDistribution, 1);

  // Drill-down records for the modal
  const substantiatingRecords = useMemo(() => {
    if (!drillDownContact) return [];
    return targetRecords.filter(r => 
      (r.sourceNumber === selectedTarget && r.destinationNumber === drillDownContact.phoneNumber) ||
      (r.destinationNumber === selectedTarget && r.sourceNumber === drillDownContact.phoneNumber)
    );
  }, [targetRecords, selectedTarget, drillDownContact]);

  const handleSelectContactForDrilldown = (c: FrequentContact) => {
    setDrillDownContact(c);
    logAuditEvent(
      'FILTER_QUERY',
      `Inspección pericial de sustento para contacto ${c.phoneNumber} (${c.totalEvents} eventos)`,
      currentUser.email,
      currentUser.uid
    );
  };

  const handleOpenTagModal = (c: FrequentContact, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setTaggingContact(c);
    
    // Check if tag already exists in phoneTags
    const rawClean = c.phoneNumber.replace(/[^0-9]/g, '');
    const short10 = rawClean.slice(-10);
    const existingTag = phoneTags?.[c.phoneNumber] || phoneTags?.[rawClean] || (short10 ? phoneTags?.[short10] : undefined);

    setTagForm({
      alias: c.alias || existingTag?.alias || '',
      category: c.category || existingTag?.category || 'INVESTIGACION',
      notes: existingTag?.notes || ''
    });
  };

  const handleSaveTag = () => {
    if (!taggingContact || !onSavePhoneTag) return;
    const cleanNum = taggingContact.phoneNumber.replace(/[^0-9]/g, '');
    const short10 = cleanNum.slice(-10);

    const newTag: PhoneTag = {
      phoneNumber: short10 || taggingContact.phoneNumber,
      alias: tagForm.alias.trim() || 'Sin Alias',
      category: tagForm.category,
      notes: tagForm.notes.trim(),
      updatedAt: new Date().toISOString(),
      updatedBy: currentUser.email
    };

    onSavePhoneTag(newTag);
    logAuditEvent(
      'TAG_PHONE',
      `Asignación de etiqueta judicial '${newTag.alias}' (${newTag.category}) al número ${newTag.phoneNumber}`,
      currentUser.email,
      currentUser.uid
    );
    setTaggingContact(null);
  };

  const handleDeleteTag = () => {
    if (!taggingContact || !onDeletePhoneTag) return;
    const cleanNum = taggingContact.phoneNumber.replace(/[^0-9]/g, '');
    const short10 = cleanNum.slice(-10);
    onDeletePhoneTag(short10 || taggingContact.phoneNumber);
    onDeletePhoneTag(taggingContact.phoneNumber);
    logAuditEvent(
      'TAG_PHONE',
      `Eliminación de etiqueta judicial del número ${taggingContact.phoneNumber}`,
      currentUser.email,
      currentUser.uid
    );
    setTaggingContact(null);
  };

  const getCategoryBadgeClass = (category?: PhoneTagCategory) => {
    switch (category) {
      case 'INVESTIGACION':
        return 'bg-rose-950/80 text-rose-300 border-rose-700/80';
      case 'FAMILIAR':
        return 'bg-blue-950/80 text-blue-300 border-blue-700/80';
      case 'COMERCIO':
        return 'bg-amber-950/80 text-amber-300 border-amber-700/80';
      case 'TRANSPORTE':
        return 'bg-emerald-950/80 text-emerald-300 border-emerald-700/80';
      case 'LEGAL':
        return 'bg-purple-950/80 text-purple-300 border-purple-700/80';
      default:
        return 'bg-slate-800 text-slate-300 border-slate-700';
    }
  };

  const PRESET_TAGS: { name: string; category: PhoneTagCategory; group: string }[] = [
    // Familiar
    { name: 'Papá', category: 'FAMILIAR', group: 'Familiar' },
    { name: 'Mamá', category: 'FAMILIAR', group: 'Familiar' },
    { name: 'Tío', category: 'FAMILIAR', group: 'Familiar' },
    { name: 'Tía', category: 'FAMILIAR', group: 'Familiar' },
    { name: 'Hermano', category: 'FAMILIAR', group: 'Familiar' },
    { name: 'Hermana', category: 'FAMILIAR', group: 'Familiar' },
    { name: 'Pareja', category: 'FAMILIAR', group: 'Familiar' },
    { name: 'Hijo/a', category: 'FAMILIAR', group: 'Familiar' },

    // Investigación / Sospechosos
    { name: 'Dealer', category: 'INVESTIGACION', group: 'Investigación' },
    { name: 'Proveedor', category: 'INVESTIGACION', group: 'Investigación' },
    { name: 'Campana / Halcón', category: 'INVESTIGACION', group: 'Investigación' },
    { name: 'Sicario', category: 'INVESTIGACION', group: 'Investigación' },
    { name: 'Transporte Ilícito', category: 'INVESTIGACION', group: 'Investigación' },
    { name: 'Líder / Mando', category: 'INVESTIGACION', group: 'Investigación' },

    // Transporte
    { name: 'Didi', category: 'TRANSPORTE', group: 'Transporte' },
    { name: 'Uber', category: 'TRANSPORTE', group: 'Transporte' },
    { name: 'Taxi', category: 'TRANSPORTE', group: 'Transporte' },
    { name: 'Repartidor', category: 'TRANSPORTE', group: 'Transporte' },

    // Comercio
    { name: 'Tienda', category: 'COMERCIO', group: 'Comercio' },
    { name: 'Ferretería', category: 'COMERCIO', group: 'Comercio' },
    { name: 'Taller Mecánico', category: 'COMERCIO', group: 'Comercio' },
    { name: 'Farmacia', category: 'COMERCIO', group: 'Comercio' },
    { name: 'Abarrotes', category: 'COMERCIO', group: 'Comercio' },

    // Legal
    { name: 'Abogado', category: 'LEGAL', group: 'Legal' },
    { name: 'Defensoría', category: 'LEGAL', group: 'Legal' },
    { name: 'Juzgado', category: 'LEGAL', group: 'Legal' }
  ];

  return (
    <div className="space-y-6">
      {/* Header and Target Number Switcher */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center space-x-2">
            <PhoneCall className="w-5 h-5 text-blue-400" />
            <span>Análisis Pericial por Número Investigado</span>
          </h1>
          <p className="text-xs text-slate-400">
            Frecuencias de enlace, aislamiento de espejos (tránsito/transfer), análisis de IMEIs y paquetes de datos.
          </p>
        </div>

        {/* Target Number Picker */}
        <div className="flex items-center space-x-3 bg-slate-950 p-2.5 rounded-xl border border-slate-800 self-start">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wide">
            Número Blanco:
          </span>
          <select
            value={selectedTarget}
            onChange={(e) => {
              setSelectedTarget(e.target.value);
              setFilters(f => ({ ...f, targetNumber: e.target.value }));
            }}
            className="bg-slate-900 border border-blue-500/50 rounded-lg px-3 py-1.5 text-xs font-mono font-bold text-blue-300 focus:outline-none focus:border-blue-400 cursor-pointer"
          >
            {targetNumbers.map(n => (
              <option key={n} value={n}>★ Investigado: {n}</option>
            ))}
            <option disabled>──────────</option>
            {availableNumbers
              .filter(n => !targetNumbers.includes(n))
              .map(n => (
                <option key={n} value={n}>{n}</option>
              ))}
          </select>
        </div>
      </div>

      {/* Forensic Warnings & IMEIs Detected Bar */}
      {targetImeis.length > 0 && (
        <div className="bg-slate-900 border border-purple-900/60 rounded-xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs">
          <div className="flex items-center space-x-2.5 text-purple-300">
            <Smartphone className="w-4 h-4 text-purple-400 shrink-0" />
            <span>
              <strong>IMEIs de Aparatos Identificados en la Sábana: </strong>
              {targetImeis.map((imei, idx) => (
                <span key={imei} className="font-mono bg-purple-950 text-purple-300 px-2 py-0.5 rounded border border-purple-800 mr-2">
                  {imei} {idx === 0 ? '(Aparato Principal)' : '(Detectado en Tránsito / Salto)'}
                </span>
              ))}
            </span>
          </div>

          {targetImeis.length > 1 && (
            <span className="text-[11px] text-amber-400 bg-amber-950/60 border border-amber-800/80 px-2.5 py-1 rounded-lg font-medium flex items-center space-x-1">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>ALERTA FORENSE: Coexisten 2 IMEIs para la misma línea telefónica</span>
            </span>
          )}
        </div>
      )}

      {/* KPI Cards for Target Number */}
      <div className="grid grid-cols-2 md:grid-cols-6 gap-3.5">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
          <div className="text-xs text-slate-400">Eventos Válidos</div>
          <div className="text-2xl font-bold font-mono text-white">{stats.total}</div>
          <div className="text-[11px] text-slate-500">Filtrados en el período</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Llamadas Directas</span>
            <PhoneCall className="w-3.5 h-3.5 text-blue-400" />
          </div>
          <div className="text-xl font-bold font-mono text-blue-400">{stats.calls}</div>
          <div className="text-[11px] text-slate-500">VOZ ENTRANTE / SALIENTE</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Paquetes de Datos</span>
            <Globe className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-xl font-bold font-mono text-amber-300">{stats.dataEvents}</div>
          <div className="text-[11px] text-amber-500/80">internet.itelcel.com</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Duración Acumulada</span>
            <Clock className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="text-xl font-bold font-mono text-emerald-300">{stats.totalDurationMinutes} min</div>
          <div className="text-[11px] text-slate-500">Tráfico de voz neta</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Balanza de Voz</span>
            <div className="flex space-x-1">
              <ArrowDownLeft className="w-3 h-3 text-blue-400" />
              <ArrowUpRight className="w-3 h-3 text-emerald-400" />
            </div>
          </div>
          <div className="text-lg font-bold font-mono text-white">
            <span className="text-blue-400">{stats.incoming}</span> / <span className="text-emerald-400">{stats.outgoing}</span>
          </div>
          <div className="text-[11px] text-slate-500">Entrantes / Salientes</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Espejos Aislados</span>
            <Layers className="w-3.5 h-3.5 text-purple-400" />
          </div>
          <div className="text-xl font-bold font-mono text-purple-300">
            {records.filter(r => r.isMirror).length}
          </div>
          <div className="text-[11px] text-purple-400/80">Tránsito / Transferencias</div>
        </div>
      </div>

      {/* Espejos Toggle Filter Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex flex-col md:flex-row items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-2">
          <Layers className="w-4 h-4 text-purple-400" />
          <span className="font-semibold text-slate-200">Tratamiento Pericial de Registros Espejo:</span>
          <span className="text-slate-400 text-[11px]">
            (Evita computar como nueva llamada los saltos de central telefónica)
          </span>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => setFilters({ ...filters, mirrorFilter: 'EXCLUDE_MIRRORS' })}
            className={`px-3 py-1.5 rounded-lg font-medium transition ${
              filters.mirrorFilter === 'EXCLUDE_MIRRORS'
                ? 'bg-blue-600 text-white shadow'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            ✓ Excluir Espejos (Recomendado)
          </button>
          <button
            onClick={() => setFilters({ ...filters, mirrorFilter: 'INCLUDE_ALL' })}
            className={`px-3 py-1.5 rounded-lg font-medium transition ${
              filters.mirrorFilter === 'INCLUDE_ALL'
                ? 'bg-purple-600 text-white shadow'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            Incluir Todo
          </button>
          <button
            onClick={() => setFilters({ ...filters, mirrorFilter: 'ONLY_MIRRORS' })}
            className={`px-3 py-1.5 rounded-lg font-medium transition ${
              filters.mirrorFilter === 'ONLY_MIRRORS'
                ? 'bg-amber-600 text-white shadow'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            Solo Espejos (Img 3)
          </button>
        </div>
      </div>

      {/* Hourly Heatmap Distribution Matrix */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Activity className="w-4 h-4 text-amber-400" />
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
              Distribución Horaria de Comunicaciones (00h a 23h UTC)
            </h3>
          </div>
          <span className="text-[11px] text-amber-400/90 font-medium">
            * Franja nocturna 22h - 06h resaltada
          </span>
        </div>

        <div className="grid grid-cols-24 gap-1 h-20 items-end pt-4 bg-slate-950/60 p-3 rounded-lg border border-slate-800">
          {hourlyDistribution.map((count, hour) => {
            const heightPercent = maxHourEvents > 0 ? (count / maxHourEvents) * 100 : 0;
            const isNocturnal = hour >= 22 || hour < 6;
            return (
              <div key={hour} className="flex flex-col items-center h-full justify-end group relative">
                <div className="opacity-0 group-hover:opacity-100 transition absolute bottom-full mb-1 z-10 bg-slate-800 border border-slate-700 text-[10px] text-white px-2 py-0.5 rounded pointer-events-none whitespace-nowrap shadow-lg">
                  {hour}:00h - {count} eventos
                </div>
                <div
                  className={`w-full rounded-t transition-all ${
                    count > 0 
                      ? isNocturnal 
                        ? 'bg-amber-500 hover:bg-amber-400' 
                        : 'bg-blue-600 hover:bg-blue-500' 
                      : 'bg-slate-800/40'
                  }`}
                  style={{ height: `${Math.max(heightPercent, 4)}%` }}
                />
                <span className={`text-[9px] mt-1 font-mono ${isNocturnal ? 'text-amber-400 font-semibold' : 'text-slate-500'}`}>
                  {hour}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Frequent Contacts Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm space-y-0">
        <div className="p-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
          <div className="space-y-0.5">
            <h3 className="text-sm font-bold text-white flex items-center space-x-2">
              <Users className="w-4 h-4 text-blue-400" />
              <span>Interlocutores Frecuentes del Número {selectedTarget}</span>
            </h3>
            <p className="text-xs text-slate-400">
              Haga clic en cualquier fila para inspeccionar los registros exactos de la sábana judicial que sustentan la métrica.
            </p>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            {frequentContacts.length} números vinculados
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800 uppercase tracking-wider text-[11px]">
              <tr>
                <th className="px-4 py-2.5">#</th>
                <th className="px-4 py-2.5 font-mono">Número Interlocutor</th>
                <th className="px-4 py-2.5">Etiqueta Pericial (Alias)</th>
                <th className="px-4 py-2.5 text-right">Eventos</th>
                <th className="px-4 py-2.5 text-right">Llamadas (Voz)</th>
                <th className="px-4 py-2.5 text-right">Paquetes Datos</th>
                <th className="px-4 py-2.5 text-right">Duración Total</th>
                <th className="px-4 py-2.5 text-center">Balanza (Ent / Sal)</th>
                <th className="px-4 py-2.5 font-mono">IMEIs Detectados</th>
                <th className="px-4 py-2.5 text-center">Sustento</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 font-mono text-[11px]">
              {frequentContacts.map((c, idx) => {
                const isDataApn = c.phoneNumber.includes('itelcel');
                return (
                  <tr 
                    key={c.phoneNumber} 
                    className="hover:bg-slate-800/40 transition cursor-pointer"
                    onClick={() => handleSelectContactForDrilldown(c)}
                  >
                    <td className="px-4 py-2 text-slate-500">{idx + 1}</td>
                    <td className="px-4 py-2 font-bold whitespace-nowrap">
                      {isDataApn ? (
                        <span className="text-amber-400 font-sans">{c.phoneNumber} (Internet APN)</span>
                      ) : (
                        <span className="text-blue-400">{c.phoneNumber}</span>
                      )}
                    </td>
                    <td className="px-4 py-2 whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                      {c.alias ? (
                        <div className="flex items-center space-x-1.5">
                          <span className={`px-2.5 py-0.5 rounded-md text-[10.5px] font-sans font-bold border shadow-xs ${getCategoryBadgeClass(c.category)}`}>
                            🏷️ {c.alias}
                          </span>
                          {currentUser.role !== 'consulta' && (
                            <button
                              onClick={(e) => handleOpenTagModal(c, e)}
                              className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-700/60 transition"
                              title="Modificar etiqueta pericial"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      ) : (
                        currentUser.role !== 'consulta' && !isDataApn ? (
                          <button
                            onClick={(e) => handleOpenTagModal(c, e)}
                            className="px-2.5 py-1 bg-slate-800/90 hover:bg-blue-900/40 text-slate-300 hover:text-blue-200 border border-slate-700/80 hover:border-blue-600/60 rounded-md text-[10.5px] font-sans font-medium flex items-center space-x-1 transition shadow-xs"
                          >
                            <Plus className="w-3 h-3 text-blue-400" />
                            <span>Asignar Alias</span>
                          </button>
                        ) : (
                          <span className="text-slate-600 font-sans text-[10px]">-</span>
                        )
                      )}
                    </td>
                    <td className="px-4 py-2 text-right font-bold text-white whitespace-nowrap">
                      {c.totalEvents}
                    </td>
                    <td className="px-4 py-2 text-right text-slate-300 whitespace-nowrap">
                      {c.callCount}
                    </td>
                    <td className="px-4 py-2 text-right text-amber-400 whitespace-nowrap">
                      {c.dataCount}
                    </td>
                    <td className="px-4 py-2 text-right text-emerald-400 whitespace-nowrap">
                      {Math.floor(c.totalDurationSeconds / 60)}m {c.totalDurationSeconds % 60}s
                    </td>
                    <td className="px-4 py-2 text-center whitespace-nowrap">
                      <span className="text-blue-400">{c.incomingCount}</span>
                      <span className="text-slate-500 mx-1">/</span>
                      <span className="text-emerald-400">{c.outgoingCount}</span>
                    </td>
                    <td className="px-4 py-2 text-slate-400 text-[10px] whitespace-nowrap truncate max-w-[140px]">
                      {c.associatedImeis.join(', ') || '-'}
                    </td>
                    <td className="px-4 py-2 text-center">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleSelectContactForDrilldown(c);
                        }}
                        className="px-2 py-0.5 bg-blue-900/60 hover:bg-blue-800 text-blue-300 border border-blue-700/60 rounded text-[10px] font-sans font-semibold transition"
                      >
                        Ver ({c.totalEvents})
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Drill-Down Modal to Inspect Substantiating Records */}
      {drillDownContact && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl max-w-4xl w-full p-6 space-y-4 shadow-2xl max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-base font-bold text-white flex items-center space-x-2">
                  <FileText className="w-5 h-5 text-blue-400" />
                  <span>Registros Periciales de la Sábana que Sustentan la Métrica</span>
                </h3>
                <p className="text-xs text-slate-400">
                  Comunicaciones entre <strong className="text-blue-400 font-mono">{selectedTarget}</strong> y{' '}
                  <strong className="text-purple-400 font-mono">{drillDownContact.phoneNumber}</strong>
                </p>
              </div>
              <button
                onClick={() => setDrillDownContact(null)}
                className="text-slate-400 hover:text-white text-xl font-bold p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="overflow-y-auto flex-1 border border-slate-800 rounded-lg">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800 text-[11px] sticky top-0 font-mono">
                  <tr>
                    <th className="px-3 py-2 w-10">Fila</th>
                    <th className="px-3 py-2">Fecha</th>
                    <th className="px-3 py-2">Hora</th>
                    <th className="px-3 py-2">Tipo</th>
                    <th className="px-3 py-2 text-right">Duración</th>
                    <th className="px-3 py-2">IMEI</th>
                    <th className="px-3 py-2">LATITUD (DMS)</th>
                    <th className="px-3 py-2">LONGITUD (DMS)</th>
                    <th className="px-3 py-2 text-center">Azimuth</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 font-mono text-[11px]">
                  {substantiatingRecords.map((r) => (
                    <tr key={r.id} className="hover:bg-slate-800/30">
                      <td className="px-3 py-2 text-slate-500">#{r.rowNumber}</td>
                      <td className="px-3 py-2 whitespace-nowrap text-slate-200">{r.rawDate}</td>
                      <td className="px-3 py-2 whitespace-nowrap text-slate-200">{r.rawTime}</td>
                      <td className="px-3 py-2 font-sans font-medium text-slate-300">{r.tipo2} ({r.rawEventType})</td>
                      <td className="px-3 py-2 text-right text-slate-200">{r.durationSeconds}s</td>
                      <td className="px-3 py-2 text-purple-300">{r.rawImei || '-'}</td>
                      <td className="px-3 py-2 text-slate-300">{r.rawLatitude || '-'}</td>
                      <td className="px-3 py-2 text-slate-300">{r.rawLongitude || '-'}</td>
                      <td className="px-3 py-2 text-center text-amber-400">{r.rawAzimuth || '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="flex justify-between items-center pt-2 border-t border-slate-800 text-xs">
              <span className="text-slate-500">
                Total de registros verificados en la sábana: {substantiatingRecords.length}
              </span>
              <button
                onClick={() => setDrillDownContact(null)}
                className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-medium rounded-lg text-xs"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Forensic Tagging Modal */}
      {taggingContact && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl max-w-xl w-full p-6 space-y-5 shadow-2xl max-h-[90vh] flex flex-col">
            {/* Modal Header */}
            <div className="flex items-start justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-base font-bold text-white flex items-center space-x-2">
                  <Tag className="w-5 h-5 text-blue-400" />
                  <span>Asignar Etiqueta Pericial por Nombre</span>
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Identificación investigativa del número{' '}
                  <strong className="text-blue-400 font-mono text-sm">{taggingContact.phoneNumber}</strong>
                </p>
                <div className="flex items-center space-x-3 text-[11px] text-slate-400 mt-1">
                  <span>{taggingContact.totalEvents} eventos registrados</span>
                  <span>•</span>
                  <span>{taggingContact.callCount} llamadas</span>
                  <span>•</span>
                  <span className="text-emerald-400">{Math.round(taggingContact.totalDurationSeconds / 60)} min acum.</span>
                </div>
              </div>
              <button
                onClick={() => setTaggingContact(null)}
                className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 overflow-y-auto flex-1 pr-1">
              {/* Presets by Category (User Request: papa, mama, tio, tia, dealer, tienda, ferreteria, didi, uber, etc.) */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-300 block">
                  Etiquetas Frecuentes Sugeridas (Haga clic para seleccionar):
                </label>
                
                {/* Group 1: Familiar */}
                <div className="space-y-1">
                  <div className="text-[10px] uppercase font-bold text-blue-400 tracking-wider">Familiar:</div>
                  <div className="flex flex-wrap gap-1.5">
                    {PRESET_TAGS.filter(p => p.group === 'Familiar').map(p => (
                      <button
                        key={p.name}
                        type="button"
                        onClick={() => setTagForm(prev => ({ ...prev, alias: p.name, category: p.category }))}
                        className={`px-2.5 py-1 rounded text-xs font-medium border transition ${
                          tagForm.alias === p.name
                            ? 'bg-blue-600 text-white border-blue-400 shadow-sm'
                            : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                        }`}
                      >
                        {p.name}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Group 2: Investigación / Sospechosos */}
                <div className="space-y-1 pt-1">
                  <div className="text-[10px] uppercase font-bold text-rose-400 tracking-wider">Investigación / Delictivo:</div>
                  <div className="flex flex-wrap gap-1.5">
                    {PRESET_TAGS.filter(p => p.group === 'Investigación').map(p => (
                      <button
                        key={p.name}
                        type="button"
                        onClick={() => setTagForm(prev => ({ ...prev, alias: p.name, category: p.category }))}
                        className={`px-2.5 py-1 rounded text-xs font-medium border transition ${
                          tagForm.alias === p.name
                            ? 'bg-rose-600 text-white border-rose-400 shadow-sm'
                            : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                        }`}
                      >
                        {p.name}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Group 3: Plataformas / Transporte */}
                <div className="space-y-1 pt-1">
                  <div className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider">Transporte y Plataformas:</div>
                  <div className="flex flex-wrap gap-1.5">
                    {PRESET_TAGS.filter(p => p.group === 'Transporte').map(p => (
                      <button
                        key={p.name}
                        type="button"
                        onClick={() => setTagForm(prev => ({ ...prev, alias: p.name, category: p.category }))}
                        className={`px-2.5 py-1 rounded text-xs font-medium border transition ${
                          tagForm.alias === p.name
                            ? 'bg-emerald-600 text-white border-emerald-400 shadow-sm'
                            : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                        }`}
                      >
                        {p.name}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Group 4: Comercio */}
                <div className="space-y-1 pt-1">
                  <div className="text-[10px] uppercase font-bold text-amber-400 tracking-wider">Comercio y Servicios:</div>
                  <div className="flex flex-wrap gap-1.5">
                    {PRESET_TAGS.filter(p => p.group === 'Comercio').map(p => (
                      <button
                        key={p.name}
                        type="button"
                        onClick={() => setTagForm(prev => ({ ...prev, alias: p.name, category: p.category }))}
                        className={`px-2.5 py-1 rounded text-xs font-medium border transition ${
                          tagForm.alias === p.name
                            ? 'bg-amber-600 text-white border-amber-400 shadow-sm'
                            : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                        }`}
                      >
                        {p.name}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Group 5: Legal */}
                <div className="space-y-1 pt-1">
                  <div className="text-[10px] uppercase font-bold text-purple-400 tracking-wider">Legal e Institucional:</div>
                  <div className="flex flex-wrap gap-1.5">
                    {PRESET_TAGS.filter(p => p.group === 'Legal').map(p => (
                      <button
                        key={p.name}
                        type="button"
                        onClick={() => setTagForm(prev => ({ ...prev, alias: p.name, category: p.category }))}
                        className={`px-2.5 py-1 rounded text-xs font-medium border transition ${
                          tagForm.alias === p.name
                            ? 'bg-purple-600 text-white border-purple-400 shadow-sm'
                            : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                        }`}
                      >
                        {p.name}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Custom Alias Input */}
              <div className="space-y-1.5 pt-2 border-t border-slate-800">
                <label className="text-xs font-semibold text-slate-200 block">
                  Nombre o Alias Asignado al Número:
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={tagForm.alias}
                    onChange={(e) => setTagForm(prev => ({ ...prev, alias: e.target.value }))}
                    placeholder="ej. Papá, Dealer, Tienda Ferretería, Didi..."
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3.5 py-2 text-sm text-white focus:outline-none focus:border-blue-500 font-medium"
                    autoFocus
                  />
                  {tagForm.alias && (
                    <button
                      type="button"
                      onClick={() => setTagForm(prev => ({ ...prev, alias: '' }))}
                      className="absolute right-2.5 top-2.5 text-slate-500 hover:text-slate-300"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

              {/* Category Selector */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-200 block">
                  Clasificación Pericial:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['FAMILIAR', 'INVESTIGACION', 'COMERCIO', 'TRANSPORTE', 'LEGAL', 'OTRO'] as PhoneTagCategory[]).map(cat => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setTagForm(prev => ({ ...prev, category: cat }))}
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold border transition text-center ${
                        tagForm.category === cat
                          ? `${getCategoryBadgeClass(cat)} ring-1 ring-white/30 shadow`
                          : 'bg-slate-950/80 text-slate-400 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Investigative Notes */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 block">
                  Notas / Justificación Pericial (Opcional):
                </label>
                <textarea
                  value={tagForm.notes}
                  onChange={(e) => setTagForm(prev => ({ ...prev, notes: e.target.value }))}
                  placeholder="ej. Declaración del testigo o informe policial de fecha 24/01/2025 que lo vincula como proveedor..."
                  rows={2}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500 resize-none"
                />
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center justify-between pt-3 border-t border-slate-800">
              <div>
                {taggingContact.alias && (
                  <button
                    type="button"
                    onClick={handleDeleteTag}
                    className="px-3 py-1.5 bg-rose-950/80 hover:bg-rose-900 text-rose-300 border border-rose-800 rounded-lg text-xs font-medium flex items-center space-x-1.5 transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Eliminar Etiqueta</span>
                  </button>
                )}
              </div>

              <div className="flex items-center space-x-2">
                <button
                  type="button"
                  onClick={() => setTaggingContact(null)}
                  className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium transition"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  disabled={!tagForm.alias.trim()}
                  onClick={handleSaveTag}
                  className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 disabled:text-slate-500 text-white rounded-lg text-xs font-bold transition shadow flex items-center space-x-1.5"
                >
                  <BookmarkCheck className="w-4 h-4" />
                  <span>Guardar Etiqueta Pericial</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
