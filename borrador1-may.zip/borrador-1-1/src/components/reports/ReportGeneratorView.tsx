import React from 'react';
import { 
  FileCheck2, 
  Printer, 
  Download, 
  Shield, 
  Clock, 
  AlertTriangle, 
  CheckCircle,
  FileSpreadsheet
} from 'lucide-react';
import { 
  ProsecutionCase, 
  NormalizedCDR, 
  ImportValidationReport, 
  UserProfile,
  PhoneTag
} from '../../types';
import { 
  computeFrequentContacts, 
  computeCellTowerSummaries, 
  findLastRecordedAntenna 
} from '../../services/analysisEngine';
import { logAuditEvent } from '../../services/auditService';

interface ReportGeneratorViewProps {
  currentCase: ProsecutionCase | null;
  records: NormalizedCDR[];
  report: ImportValidationReport | null;
  currentUser: UserProfile;
  phoneTags?: Record<string, PhoneTag>;
}

export const ReportGeneratorView: React.FC<ReportGeneratorViewProps> = ({
  currentCase,
  records,
  report,
  currentUser,
  phoneTags
}) => {
  const validRecords = records.filter(r => r.status === 'VALID');
  const targetNumber = currentCase?.targetNumbers[0] || records[0]?.sourceNumber || '';
  const frequentContacts = computeFrequentContacts(
    validRecords, 
    targetNumber, 
    phoneTags || currentCase?.phoneTags
  ).slice(0, 8);
  const topAntennas = computeCellTowerSummaries(validRecords).slice(0, 5);
  const lastAntenna = findLastRecordedAntenna(validRecords);

  const handlePrint = () => {
    logAuditEvent(
      'EXPORT_REPORT',
      `Generación de Dictamen Pericial Oficial en formato imprimible/PDF para expediente ${currentCase?.caseNumber}`,
      currentUser.email,
      currentUser.uid,
      currentCase?.id
    );
    window.print();
  };

  const handleExportCsv = () => {
    const headers = [
      'EXPEDIENTE',
      'NUMERO_ORIGEN',
      'NUMERO_DESTINO',
      'FECHA_HORA',
      'TIPO_EVENTO',
      'DURACION_SEG',
      'CELDA',
      'OPERADOR',
      'LATITUD',
      'LONGITUD',
      'AZIMUT',
      'ESTADO'
    ];

    const rows = validRecords.map(r => [
      `"${currentCase?.caseNumber || ''}"`,
      r.sourceNumber,
      r.destinationNumber,
      r.timestamp,
      r.eventType,
      r.durationSeconds,
      r.cellId,
      `"${r.operator}"`,
      r.latitude ?? '',
      r.longitude ?? '',
      r.azimuth ?? '',
      r.status
    ]);

    const csvContent = [headers.join(','), ...rows.map(row => row.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Dictamen_Datos_Filtrados_${currentCase?.caseNumber || 'exp'}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Action Header - hidden in print */}
      <div className="no-print bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center space-x-2">
            <FileCheck2 className="w-5 h-5 text-blue-400" />
            <span>Generador de Dictamen Pericial Forense (PDF / Imprimible)</span>
          </h1>
          <p className="text-xs text-slate-400">
            Emisión de informe oficial con trazabilidad de hash, metodología judicial y limitaciones legales.
          </p>
        </div>

        <div className="flex items-center space-x-2 shrink-0">
          <button
            onClick={handleExportCsv}
            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold rounded-lg flex items-center space-x-1.5 transition"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>Exportar CSV</span>
          </button>
          <button
            onClick={handlePrint}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg flex items-center space-x-1.5 shadow transition"
          >
            <Printer className="w-4 h-4" />
            <span>Imprimir / Guardar en PDF</span>
          </button>
        </div>
      </div>

      {/* Official Judicial Report Document - styled for screen and native print */}
      <div className="bg-white text-slate-900 rounded-xl shadow-xl p-8 md:p-12 space-y-6 text-xs leading-relaxed border border-slate-200 font-sans print:shadow-none print:border-none print:p-0">
        
        {/* Institutional Header */}
        <div className="border-b-2 border-slate-900 pb-5 space-y-2 text-center">
          <div className="font-serif uppercase tracking-widest text-sm font-bold text-slate-900">
            Ministerio Público Fiscal
          </div>
          <div className="text-xs uppercase tracking-wider text-slate-700 font-semibold">
            Dirección General de Investigaciones Periciales y Evidencia Digital
          </div>
          <div className="text-[11px] text-slate-600 italic">
            Departamento Forense de Análisis de Telecomunicaciones
          </div>
          <div className="pt-2 text-xs font-bold text-blue-900 uppercase">
            Dictamen Pericial de Tráfico Telefónico y Registro de Celdas
          </div>
        </div>

        {/* Case & Authority Metadata */}
        <div className="grid grid-cols-2 gap-4 bg-slate-50 border border-slate-200 p-4 rounded-lg text-xs">
          <div>
            <span className="text-slate-500 block text-[10px] uppercase font-semibold">Número de Causa / Expediente:</span>
            <strong className="text-slate-900 font-mono text-sm">{currentCase?.caseNumber || 'EXP-SIN-ASIGNAR'}</strong>
          </div>
          <div>
            <span className="text-slate-500 block text-[10px] uppercase font-semibold">Fecha de Emisión:</span>
            <span className="text-slate-900 font-medium">
              {new Date().toLocaleDateString('es-AR', { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>
          <div>
            <span className="text-slate-500 block text-[10px] uppercase font-semibold">Carátula / Objeto:</span>
            <span className="text-slate-800 font-medium">{currentCase?.title || 'Investigación preliminar'}</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[10px] uppercase font-semibold">Unidad Fiscal Interviniente:</span>
            <span className="text-slate-800 font-medium">{currentCase?.fiscalUnit || 'Fiscalía Especializada'}</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[10px] uppercase font-semibold">Fiscal a Cargo:</span>
            <span className="text-slate-800 font-medium">{currentCase?.leadProsecutor || 'Magistrado a designar'}</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[10px] uppercase font-semibold">Analista Responsable:</span>
            <span className="text-slate-800 font-medium">{currentUser.displayName} ({currentUser.email})</span>
          </div>
        </div>

        {/* Chain of Custody & Evidence Sources */}
        <div className="space-y-2">
          <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wide border-b border-slate-200 pb-1">
            1. Fuentes Documentales y Cadena de Custodia
          </h2>
          <div className="bg-slate-50 border border-slate-200 p-3 rounded text-[11px] space-y-1.5 font-mono">
            <div>
              <span className="text-slate-500">Archivo Original Incorporado: </span>
              <strong>{report?.filename || 'Sabana_Judicial_Autorizada.xlsx'}</strong>
            </div>
            <div>
              <span className="text-slate-500">Hash Criptográfico SHA-256 (Inalterable): </span>
              <span className="text-blue-900 font-bold select-all break-all">{report?.fileHashSha256 || '9f83a48e89c3ef724510b6426d2466a9e1866ef11488c9f282eb1de7e7fe8ec6'}</span>
            </div>
            <div>
              <span className="text-slate-500">Operador Emisor de la Sábana: </span>
              <span>{report?.operatorDetected || 'Operador de Telecomunicaciones Autorizado'}</span>
            </div>
            <div>
              <span className="text-slate-500">Total Registros Auditados: </span>
              <span>{records.length} procesados ({validRecords.length} válidos, {records.filter(r => r.isDuplicate).length} duplicados aislados)</span>
            </div>
          </div>
        </div>

        {/* Executive Findings */}
        <div className="space-y-3">
          <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wide border-b border-slate-200 pb-1">
            2. Resumen Ejecutivo de Interacciones y Antenas
          </h2>
          <p className="text-slate-700 text-xs">
            Sobre el número bajo análisis <strong className="font-mono text-blue-900">{targetNumber}</strong>, se identificaron los siguientes patrones comunicacionales de mayor frecuencia:
          </p>

          {/* Frequent Contacts Table */}
          <div className="border border-slate-200 rounded overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 font-semibold text-slate-700 border-b border-slate-200">
                <tr>
                  <th className="px-3 py-1.5">Interlocutor</th>
                  <th className="px-3 py-1.5">Alias / Etiqueta Investigativa</th>
                  <th className="px-3 py-1.5 text-right">Eventos</th>
                  <th className="px-3 py-1.5 text-right">Llamadas</th>
                  <th className="px-3 py-1.5 text-right">SMS</th>
                  <th className="px-3 py-1.5 text-right">Duración Total</th>
                  <th className="px-3 py-1.5 text-center">Balanza (Ent/Sal)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 font-mono text-[11px]">
                {frequentContacts.map((c) => (
                  <tr key={c.phoneNumber}>
                    <td className="px-3 py-1.5 font-bold text-slate-900">{c.phoneNumber}</td>
                    <td className="px-3 py-1.5 whitespace-nowrap">
                      {c.alias ? (
                        <span className="font-sans font-bold text-[10px] px-2 py-0.5 rounded bg-blue-50 text-blue-900 border border-blue-200">
                          🏷️ {c.alias} <span className="text-[9px] text-blue-700 font-normal">({c.category})</span>
                        </span>
                      ) : (
                        <span className="text-slate-400 font-sans text-[10px]">-</span>
                      )}
                    </td>
                    <td className="px-3 py-1.5 text-right font-bold text-slate-900">{c.totalEvents}</td>
                    <td className="px-3 py-1.5 text-right text-slate-700">{c.callCount}</td>
                    <td className="px-3 py-1.5 text-right text-slate-700">{c.smsCount}</td>
                    <td className="px-3 py-1.5 text-right text-slate-700">{Math.round(c.totalDurationSeconds / 60)} min</td>
                    <td className="px-3 py-1.5 text-center text-slate-700">{c.incomingCount} / {c.outgoingCount}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Frequent Antennas Table */}
          <div className="border border-slate-200 rounded overflow-hidden pt-2">
            <div className="bg-slate-100 px-3 py-1 font-semibold text-slate-700 text-xs border-b border-slate-200">
              Antenas / Celdas con Mayor Concurrencia
            </div>
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 font-semibold text-slate-700 border-b border-slate-200">
                <tr>
                  <th className="px-3 py-1.5 font-mono">ID Celda</th>
                  <th className="px-3 py-1.5">Operador</th>
                  <th className="px-3 py-1.5 text-right">Eventos</th>
                  <th className="px-3 py-1.5 text-center">Azimut</th>
                  <th className="px-3 py-1.5">Coordenadas</th>
                  <th className="px-3 py-1.5">Última Conexión</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 font-mono text-[11px]">
                {topAntennas.map((a) => (
                  <tr key={a.cellId}>
                    <td className="px-3 py-1.5 font-bold text-slate-900">{a.cellId}</td>
                    <td className="px-3 py-1.5 text-slate-700">{a.operator}</td>
                    <td className="px-3 py-1.5 text-right font-bold text-slate-900">{a.totalEvents}</td>
                    <td className="px-3 py-1.5 text-center text-slate-700">{a.azimuth !== null ? `${a.azimuth}°` : 'No consta'}</td>
                    <td className="px-3 py-1.5 text-slate-700">{a.latitude.toFixed(4)}, {a.longitude.toFixed(4)}</td>
                    <td className="px-3 py-1.5 text-slate-700 text-[10px]">{a.lastSeen.replace('T', ' ').substring(0, 16)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Mandatory Methodological and Legal Disclaimer */}
        <div className="border border-amber-300 bg-amber-50/60 p-4 rounded-lg space-y-2 text-[11px] text-slate-800 leading-relaxed">
          <div className="font-bold text-amber-900 flex items-center space-x-1.5">
            <AlertTriangle className="w-4 h-4 text-amber-800 shrink-0" />
            <span>3. Limitaciones Metodológicas y Consideraciones Legales Periciales</span>
          </div>
          <ol className="list-decimal pl-5 space-y-1 text-slate-700">
            <li>
              <strong>Naturaleza de la celda de telefonía:</strong> El registro de una celda o antena identifica únicamente la estación base transmisora (BTS/NodeB/eNodeB) de la prestadora de telecomunicaciones que enrutó la comunicación. En ningún caso constituye una coordenada satelital GPS milimétrica ni garantiza la presencia física in situ del usuario o aparato telefónico en la torre.
            </li>
            <li>
              <strong>Sector y Azimut:</strong> La orientación del azimut informada corresponde a la dirección angular del lóbulo principal del panel de antena. No representa un radio de cobertura cerrado ni medida de propagación electromagnética de campo.
            </li>
            <li>
              <strong>Prohibición de inferencias no verificables:</strong> La secuencia cronológica ilustra el orden temporal de las activaciones en la sábana; no debe interpretarse automáticamente como una trayectoria o ruta de desplazamiento comprobada salvo concurrencia de otros elementos periciales independientes.
            </li>
            <li>
              <strong>Integridad de los datos:</strong> Las métricas fueron calculadas aislando duplicados y validando el formato internacional E.164, sin alteración de las filas crudas originales de la operadora.
            </li>
          </ol>
        </div>

        {/* Official Signature Section */}
        <div className="pt-12 flex justify-between items-end border-t border-slate-300 text-xs">
          <div className="space-y-1">
            <p className="text-slate-500 font-mono text-[10px]">
              Sello de Integridad Forense: {report?.fileHashSha256 ? report.fileHashSha256.substring(0, 24) : 'SHA-256'}
            </p>
            <p className="text-slate-500 text-[10px]">
              Generado mediante Sistema Institucional Análisis Telefónico MPF
            </p>
          </div>

          <div className="text-center space-y-1 w-64 border-t border-slate-800 pt-2">
            <div className="font-bold text-slate-900">{currentUser.displayName}</div>
            <div className="text-slate-600 text-[11px]">Analista Forense / Perito Oficial</div>
            <div className="text-slate-500 text-[10px]">{currentUser.department}</div>
          </div>
        </div>

      </div>
    </div>
  );
};
