import React from 'react';
import { Shield, FileText, Lock, User, RefreshCw } from 'lucide-react';
import { ProsecutionCase, UserProfile } from '../../types';

interface NavbarProps {
  currentCase: ProsecutionCase | null;
  cases: ProsecutionCase[];
  onSelectCase: (c: ProsecutionCase) => void;
  currentUser: UserProfile;
  onChangeRole: (r: 'admin' | 'analista' | 'consulta') => void;
  onRefreshData?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentCase,
  cases,
  onSelectCase,
  currentUser,
  onChangeRole,
  onRefreshData
}) => {
  return (
    <header className="bg-slate-900 border-b border-slate-800 text-slate-100 sticky top-0 z-40 px-4 py-2.5">
      <div className="flex items-center justify-between">
        {/* Brand & Emblem */}
        <div className="flex items-center space-x-3">
          <div className="bg-blue-900/60 border border-blue-500/40 p-2 rounded-lg flex items-center justify-center text-blue-400 shadow-inner">
            <Shield className="w-5 h-5 text-blue-400" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-bold tracking-tight text-white text-base">ANÁLISIS TELEFÓNICO</span>
              <span className="text-[10px] uppercase font-semibold bg-blue-950/80 text-blue-300 border border-blue-800/80 px-2 py-0.5 rounded">
                Ministerio Público Fiscal
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Sistema Forense de Depuración y Cartografía Pericial de Sábanas
            </p>
          </div>
        </div>

        {/* Center: Active Case Switcher */}
        <div className="hidden md:flex items-center bg-slate-950/70 border border-slate-800 rounded-lg px-3 py-1.5 space-x-3">
          <FileText className="w-4 h-4 text-amber-400" />
          <div className="flex flex-col text-left">
            <span className="text-[10px] uppercase font-semibold text-slate-400">Expediente Activo</span>
            <select
              value={currentCase?.id || ''}
              onChange={(e) => {
                const found = cases.find(c => c.id === e.target.value);
                if (found) onSelectCase(found);
              }}
              className="bg-transparent text-xs font-medium text-slate-200 outline-none cursor-pointer pr-4"
            >
              {cases.map(c => (
                <option key={c.id} value={c.id} className="bg-slate-900 text-slate-200">
                  {c.caseNumber} - {c.title.substring(0, 36)}...
                </option>
              ))}
            </select>
          </div>
          <span className="text-[10px] px-2 py-0.5 rounded font-mono font-semibold uppercase bg-emerald-950/70 text-emerald-400 border border-emerald-800/60">
            {currentCase?.status.replace('_', ' ') || 'ACTIVO'}
          </span>
        </div>

        {/* Right: Security Badge & User Profile */}
        <div className="flex items-center space-x-3">
          {onRefreshData && (
            <button
              onClick={onRefreshData}
              title="Actualizar datos"
              className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-slate-200 rounded transition"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          )}

          <div className="hidden lg:flex items-center space-x-1.5 text-xs bg-slate-950/60 text-slate-300 border border-slate-800 px-2.5 py-1 rounded">
            <Lock className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-[11px] font-mono text-emerald-400 font-medium">Cadena de Custodia OK</span>
          </div>

          {/* User & Role Switcher */}
          <div className="flex items-center space-x-2 pl-2 border-l border-slate-800">
            <div className="w-7 h-7 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300">
              <User className="w-4 h-4" />
            </div>
            <div className="hidden sm:flex flex-col text-right">
              <span className="text-xs font-medium text-slate-200">{currentUser.displayName}</span>
              <div className="flex items-center justify-end space-x-1">
                <span className="text-[10px] text-slate-400">Rol:</span>
                <select
                  value={currentUser.role}
                  onChange={(e) => onChangeRole(e.target.value as any)}
                  className="bg-transparent text-[11px] font-semibold text-blue-400 cursor-pointer outline-none"
                >
                  <option value="admin" className="bg-slate-900 text-slate-200">Administrador</option>
                  <option value="analista" className="bg-slate-900 text-slate-200">Analista Forense</option>
                  <option value="consulta" className="bg-slate-900 text-slate-200">Consulta (Solo Lectura)</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
