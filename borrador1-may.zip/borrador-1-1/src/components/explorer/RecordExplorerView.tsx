import React, { useState, useMemo } from 'react';
import { 
  Database, 
  Search, 
  Filter, 
  Download, 
  Eye, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle, 
  ChevronLeft, 
  ChevronRight,
  ShieldAlert,
  ArrowUpDown,
  History,
  FileSpreadsheet,
  Smartphone,
  Layers
} from 'lucide-react';
import { NormalizedCDR, AnalysisFilterState, UserProfile, PhoneTag } from '../../types';
import { filterCDRRecords } from '../../services/analysisEngine';
import { logAuditEvent } from '../../services/auditService';

interface RecordExplorerViewProps {
  records: NormalizedCDR[];
  currentUser: UserProfile;
  phoneTags?: Record<string, PhoneTag>;
}

export const RecordExplorerView: React.FC<RecordExplorerViewProps> = ({
  records,
  currentUser,
  phoneTags
}) => {
  const [filters, setFilters] = useState<AnalysisFilterState>({
    targetNumber: '',
    selectedContact: '',
    direction: 'TODOS',
    eventType: 'TODOS',
    mirrorFilter: 'INCLUDE_ALL', // Can toggle between exclude or include
    imeiFilter: 'TODOS',
    startDate: '',
    endDate: '',
    startHour: 0,
    endHour: 23,
    operator: 'TODOS',
    cellId: 'TODAS',
    minDuration: 0,
    searchTerm: ''
  });

  const [statusFilter, setStatusFilter] = useState<'ALL' | 'VALID' | 'WARNING' | 'REJECTED'>('ALL');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const pageSize = 25;

  const [inspectedRecord, setInspectedRecord] = useState<NormalizedCDR | null>(null);

  // Distinct IMEIs for filtering
  const distinctImeis = useMemo(() => {
    const set = new Set<string>();
    records.forEach(r => {
      if (r.imei && r.imei !== '-') set.add(r.imei);
    });
    return Array.from(set);
  }, [records]);

  const getContactTag = (num: string): PhoneTag | undefined => {
    if (!phoneTags || !num) return undefined;
    const clean = num.replace(/[^0-9]/g, '');
    const short10 = clean.slice(-10);
    return phoneTags[num] || phoneTags[clean] || (short10 ? phoneTags[short10] : undefined);
  };

  // Distinct operators and cells
  const operators = useMemo(() => {
    return Array.from(new Set(records.map(r => r.operator).filter(Boolean)));
  }, [records]);

  // Filtered dataset
  const filteredRecords = useMemo(() => {
    let result = filterCDRRecords(records, filters, true);
    if (statusFilter !== 'ALL') {
      result = result.filter(r => r.status === statusFilter);
    }
    return result;
  }, [records, filters, statusFilter]);

  const totalPages = Math.ceil(filteredRecords.length / pageSize) || 1;
  const paginatedRecords = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredRecords.slice(start, start + pageSize);
  }, [filteredRecords, currentPage]);

  const handleExportCsv = () => {
    if (filteredRecords.length === 0) return;

    // Export with exact columns as in user Image 2:
    // Teléfono, Tipo, Número A, Número B, Fecha, Hora, Duracion, IMEI, LATITUD, LONGITUD, Azimuth, Tipo 2, Color
    const headers = [
      'Teléfono',
      'Tipo',
      'Número A',
      'Número B',
      'Fecha',
      'Hora',
      'Duracion',
      'IMEI',
      'LATITUD',
      'LONGITUD',
      'Azimuth',
      'Tipo 2',
      'Color',
      'LATITUD_DECIMAL_WGS84',
      'LONGITUD_DECIMAL_WGS84',
      'ESTADO_AUDITORIA',
      'FILA_ORIGINAL'
    ];

    const rows = filteredRecords.map(r => [
      `"${r.targetPhone}"`,
      `"${r.rawEventType}"`,
      `"${r.rawSourceNumber}"`,
      `"${r.rawDestinationNumber}"`,
      `"${r.rawDate}"`,
      `"${r.rawTime}"`,
      r.durationSeconds,
      `"${r.rawImei || ''}"`,
      `"${r.rawLatitude || ''}"`,
      `"${r.rawLongitude || ''}"`,
      `"${r.rawAzimuth || ''}"`,
      `"${r.tipo2}"`,
      `"${r.colorTag}"`,
      r.latitude ?? '',
      r.longitude ?? '',
      r.status,
      r.rowNumber
    ]);

    const csvContent = [headers.join(','), ...rows.map(row => row.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Sabana_Procesada_Tipo2_Color_${new Date().toISOString().substring(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    logAuditEvent(
      'EXPORT_CSV',
      `Exportación de ${filteredRecords.length} registros con columnas Tipo 2 y Color a CSV`,
      currentUser.email,
      currentUser.uid
    );
  };

  const getColorPill = (colorTag: string, tipo2: string) => {
    switch (colorTag) {
      case 'Azul':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-blue-950 text-blue-300 border border-blue-700">
            {tipo2} (Azul)
          </span>
        );
      case 'Verde':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-950 text-emerald-300 border border-emerald-700">
            {tipo2} (Verde)
          </span>
        );
      case 'Amarillo':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-950 text-amber-300 border border-amber-600">
            {tipo2} (Amarillo)
          </span>
        );
      case 'Naranja':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-orange-950 text-orange-300 border border-orange-700">
            {tipo2} (Naranja)
          </span>
        );
      case 'Morado':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-purple-950 text-purple-300 border border-purple-700">
            {tipo2} (Morado)
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-800 text-slate-300 border border-slate-700">
            {tipo2}
          </span>
        );
    }
  };

  return (
    <div className="space-y-4">
      {/* Header and Export Action */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center space-x-2">
            <Database className="w-5 h-5 text-blue-400" />
            <span>Explorador Forense con Normalización de Sábana (Tipo 2 y Espejos)</span>
          </h1>
          <p className="text-xs text-slate-400">
            Visualización pericial fiel al formato oficial: llamadas de voz, paquetes de datos, coordenadas DMS y conmutaciones espejo.
          </p>
        </div>

        <button
          onClick={handleExportCsv}
          disabled={filteredRecords.length === 0}
          className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg flex items-center space-x-2 transition self-start disabled:opacity-50 shadow"
        >
          <Download className="w-4 h-4" />
          <span>Exportar Copia Depurada con "Tipo 2" y "Color" ({filteredRecords.length})</span>
        </button>
      </div>

      {/* Multi-filter Panel */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-4 lg:grid-cols-6 gap-3 text-xs">
          {/* General Search */}
          <div className="lg:col-span-2">
            <label className="block text-slate-400 font-medium mb-1">Búsqueda rápida</label>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2.5" />
              <input
                type="text"
                placeholder="Número, IMEI, tipo o celda..."
                value={filters.searchTerm}
                onChange={(e) => {
                  setFilters({ ...filters, searchTerm: e.target.value });
                  setCurrentPage(1);
                }}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-8 pr-2.5 py-1.5 text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500 font-mono"
              />
            </div>
          </div>

          {/* Mirror Filter (Espejos) */}
          <div>
            <label className="block text-slate-400 font-medium mb-1 flex items-center justify-between">
              <span>Tratamiento de Espejos</span>
              <span className="text-[10px] text-amber-400 font-bold">Img 3</span>
            </label>
            <select
              value={filters.mirrorFilter}
              onChange={(e) => {
                setFilters({ ...filters, mirrorFilter: e.target.value as any });
                setCurrentPage(1);
              }}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-blue-500 font-medium"
            >
              <option value="INCLUDE_ALL">Incluir Todo (Voz + Datos + Espejos)</option>
              <option value="EXCLUDE_MIRRORS">Excluir Espejos (Sin doble conteo)</option>
              <option value="ONLY_MIRRORS">Solo Espejos (Tránsito / Transfer)</option>
            </select>
          </div>

          {/* Event Type */}
          <div>
            <label className="block text-slate-400 font-medium mb-1">Tipo de Evento</label>
            <select
              value={filters.eventType}
              onChange={(e) => {
                setFilters({ ...filters, eventType: e.target.value as any });
                setCurrentPage(1);
              }}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-blue-500"
            >
              <option value="TODOS">Todos los tipos</option>
              <option value="LLAMADAS">Llamadas (VOZ ENTRANTE / SALIENTE)</option>
              <option value="DATOS">Datos (Internet APN)</option>
              <option value="ESPEJOS">Espejos (TRANSITO / TRANSFER)</option>
            </select>
          </div>

          {/* IMEI Filter */}
          <div>
            <label className="block text-slate-400 font-medium mb-1 flex items-center space-x-1">
              <Smartphone className="w-3 h-3 text-purple-400" />
              <span>Filtrar por IMEI</span>
            </label>
            <select
              value={filters.imeiFilter}
              onChange={(e) => {
                setFilters({ ...filters, imeiFilter: e.target.value });
                setCurrentPage(1);
              }}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-blue-500 font-mono text-[11px]"
            >
              <option value="TODOS">Todos los IMEIs</option>
              {distinctImeis.map(imei => (
                <option key={imei} value={imei}>IMEI: {imei}</option>
              ))}
            </select>
          </div>

          {/* Date Filter */}
          <div>
            <label className="block text-slate-400 font-medium mb-1">Fecha Desde</label>
            <input
              type="date"
              value={filters.startDate}
              onChange={(e) => {
                setFilters({ ...filters, startDate: e.target.value });
                setCurrentPage(1);
              }}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2 py-1 text-slate-200 focus:outline-none focus:border-blue-500 text-xs"
            />
          </div>
        </div>
      </div>

      {/* Main Forensic Table matching Image 1 and Image 2 */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800 uppercase tracking-wider text-[11px]">
              <tr>
                <th className="px-3 py-2.5 w-10 text-slate-500 font-mono">Fila</th>
                <th className="px-3 py-2.5 font-mono">Teléfono</th>
                <th className="px-3 py-2.5">Tipo Original</th>
                <th className="px-3 py-2.5 text-center">Tipo 2 / Color</th>
                <th className="px-3 py-2.5 font-mono">Número A</th>
                <th className="px-3 py-2.5 font-mono">Número B</th>
                <th className="px-3 py-2.5 font-mono">Fecha</th>
                <th className="px-3 py-2.5 font-mono">Hora</th>
                <th className="px-3 py-2.5 text-right font-mono">Duración</th>
                <th className="px-3 py-2.5 font-mono">IMEI</th>
                <th className="px-3 py-2.5 font-mono">LATITUD</th>
                <th className="px-3 py-2.5 font-mono">LONGITUD</th>
                <th className="px-3 py-2.5 text-center font-mono">Azimuth</th>
                <th className="px-3 py-2.5 text-center w-14">Auditar</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 font-mono text-[11px]">
              {paginatedRecords.map((r) => {
                const isSecondaryImei = r.imei === '865746050686190';
                return (
                  <tr 
                    key={r.id} 
                    className={`hover:bg-slate-800/40 transition cursor-pointer ${
                      r.isMirror ? 'bg-purple-950/20' : 
                      r.eventType === 'DATOS' ? 'bg-amber-950/10' : ''
                    }`}
                    onClick={() => setInspectedRecord(r)}
                  >
                    <td className="px-3 py-2 text-slate-500">{r.rowNumber}</td>
                    <td className="px-3 py-2 font-bold text-slate-200 whitespace-nowrap">
                      {r.rawSourceNumber === '6141769216' || r.rawDestinationNumber === '6141769216' ? '6141769216' : r.targetPhone}
                    </td>
                    <td className="px-3 py-2 font-sans font-medium whitespace-nowrap text-slate-300">
                      {r.rawEventType}
                    </td>
                    <td className="px-3 py-2 text-center whitespace-nowrap font-sans">
                      {getColorPill(r.colorTag, r.tipo2)}
                    </td>
                    <td className="px-3 py-2 whitespace-nowrap font-bold text-blue-400">
                      <div>{r.rawSourceNumber}</div>
                      {getContactTag(r.rawSourceNumber) && (
                        <span className="text-[8.5px] font-sans font-bold text-blue-300 bg-blue-950/80 border border-blue-800 px-1 py-0.2 rounded inline-block mt-0.5">
                          🏷️ {getContactTag(r.rawSourceNumber)?.alias}
                        </span>
                      )}
                    </td>
                    <td className={`px-3 py-2 whitespace-nowrap font-bold ${
                      r.rawDestinationNumber.includes('itelcel') ? 'text-amber-400 font-sans text-[10px]' : 'text-purple-400'
                    }`}>
                      <div>{r.rawDestinationNumber}</div>
                      {getContactTag(r.rawDestinationNumber) && (
                        <span className="text-[8.5px] font-sans font-bold text-purple-300 bg-purple-950/80 border border-purple-800 px-1 py-0.2 rounded inline-block mt-0.5">
                          🏷️ {getContactTag(r.rawDestinationNumber)?.alias}
                        </span>
                      )}
                    </td>
                    <td className="px-3 py-2 whitespace-nowrap text-slate-300">
                      {r.rawDate}
                    </td>
                    <td className="px-3 py-2 whitespace-nowrap text-slate-300">
                      {r.rawTime}
                    </td>
                    <td className="px-3 py-2 text-right whitespace-nowrap text-slate-200 font-semibold">
                      {r.durationSeconds}
                    </td>
                    <td className={`px-3 py-2 whitespace-nowrap ${
                      isSecondaryImei ? 'text-amber-400 font-bold bg-amber-950/30 rounded px-1' : 'text-slate-400'
                    }`}>
                      {r.rawImei || '-'}
                    </td>
                    <td className="px-3 py-2 whitespace-nowrap text-slate-300">
                      {r.rawLatitude || '-'}
                    </td>
                    <td className="px-3 py-2 whitespace-nowrap text-slate-300">
                      {r.rawLongitude || '-'}
                    </td>
                    <td className="px-3 py-2 text-center whitespace-nowrap text-amber-400 font-semibold">
                      {r.rawAzimuth || '-'}
                    </td>
                    <td className="px-3 py-2 text-center whitespace-nowrap">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setInspectedRecord(r);
                        }}
                        className="p-1 hover:bg-slate-700 text-slate-400 hover:text-white rounded"
                        title="Ver procedencia"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Pagination bar */}
        <div className="p-3 bg-slate-950/80 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <div>
            Mostrando {filteredRecords.length > 0 ? (currentPage - 1) * pageSize + 1 : 0} -{' '}
            {Math.min(currentPage * pageSize, filteredRecords.length)} de{' '}
            <strong className="text-slate-200">{filteredRecords.length.toLocaleString()}</strong> registros
            {filters.mirrorFilter === 'INCLUDE_ALL' && (
              <span className="ml-2 text-purple-400 font-medium">
                (Incluyendo registros espejos de conmutación)
              </span>
            )}
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded disabled:opacity-40 transition"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="font-mono text-slate-300">
              Página {currentPage} de {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded disabled:opacity-40 transition"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Modal: Forensic Provenance Inspector */}
      {inspectedRecord && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl max-w-2xl w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center space-x-2">
                <History className="w-5 h-5 text-blue-400" />
                <h3 className="text-base font-bold text-white">Trazabilidad y Comparativa de Registro</h3>
              </div>
              <button
                onClick={() => setInspectedRecord(null)}
                className="text-slate-400 hover:text-white text-xl font-bold"
              >
                ×
              </button>
            </div>

            <div className="space-y-4 text-xs font-mono">
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 grid grid-cols-2 gap-2">
                <div>
                  <span className="text-slate-500 block text-[10px]">Archivo de Origen:</span>
                  <span className="text-slate-200">{inspectedRecord.sourceFile}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">Fila en la Sábana:</span>
                  <span className="text-blue-400 font-bold">Fila #{inspectedRecord.rowNumber}</span>
                </div>
              </div>

              {/* Classification details */}
              <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400 font-sans">Categorización Tipo 2:</span>
                  {getColorPill(inspectedRecord.colorTag, inspectedRecord.tipo2)}
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400 font-sans">Condición de Espejo:</span>
                  <span className={inspectedRecord.isMirror ? 'text-amber-400 font-bold' : 'text-slate-400'}>
                    {inspectedRecord.isMirror ? `SÍ (${inspectedRecord.mirrorType})` : 'NO (Registro Directo)'}
                  </span>
                </div>
                {inspectedRecord.imei && (
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400 font-sans">IMEI Asociado:</span>
                    <span className="text-purple-300 font-bold">{inspectedRecord.imei}</span>
                  </div>
                )}
                {inspectedRecord.latitude !== null && (
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400 font-sans">Conversión DMS a WGS84:</span>
                    <span className="text-emerald-400 font-bold">
                      {inspectedRecord.rawLatitude} / {inspectedRecord.rawLongitude} → {inspectedRecord.latitude.toFixed(6)}, {inspectedRecord.longitude?.toFixed(6)}
                    </span>
                  </div>
                )}
              </div>

              <div className="space-y-1">
                <h4 className="font-semibold text-slate-300 text-xs font-sans">Dictamen Pericial:</h4>
                <ul className="list-disc pl-4 space-y-0.5 text-slate-400 text-[11px] font-sans">
                  {inspectedRecord.validationNotes.map((note, idx) => (
                    <li key={idx}>{note}</li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="flex justify-end pt-3 border-t border-slate-800">
              <button
                onClick={() => setInspectedRecord(null)}
                className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-medium rounded-lg text-xs"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
