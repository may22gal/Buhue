import React from 'react';
import { 
  LayoutDashboard, 
  Briefcase, 
  UploadCloud, 
  Database, 
  PhoneCall, 
  Network,
  MapPin, 
  FileCheck2, 
  Radio, 
  ShieldCheck,
  AlertTriangle
} from 'lucide-react';

export type NavTab = 
  | 'dashboard'
  | 'cases'
  | 'import'
  | 'explorer'
  | 'analysis'
  | 'network'
  | 'map'
  | 'reports'
  | 'integrations'
  | 'audit';

interface SidebarProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  recordCount: number;
  caseCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  recordCount,
  caseCount
}) => {
  const navItems: { id: NavTab; label: string; icon: React.ReactNode; badge?: string | number }[] = [
    { id: 'dashboard', label: 'Panel General', icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'cases', label: 'Expedientes', icon: <Briefcase className="w-4 h-4" />, badge: caseCount },
    { id: 'import', label: 'Importar Sábana', icon: <UploadCloud className="w-4 h-4" /> },
    { id: 'explorer', label: 'Explorador CDR', icon: <Database className="w-4 h-4" />, badge: recordCount },
    { id: 'analysis', label: 'Análisis por Número', icon: <PhoneCall className="w-4 h-4" /> },
    { id: 'network', label: 'Red de Vínculos (Final)', icon: <Network className="w-4 h-4 text-amber-400" /> },
    { id: 'map', label: 'Mapa de Antenas', icon: <MapPin className="w-4 h-4" /> },
    { id: 'reports', label: 'Dictamen Pericial', icon: <FileCheck2 className="w-4 h-4" /> },
    { id: 'integrations', label: 'OSINT / Geomatrix', icon: <Radio className="w-4 h-4" /> },
    { id: 'audit', label: 'Auditoría Forense', icon: <ShieldCheck className="w-4 h-4" /> },
  ];

  return (
    <aside className="w-64 bg-slate-950 border-r border-slate-800 text-slate-300 flex flex-col justify-between shrink-0 select-none">
      <div className="p-3 space-y-1">
        <div className="px-3 py-2 text-[11px] font-semibold tracking-wider text-slate-500 uppercase">
          Módulos Periciales
        </div>
        <nav className="space-y-1">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-lg transition-all ${
                  isActive
                    ? 'bg-blue-600/20 text-blue-300 border border-blue-500/30 shadow-sm font-semibold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                }`}
              >
                <div className="flex items-center space-x-2.5">
                  <span className={isActive ? 'text-blue-400' : 'text-slate-400'}>{item.icon}</span>
                  <span>{item.label}</span>
                </div>
                {item.badge !== undefined && (
                  <span
                    className={`text-[10px] px-1.5 py-0.2 rounded font-mono font-medium ${
                      isActive
                        ? 'bg-blue-500/20 text-blue-300 border border-blue-400/30'
                        : 'bg-slate-800/80 text-slate-400'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Institutional Legal Warning Notice */}
      <div className="p-3 m-3 bg-slate-900/90 border border-amber-900/50 rounded-lg text-slate-400 text-[11px] space-y-1.5">
        <div className="flex items-center space-x-1.5 text-amber-400 font-semibold text-[11px]">
          <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
          <span>Advertencia Procesal</span>
        </div>
        <p className="text-[10px] leading-relaxed text-slate-400">
          Uso restringido a personal judicial autorizado. Los registros crudos y transformaciones quedan registrados bajo cadena de custodia.
        </p>
      </div>
    </aside>
  );
};
