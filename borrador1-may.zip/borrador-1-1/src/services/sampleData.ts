import { NormalizedCDR, ProsecutionCase, ImportValidationReport } from '../types';
import { parseCoordinateDMS } from './cdrParser';

export const INITIAL_SYNTHETIC_CASE: ProsecutionCase = {
  id: 'case-demo-chih-2022',
  caseNumber: 'EXP-2022-CHIH-0492',
  title: 'Investigación Penal Preparatoria - Intervención y Sábana Telefónica Telcel',
  description: 'Análisis de sábanas telefónicas autorizadas judicialmente. Incluye registros de voz directa, paquetes de datos IP (APN) y conmutaciones espejo (tránsito y transferencias) para el número objetivo de Chihuahua.',
  fiscalUnit: 'Fiscalía Especializada en Investigación de Delitos Complejos - Distrito Morelos (Chihuahua)',
  leadProsecutor: 'Lic. Roberto Morales S. (Agente del Ministerio Público)',
  status: 'en_analisis',
  assignedUsers: ['user-fiscal-01', 'user-analista-02'],
  createdBy: 'user-fiscal-01',
  createdAt: '2022-05-20T09:00:00.000Z',
  updatedAt: '2022-06-15T18:30:00.000Z',
  targetNumbers: ['+526271218386', '+526141769216'],
  phoneTags: {
    '6271134588': { phoneNumber: '6271134588', alias: 'Dealer', category: 'INVESTIGACION', updatedAt: '2025-01-25T10:00:00Z', updatedBy: 'user-fiscal-01' },
    '6271474227': { phoneNumber: '6271474227', alias: 'Papá', category: 'FAMILIAR', updatedAt: '2025-01-25T10:00:00Z', updatedBy: 'user-fiscal-01' },
    '6271449752': { phoneNumber: '6271449752', alias: 'Tío', category: 'FAMILIAR', updatedAt: '2025-01-25T10:00:00Z', updatedBy: 'user-fiscal-01' },
    '6271148264': { phoneNumber: '6271148264', alias: 'Didi', category: 'TRANSPORTE', updatedAt: '2025-01-25T10:00:00Z', updatedBy: 'user-fiscal-01' },
    '6271231031': { phoneNumber: '6271231031', alias: 'Ferretería', category: 'COMERCIO', updatedAt: '2025-01-25T10:00:00Z', updatedBy: 'user-fiscal-01' },
    '6271030501': { phoneNumber: '6271030501', alias: 'Tienda', category: 'COMERCIO', updatedAt: '2025-01-25T10:00:00Z', updatedBy: 'user-fiscal-01' },
    '6271430295': { phoneNumber: '6271430295', alias: 'Mamá', category: 'FAMILIAR', updatedAt: '2025-01-25T10:00:00Z', updatedBy: 'user-fiscal-01' }
  }
};

export function generateSyntheticCDRs(): { records: NormalizedCDR[]; report: ImportValidationReport } {
  const targetNumber = '+526141769216'; // 6141769216 de las imágenes del usuario
  const targetRaw = '6141769216';

  const antenna1LatDMS = '28°46\'52"N';
  const antenna1LngDMS = '106°10\'8"W';
  const antenna1Lat = parseCoordinateDMS(antenna1LatDMS)!;
  const antenna1Lng = parseCoordinateDMS(antenna1LngDMS)!;

  const antenna2LatDMS = '28°47\'15"N';
  const antenna2LngDMS = '106°9\'53"W';
  const antenna2Lat = parseCoordinateDMS(antenna2LatDMS)!;
  const antenna2Lng = parseCoordinateDMS(antenna2LngDMS)!;

  const antenna3LatDMS = '28°38\'20"N';
  const antenna3LngDMS = '106°4\'45"W';
  const antenna3Lat = parseCoordinateDMS(antenna3LatDMS)!;
  const antenna3Lng = parseCoordinateDMS(antenna3LngDMS)!;

  const imeiPrimary = '351813091633410';
  const imeiSecondary = '865746050686190'; // IMEI detectado en espejos

  const records: NormalizedCDR[] = [];
  let rowId = 1;

  // 1. Initial batch exactly matching Image 1 & 2
  const initialExactRows = [
    {
      tipo: 'VOZ ENTRANTE',
      tipo2: 'LL-E',
      color: 'Azul',
      numA: '4535348400',
      numB: targetRaw,
      fecha: '22/05/2022',
      hora: '13:21:00',
      dur: 619,
      imei: imeiPrimary,
      latDMS: antenna1LatDMS,
      lngDMS: antenna1LngDMS,
      lat: antenna1Lat,
      lng: antenna1Lng,
      az: 130
    },
    {
      tipo: 'DATOS',
      tipo2: 'Internet',
      color: 'Amarillo',
      numA: targetRaw,
      numB: 'internet.itelcel.com',
      fecha: '22/05/2022',
      hora: '22:43:14',
      dur: 491,
      imei: imeiPrimary,
      latDMS: antenna1LatDMS,
      lngDMS: antenna1LngDMS,
      lat: antenna1Lat,
      lng: antenna1Lng,
      az: 130
    },
    {
      tipo: 'DATOS',
      tipo2: 'Internet',
      color: 'Amarillo',
      numA: targetRaw,
      numB: 'internet.itelcel.com',
      fecha: '22/05/2022',
      hora: '22:43:14',
      dur: 491,
      imei: imeiPrimary,
      latDMS: antenna1LatDMS,
      lngDMS: antenna1LngDMS,
      lat: antenna1Lat,
      lng: antenna1Lng,
      az: 130
    },
    {
      tipo: 'DATOS',
      tipo2: 'Internet',
      color: 'Amarillo',
      numA: targetRaw,
      numB: 'internet.itelcel.com',
      fecha: '23/05/2022',
      hora: '02:12:23',
      dur: 257,
      imei: imeiPrimary,
      latDMS: antenna2LatDMS,
      lngDMS: antenna2LngDMS,
      lat: antenna2Lat,
      lng: antenna2Lng,
      az: 210
    },
    {
      tipo: 'VOZ ENTRANTE',
      tipo2: 'LL-E',
      color: 'Azul',
      numA: '6143791925',
      numB: targetRaw,
      fecha: '23/05/2022',
      hora: '07:16:55',
      dur: 241,
      imei: imeiPrimary,
      latDMS: antenna2LatDMS,
      lngDMS: antenna2LngDMS,
      lat: antenna2Lat,
      lng: antenna2Lng,
      az: 210
    },
    {
      tipo: 'VOZ SALIENTE',
      tipo2: 'LL-S',
      color: 'Verde',
      numA: '6143791925',
      numB: targetRaw,
      fecha: '23/05/2022',
      hora: '08:16:39',
      dur: 240,
      imei: null,
      latDMS: '-',
      lngDMS: '-',
      lat: null,
      lng: null,
      az: null
    },
    {
      tipo: 'DATOS',
      tipo2: 'Internet',
      color: 'Amarillo',
      numA: targetRaw,
      numB: 'internet.itelcel.com',
      fecha: '23/05/2022',
      hora: '08:42:22',
      dur: 7200,
      imei: imeiPrimary,
      latDMS: antenna2LatDMS,
      lngDMS: antenna2LngDMS,
      lat: antenna2Lat,
      lng: antenna2Lng,
      az: 210
    },
    {
      tipo: 'DATOS',
      tipo2: 'Internet',
      color: 'Amarillo',
      numA: targetRaw,
      numB: 'internet.itelcel.com',
      fecha: '23/05/2022',
      hora: '08:42:22',
      dur: 4500,
      imei: imeiPrimary,
      latDMS: antenna2LatDMS,
      lngDMS: antenna2LngDMS,
      lat: antenna2Lat,
      lng: antenna2Lng,
      az: 210
    },
    {
      tipo: 'DATOS',
      tipo2: 'Internet',
      color: 'Amarillo',
      numA: targetRaw,
      numB: 'internet.itelcel.com',
      fecha: '23/05/2022',
      hora: '08:42:22',
      dur: 2700,
      imei: imeiPrimary,
      latDMS: antenna2LatDMS,
      lngDMS: antenna2LngDMS,
      lat: antenna2Lat,
      lng: antenna2Lng,
      az: 210
    }
  ];

  initialExactRows.forEach(row => {
    const isTargetA = row.numA === targetRaw;
    const isData = row.tipo === 'DATOS';
    const normSrc = isData ? targetNumber : (row.numA.startsWith('+') ? row.numA : `+52${row.numA}`);
    const normDst = isData ? row.numB : (row.numB.startsWith('+') ? row.numB : `+52${row.numB}`);

    const dtParts = row.fecha.split('/');
    const tmParts = row.hora.split(':');
    const isoDate = new Date(Date.UTC(
      parseInt(dtParts[2], 10),
      parseInt(dtParts[1], 10) - 1,
      parseInt(dtParts[0], 10),
      parseInt(tmParts[0], 10),
      parseInt(tmParts[1], 10),
      parseInt(tmParts[2], 10)
    )).toISOString();

    records.push({
      id: `cdr-${rowId.toString().padStart(5, '0')}`,
      importId: 'imp-chih-001',
      rowNumber: rowId + 1,
      caseId: INITIAL_SYNTHETIC_CASE.id,
      targetPhone: targetNumber,
      sourceNumber: normSrc,
      rawSourceNumber: row.numA,
      destinationNumber: normDst,
      rawDestinationNumber: row.numB,
      timestamp: isoDate,
      rawDate: row.fecha,
      rawTime: row.hora,
      rawTimestamp: `${row.fecha} ${row.hora}`,
      eventType: row.tipo === 'DATOS' ? 'DATOS' : (row.tipo === 'VOZ ENTRANTE' ? 'LLAMADA_ENTRANTE' : 'LLAMADA_SALIENTE'),
      rawEventType: row.tipo,
      tipo2: row.tipo2,
      colorTag: row.color,
      durationSeconds: row.dur,
      rawDuration: String(row.dur),
      imei: row.imei,
      rawImei: row.imei || '-',
      cellId: row.lat !== null ? `CEL-CHIH-${row.az}°` : 'SIN_CELDA',
      rawCellId: row.lat !== null ? `CHIH_${row.az}` : '-',
      operator: 'Telcel México',
      latitude: row.lat,
      longitude: row.lng,
      rawLatitude: row.latDMS,
      rawLongitude: row.lngDMS,
      azimuth: row.az,
      rawAzimuth: row.az !== null ? `${row.az}°` : '-',
      sourceFile: 'Sabana_Telcel_Oficio_Chihuahua_6141769216.xlsx',
      status: 'VALID',
      validationNotes: ['Registro normalizado correctamente conforme a estándar E.164 (+52)'],
      transformations: [
        'Prefijo local Chihuahua 614 normalizado a E.164 +52614...',
        'Coordenadas DMS convertidas a WGS84 decimal',
        'Etiquetas Tipo 2 y Color asignadas'
      ],
      isDuplicate: false,
      isMirror: false,
      mirrorType: 'NONE'
    });
    rowId++;
  });

  // 2. Batch matching Image 3: "Espejos" (VOZ TRANSITO y VOZ TRANSFER)
  const mirrorExactRows = [
    { tipo: 'VOZ TRANSITO', numA: targetRaw, numB: '6143441900', fecha: '29/05/2022', hora: '20:26:25', dur: 5, imei: imeiSecondary },
    { tipo: 'VOZ TRANSFER', numA: targetRaw, numB: '6141224950', fecha: '04/06/2022', hora: '16:34:57', dur: 2, imei: null },
    { tipo: 'VOZ TRANSFER', numA: '6142160336', numB: targetRaw, fecha: '07/06/2022', hora: '13:55:33', dur: 5, imei: null },
    { tipo: 'VOZ TRANSFER', numA: '6144203670', numB: targetRaw, fecha: '08/06/2022', hora: '13:41:52', dur: 59, imei: null },
    { tipo: 'VOZ TRANSFER', numA: '6144203670', numB: targetRaw, fecha: '08/06/2022', hora: '13:43:53', dur: 2, imei: null },
    { tipo: 'VOZ TRANSFER', numA: '6144203670', numB: targetRaw, fecha: '08/06/2022', hora: '20:06:45', dur: 120, imei: null },
    { tipo: 'VOZ TRANSITO', numA: '6142084090', numB: targetRaw, fecha: '09/06/2022', hora: '19:55:49', dur: 2, imei: null },
    { tipo: 'VOZ TRANSITO', numA: '6142084090', numB: targetRaw, fecha: '09/06/2022', hora: '20:54:09', dur: 82, imei: null },
    { tipo: 'VOZ TRANSITO', numA: '6142084090', numB: targetRaw, fecha: '10/06/2022', hora: '09:35:36', dur: 181, imei: null },
    { tipo: 'VOZ TRANSFER', numA: '6144397899', numB: targetRaw, fecha: '10/06/2022', hora: '14:43:53', dur: 4, imei: null },
    { tipo: 'VOZ TRANSFER', numA: targetRaw, numB: '6141224950', fecha: '12/06/2022', hora: '13:40:46', dur: 11, imei: null },
    { tipo: 'VOZ TRANSFER', numA: targetRaw, numB: '5549603661', fecha: '12/06/2022', hora: '16:51:04', dur: 3, imei: null },
    { tipo: 'VOZ TRANSFER', numA: targetRaw, numB: '5549603784', fecha: '12/06/2022', hora: '17:17:44', dur: 13, imei: null },
    { tipo: 'VOZ TRANSITO', numA: '6142084090', numB: targetRaw, fecha: '14/06/2022', hora: '10:08:11', dur: 1, imei: null },
    { tipo: 'VOZ TRANSFER', numA: '6142160336', numB: targetRaw, fecha: '14/06/2022', hora: '12:33:26', dur: 4, imei: null }
  ];

  mirrorExactRows.forEach(row => {
    const isTransito = row.tipo.includes('TRANSITO');
    const normSrc = `+52${row.numA}`;
    const normDst = `+52${row.numB}`;

    const dtParts = row.fecha.split('/');
    const tmParts = row.hora.split(':');
    const isoDate = new Date(Date.UTC(
      parseInt(dtParts[2], 10),
      parseInt(dtParts[1], 10) - 1,
      parseInt(dtParts[0], 10),
      parseInt(tmParts[0], 10),
      parseInt(tmParts[1], 10),
      parseInt(tmParts[2], 10)
    )).toISOString();

    records.push({
      id: `cdr-${rowId.toString().padStart(5, '0')}`,
      importId: 'imp-chih-001',
      rowNumber: rowId + 1,
      caseId: INITIAL_SYNTHETIC_CASE.id,
      targetPhone: targetNumber,
      sourceNumber: normSrc,
      rawSourceNumber: row.numA,
      destinationNumber: normDst,
      rawDestinationNumber: row.numB,
      timestamp: isoDate,
      rawDate: row.fecha,
      rawTime: row.hora,
      rawTimestamp: `${row.fecha} ${row.hora}`,
      eventType: isTransito ? 'VOZ_TRANSITO' : 'VOZ_TRANSFER',
      rawEventType: row.tipo,
      tipo2: isTransito ? 'Espejo (Tránsito)' : 'Espejo (Transfer)',
      colorTag: isTransito ? 'Naranja' : 'Morado',
      durationSeconds: row.dur,
      rawDuration: String(row.dur),
      imei: row.imei,
      rawImei: row.imei || '-',
      cellId: 'CONMUTADOR_CENTRAL_TRÁNSITO',
      rawCellId: '-',
      operator: 'Telcel México',
      latitude: null,
      longitude: null,
      rawLatitude: '-',
      rawLongitude: '-',
      azimuth: null,
      rawAzimuth: '-',
      sourceFile: 'Sabana_Telcel_Oficio_Chihuahua_6141769216.xlsx',
      status: 'WARNING',
      validationNotes: [
        `Registro Espejo (${row.tipo}): Conmutación de tránsito/transferencia de llamada.`,
        row.imei ? `ALERTA PERICIAL: Detectado IMEI secundario de salto (${row.imei})` : 'Sin IMEI de conmutador'
      ],
      transformations: [
        'Clasificado como Espejo para evitar doble cómputo pericial de duración',
        'Etiqueta Tipo 2 y Color asignados'
      ],
      isDuplicate: false,
      isMirror: true,
      mirrorType: isTransito ? 'TRANSITO' : 'TRANSFER'
    });
    rowId++;
  });

  // 3. Add more realistic calls throughout late May and June to populate analysis
  const additionalContacts = ['6143791925', '6143441900', '6141224950', '6144203670', '6142084090'];
  for (let k = 0; k < 60; k++) {
    const contact = additionalContacts[k % additionalContacts.length];
    const isOutgoing = (k % 2) === 0;
    const isData = (k % 5) === 0;
    const antenna = (k % 3) === 0 ? { lat: antenna1Lat, lng: antenna1Lng, az: 130 } : { lat: antenna2Lat, lng: antenna2Lng, az: 210 };
    const day = 24 + (k % 7);
    const hour = (k * 3) % 24;
    const min = (k * 13) % 60;

    const fechaStr = `${day.toString().padStart(2, '0')}/05/2022`;
    const horaStr = `${hour.toString().padStart(2, '0')}:${min.toString().padStart(2, '0')}:15`;
    const isoDate = new Date(Date.UTC(2022, 4, day, hour, min, 15)).toISOString();

    const tipo = isData ? 'DATOS' : (isOutgoing ? 'VOZ SALIENTE' : 'VOZ ENTRANTE');
    const tipo2 = isData ? 'Internet' : (isOutgoing ? 'LL-S' : 'LL-E');
    const color = isData ? 'Amarillo' : (isOutgoing ? 'Verde' : 'Azul');

    records.push({
      id: `cdr-${rowId.toString().padStart(5, '0')}`,
      importId: 'imp-chih-001',
      rowNumber: rowId + 1,
      caseId: INITIAL_SYNTHETIC_CASE.id,
      targetPhone: targetNumber,
      sourceNumber: isData ? targetNumber : (isOutgoing ? targetNumber : `+52${contact}`),
      rawSourceNumber: isData ? targetRaw : (isOutgoing ? targetRaw : contact),
      destinationNumber: isData ? 'internet.itelcel.com' : (isOutgoing ? `+52${contact}` : targetNumber),
      rawDestinationNumber: isData ? 'internet.itelcel.com' : (isOutgoing ? contact : targetRaw),
      timestamp: isoDate,
      rawDate: fechaStr,
      rawTime: horaStr,
      rawTimestamp: `${fechaStr} ${horaStr}`,
      eventType: isData ? 'DATOS' : (isOutgoing ? 'LLAMADA_SALIENTE' : 'LLAMADA_ENTRANTE'),
      rawEventType: tipo,
      tipo2,
      colorTag: color,
      durationSeconds: isData ? 1800 : (30 + (k * 29) % 360),
      rawDuration: String(isData ? 1800 : (30 + (k * 29) % 360)),
      imei: imeiPrimary,
      rawImei: imeiPrimary,
      cellId: `CEL-CHIH-${antenna.az}°`,
      rawCellId: `CHIH_${antenna.az}`,
      operator: 'Telcel México',
      latitude: antenna.lat,
      longitude: antenna.lng,
      rawLatitude: antenna.az === 130 ? antenna1LatDMS : antenna2LatDMS,
      rawLongitude: antenna.az === 130 ? antenna1LngDMS : antenna2LngDMS,
      azimuth: antenna.az,
      rawAzimuth: `${antenna.az}°`,
      sourceFile: 'Sabana_Telcel_Oficio_Chihuahua_6141769216.xlsx',
      status: 'VALID',
      validationNotes: ['Registro normalizado correctamente conforme a estándar E.164 (+52)'],
      transformations: ['Normalización E.164'],
      isDuplicate: false,
      isMirror: false,
      mirrorType: 'NONE'
    });
    rowId++;
  }

  // 4. Batch for Target 6271218386 (Red de Vínculos UAYC Chihuahua - Image 213aa06d and 64a716d9)
  const targetUayc = '6271218386';
  const targetUaycNorm = '+526271218386';

  const uaycEvents = [
    // Left side contacts
    { other: '6271134588', type: 'LLAMADA_SALIENTE', tipo2: 'LL-S', color: 'Verde', fecha: '22/01/2025', hora: '11:34:45', dur: 120 },
    { other: '6271134588', type: 'LLAMADA_ENTRANTE', tipo2: 'LL-E', color: 'Azul', fecha: '22/01/2025', hora: '11:44:49', dur: 85 },
    { other: '6271134588', type: 'LLAMADA_SALIENTE', tipo2: 'LL-S', color: 'Verde', fecha: '22/01/2025', hora: '11:51:42', dur: 64 },
    { other: '6271134588', type: 'LLAMADA_SALIENTE', tipo2: 'LL-S', color: 'Verde', fecha: '22/01/2025', hora: '12:08:06', dur: 45 },
    { other: '6271134588', type: 'LLAMADA_ENTRANTE', tipo2: 'LL-E', color: 'Azul', fecha: '22/01/2025', hora: '12:10:13', dur: 92 },
    { other: '6271134588', type: 'LLAMADA_SALIENTE', tipo2: 'LL-S', color: 'Verde', fecha: '22/01/2025', hora: '12:14:47', dur: 180 },
    { other: '6271134588', type: 'LLAMADA_ENTRANTE', tipo2: 'LL-E', color: 'Azul', fecha: '22/01/2025', hora: '12:28:27', dur: 70 },
    { other: '6271134588', type: 'LLAMADA_SALIENTE', tipo2: 'LL-S', color: 'Verde', fecha: '22/01/2025', hora: '12:32:56', dur: 55 },
    { other: '6271134588', type: 'SMS_ENTRANTE', tipo2: 'M-E', color: 'Cian', fecha: '22/01/2025', hora: '15:14:40', dur: 0 },
    { other: '6271134588', type: 'LLAMADA_SALIENTE', tipo2: 'LL-S', color: 'Verde', fecha: '23/01/2025', hora: '18:51:20', dur: 140 },
    { other: '6271134588', type: 'LLAMADA_SALIENTE', tipo2: 'LL-S', color: 'Verde', fecha: '24/01/2025', hora: '06:50:10', dur: 38 },
    { other: '6271134588', type: 'LLAMADA_SALIENTE', tipo2: 'LL-S', color: 'Verde', fecha: '25/01/2025', hora: '17:58:30', dur: 90 },
    { other: '6271134588', type: 'LLAMADA_SALIENTE', tipo2: 'LL-S', color: 'Verde', fecha: '25/01/2025', hora: '19:12:37', dur: 210 },
    { other: '6271134588', type: 'LLAMADA_SALIENTE', tipo2: 'LL-S', color: 'Verde', fecha: '25/01/2025', hora: '21:54:17', dur: 45 },
    { other: '6271134588', type: 'LLAMADA_SALIENTE', tipo2: 'LL-S', color: 'Verde', fecha: '26/01/2025', hora: '07:31:45', dur: 12 },
    { other: '6271134588', type: 'LLAMADA_SALIENTE', tipo2: 'LL-S', color: 'Verde', fecha: '27/01/2025', hora: '19:24:38', dur: 34 },
    { other: '6271134588', type: 'LLAMADA_ENTRANTE', tipo2: 'LL-E', color: 'Azul', fecha: '29/01/2025', hora: '18:08:22', dur: 60 },
    { other: '6271134588', type: 'SMS_ENTRANTE', tipo2: 'M-E', color: 'Cian', fecha: '29/01/2025', hora: '21:34:05', dur: 0 },
    { other: '6271134588', type: 'LLAMADA_SALIENTE', tipo2: 'LL-S', color: 'Verde', fecha: '29/01/2025', hora: '21:43:15', dur: 110 },
    { other: '6271134588', type: 'LLAMADA_ENTRANTE', tipo2: 'LL-E', color: 'Azul', fecha: '31/01/2025', hora: '21:21:25', dur: 75 },

    // Contact 6271474227
    { other: '6271474227', type: 'LLAMADA_SALIENTE', tipo2: 'LL-S', color: 'Verde', fecha: '26/01/2025', hora: '15:11:37', dur: 40 },
    { other: '6271474227', type: 'LLAMADA_ENTRANTE', tipo2: 'LL-E', color: 'Azul', fecha: '29/01/2025', hora: '18:34:49', dur: 95 },
    { other: '6271474227', type: 'LLAMADA_ENTRANTE', tipo2: 'LL-E', color: 'Azul', fecha: '29/01/2025', hora: '19:54:20', dur: 15 },

    // Contact 6271449752
    { other: '6271449752', type: 'LLAMADA_ENTRANTE', tipo2: 'LL-E', color: 'Azul', fecha: '22/01/2025', hora: '01:06:51', dur: 120 },
    { other: '6271449752', type: 'LLAMADA_SALIENTE', tipo2: 'LL-S', color: 'Verde', fecha: '29/01/2025', hora: '19:35:15', dur: 60 },
    { other: '6271449752', type: 'LLAMADA_ENTRANTE', tipo2: 'LL-E', color: 'Azul', fecha: '30/01/2025', hora: '05:49:18', dur: 80 },
    { other: '6271449752', type: 'LLAMADA_SALIENTE', tipo2: 'LL-S', color: 'Verde', fecha: '30/01/2025', hora: '05:50:47', dur: 15 },

    // Single outgoings
    { other: '6271148264', type: 'LLAMADA_SALIENTE', tipo2: 'LL-S', color: 'Verde', fecha: '24/01/2025', hora: '06:17:17', dur: 50 },
    { other: '6271231031', type: 'LLAMADA_SALIENTE', tipo2: 'LL-S', color: 'Verde', fecha: '26/01/2025', hora: '16:53:38', dur: 110 },
    { other: '6271030501', type: 'LLAMADA_SALIENTE', tipo2: 'LL-S', color: 'Verde', fecha: '24/01/2025', hora: '16:51:13', dur: 75 },
    { other: '6271430295', type: 'LLAMADA_SALIENTE', tipo2: 'LL-S', color: 'Verde', fecha: '23/01/2025', hora: '19:08:24', dur: 30 },

    // Right side contacts & services
    { other: '6565901978', type: 'LLAMADA_ENTRANTE', tipo2: 'LL-E', color: 'Azul', fecha: '27/01/2025', hora: '11:26:20', dur: 45 },
    { other: '142323', type: 'SMS_ENTRANTE', tipo2: 'M-E', color: 'Cian', fecha: '22/01/2025', hora: '08:18:11', dur: 0 },
    { other: '142323', type: 'SMS_ENTRANTE', tipo2: 'M-E', color: 'Cian', fecha: '22/01/2025', hora: '18:49:20', dur: 0 },
    { other: 'Telcel', type: 'SMS_ENTRANTE', tipo2: 'M-E', color: 'Cian', fecha: '22/01/2025', hora: '10:02:34', dur: 0 },
    { other: 'Telcel', type: 'SMS_ENTRANTE', tipo2: 'M-E', color: 'Cian', fecha: '22/01/2025', hora: '10:02:38', dur: 0 },
    { other: 'UNOTV.COM', type: 'SMS_ENTRANTE', tipo2: 'M-E', color: 'Cian', fecha: '22/01/2025', hora: '18:51:24', dur: 0 },
    { other: 'UNOTV.COM', type: 'SMS_ENTRANTE', tipo2: 'M-E', color: 'Cian', fecha: '22/01/2025', hora: '20:42:32', dur: 0 },
    { other: '6271130597', type: 'LLAMADA_ENTRANTE', tipo2: 'LL-E', color: 'Azul', fecha: '22/01/2025', hora: '19:56:17', dur: 85 },
    { other: '6271130597', type: 'LLAMADA_ENTRANTE', tipo2: 'LL-E', color: 'Azul', fecha: '25/01/2025', hora: '20:55:11', dur: 40 },
    { other: 'BUZON', type: 'SMS_ENTRANTE', tipo2: 'M-E', color: 'Cian', fecha: '22/01/2025', hora: '15:14:45', dur: 0 },
    { other: 'TELCEL', type: 'SMS_ENTRANTE', tipo2: 'M-E', color: 'Cian', fecha: '26/01/2025', hora: '16:55:21', dur: 0 },
    { other: '6271181113', type: 'LLAMADA_ENTRANTE', tipo2: 'LL-E', color: 'Azul', fecha: '23/01/2025', hora: '17:55:48', dur: 95 },
    { other: '6271331238', type: 'LLAMADA_ENTRANTE', tipo2: 'LL-E', color: 'Azul', fecha: '22/01/2025', hora: '19:22:47', dur: 60 },
    { other: '6271331238', type: 'LLAMADA_ENTRANTE', tipo2: 'LL-E', color: 'Azul', fecha: '22/01/2025', hora: '19:43:42', dur: 35 },
    { other: '47288', type: 'SMS_ENTRANTE', tipo2: 'M-E', color: 'Cian', fecha: '22/01/2025', hora: '11:36:42', dur: 0 }
  ];

  uaycEvents.forEach(ev => {
    const isOutgoing = ev.type === 'LLAMADA_SALIENTE' || ev.type === 'SMS_SALIENTE';
    const numA = isOutgoing ? targetUayc : ev.other;
    const numB = isOutgoing ? ev.other : targetUayc;
    const normA = isOutgoing ? targetUaycNorm : (ev.other.startsWith('627') ? `+52${ev.other}` : ev.other);
    const normB = isOutgoing ? (ev.other.startsWith('627') ? `+52${ev.other}` : ev.other) : targetUaycNorm;

    const dtParts = ev.fecha.split('/');
    const tmParts = ev.hora.split(':');
    const isoDate = new Date(Date.UTC(
      parseInt(dtParts[2], 10),
      parseInt(dtParts[1], 10) - 1,
      parseInt(dtParts[0], 10),
      parseInt(tmParts[0], 10),
      parseInt(tmParts[1], 10),
      parseInt(tmParts[2], 10)
    )).toISOString();

    records.push({
      id: `cdr-${rowId.toString().padStart(5, '0')}`,
      importId: 'imp-uayc-002',
      rowNumber: rowId + 1,
      caseId: INITIAL_SYNTHETIC_CASE.id,
      targetPhone: targetUaycNorm,
      sourceNumber: normA,
      rawSourceNumber: numA,
      destinationNumber: normB,
      rawDestinationNumber: numB,
      timestamp: isoDate,
      rawDate: ev.fecha,
      rawTime: ev.hora,
      rawTimestamp: `${ev.fecha} ${ev.hora}`,
      eventType: ev.type as any,
      rawEventType: ev.type.replace('_', ' '),
      tipo2: ev.tipo2,
      colorTag: ev.color,
      durationSeconds: ev.dur,
      rawDuration: String(ev.dur),
      imei: '351813091633410',
      rawImei: '351813091633410',
      cellId: 'CEL-PARRAL-1',
      rawCellId: 'PARRAL_CENTRO',
      operator: 'Telcel México',
      latitude: 26.9328,
      longitude: -105.6667,
      rawLatitude: '26°55\'58"N',
      rawLongitude: '105°40\'0"W',
      azimuth: 180,
      rawAzimuth: '180°',
      sourceFile: 'Sabana_Telcel_Parral_6271218386.xlsx',
      status: 'VALID',
      validationNotes: ['Registro procesado y verificado conforme a Oficio UAYC'],
      transformations: ['Normalización E.164'],
      isDuplicate: false,
      isMirror: false,
      mirrorType: 'NONE'
    });
    rowId++;
  });

  // Data sessions matching Image 2
  const dataSessions = [
    { fecha: '22/01/2025', hora: '09:30:05', dur: 3 },
    { fecha: '22/01/2025', hora: '09:45:14', dur: 3600 },
    { fecha: '22/01/2025', hora: '10:45:14', dur: 3601 },
    { fecha: '22/01/2025', hora: '11:45:15', dur: 3563 },
    { fecha: '22/01/2025', hora: '12:53:58', dur: 3600 },
    { fecha: '22/01/2025', hora: '13:53:58', dur: 4817 },
    { fecha: '22/01/2025', hora: '15:14:19', dur: 47 },
    { fecha: '22/01/2025', hora: '18:49:05', dur: 59 },
    { fecha: '23/01/2025', hora: '23:31:50', dur: 3600 },
    { fecha: '24/01/2025', hora: '00:31:50', dur: 3600 },
    { fecha: '24/01/2025', hora: '01:31:50', dur: 3600 },
    { fecha: '24/01/2025', hora: '02:31:50', dur: 7201 },
    { fecha: '24/01/2025', hora: '04:31:51', dur: 3600 },
    { fecha: '24/01/2025', hora: '05:31:51', dur: 3600 },
    { fecha: '24/01/2025', hora: '06:31:51', dur: 3600 },
    { fecha: '24/01/2025', hora: '07:31:51', dur: 3600 },
    { fecha: '24/01/2025', hora: '08:31:51', dur: 3600 },
    { fecha: '24/01/2025', hora: '09:31:51', dur: 3600 },
    { fecha: '24/01/2025', hora: '10:31:51', dur: 2357 },
    { fecha: '24/01/2025', hora: '14:56:14', dur: 3600 },
    { fecha: '24/01/2025', hora: '15:56:14', dur: 3600 },
    { fecha: '24/01/2025', hora: '16:56:14', dur: 3600 },
    { fecha: '24/01/2025', hora: '17:56:14', dur: 3600 },
    { fecha: '24/01/2025', hora: '18:56:14', dur: 3600 },
    { fecha: '24/01/2025', hora: '19:56:14', dur: 3600 },
    { fecha: '24/01/2025', hora: '20:56:14', dur: 2784 },
    { fecha: '25/01/2025', hora: '17:42:00', dur: 1426 },
    { fecha: '25/01/2025', hora: '18:37:27', dur: 107 }
  ];

  dataSessions.forEach(ds => {
    const dtParts = ds.fecha.split('/');
    const tmParts = ds.hora.split(':');
    const isoDate = new Date(Date.UTC(
      parseInt(dtParts[2], 10),
      parseInt(dtParts[1], 10) - 1,
      parseInt(dtParts[0], 10),
      parseInt(tmParts[0], 10),
      parseInt(tmParts[1], 10),
      parseInt(tmParts[2], 10)
    )).toISOString();

    records.push({
      id: `cdr-${rowId.toString().padStart(5, '0')}`,
      importId: 'imp-uayc-002',
      rowNumber: rowId + 1,
      caseId: INITIAL_SYNTHETIC_CASE.id,
      targetPhone: targetUaycNorm,
      sourceNumber: targetUaycNorm,
      rawSourceNumber: targetUayc,
      destinationNumber: 'internet.itelcel.com',
      rawDestinationNumber: 'internet.itelcel.com',
      timestamp: isoDate,
      rawDate: ds.fecha,
      rawTime: ds.hora,
      rawTimestamp: `${ds.fecha} ${ds.hora}`,
      eventType: 'DATOS',
      rawEventType: 'DATOS',
      tipo2: 'Internet',
      colorTag: 'Amarillo',
      durationSeconds: ds.dur,
      rawDuration: String(ds.dur),
      imei: '351813091633410',
      rawImei: '351813091633410',
      cellId: 'CEL-PARRAL-DATA',
      rawCellId: 'PARRAL_DATOS',
      operator: 'Telcel México',
      latitude: 26.9328,
      longitude: -105.6667,
      rawLatitude: '26°55\'58"N',
      rawLongitude: '105°40\'0"W',
      azimuth: 180,
      rawAzimuth: '180°',
      sourceFile: 'Sabana_Telcel_Parral_6271218386.xlsx',
      status: 'VALID',
      validationNotes: ['Sesión de datos IP móvil APN'],
      transformations: ['Normalización'],
      isDuplicate: false,
      isMirror: false,
      mirrorType: 'NONE'
    });
    rowId++;
  });

  const report: ImportValidationReport = {
    importId: 'imp-chih-001',
    caseId: INITIAL_SYNTHETIC_CASE.id,
    filename: 'Sabana_Telcel_Oficio_Chihuahua_6141769216.xlsx',
    fileHashSha256: '5d9b9302e1286c47bf7918a3627d3b0e1a89c426f432ea3212670b69b526f81a',
    fileSizeBytes: 312480,
    totalRows: records.length,
    validCount: records.filter(r => r.status === 'VALID').length,
    rejectedCount: 0,
    incompleteCount: records.filter(r => r.latitude === null).length,
    duplicateCount: 0,
    mirrorCount: records.filter(r => r.isMirror).length,
    dataCount: records.filter(r => r.eventType === 'DATOS').length,
    voiceCount: records.filter(r => r.eventType.startsWith('LLAMADA') || r.isMirror).length,
    operatorDetected: 'Telcel México (Radiomóvil Dipsa S.A. de C.V.)',
    countryPrefix: '+52',
    timezone: 'America/Chihuahua (UTC-6 / CST)',
    importedAt: new Date().toISOString(),
    detectedTargets: [targetNumber],
    rejectionReasons: {}
  };

  return { records, report };
}

export function generateSampleCsvContent(): string {
  const header = 'Teléfono,Tipo,Número A,Número B,Fecha,Hora,Duracion,IMEI,LATITUD,LONGITUD,Azimuth\n';
  const rows = [
    '6141769216,VOZ ENTRANTE,4535348400,6141769216,22/05/2022,13:21:00,619,351813091633410,28°46\'52"N,106°10\'8"W,130°',
    '6141769216,DATOS,6141769216,internet.itelcel.com,22/05/2022,22:43:14,491,351813091633410,28°46\'52"N,106°10\'8"W,130°',
    '6141769216,DATOS,6141769216,internet.itelcel.com,23/05/2022,02:12:23,257,351813091633410,28°47\'15"N,106°9\'53"W,210°',
    '6141769216,VOZ ENTRANTE,6143791925,6141769216,23/05/2022,07:16:55,241,351813091633410,28°47\'15"N,106°9\'53"W,210°',
    '6141769216,VOZ SALIENTE,6143791925,6141769216,23/05/2022,08:16:39,240,-,-,-,-',
    '6141769216,DATOS,6141769216,internet.itelcel.com,23/05/2022,08:42:22,7200,351813091633410,28°47\'15"N,106°9\'53"W,210°',
    '6141769216,VOZ TRANSITO,6141769216,6143441900,29/05/2022,20:26:25,5,865746050686190,-,-,-',
    '6141769216,VOZ TRANSFER,6141769216,6141224950,04/06/2022,16:34:57,2,-,-,-,-',
    '6141769216,VOZ TRANSFER,6142160336,6141769216,07/06/2022,13:55:33,5,-,-,-,-',
    '6141769216,VOZ TRANSFER,6144203670,6141769216,08/06/2022,13:41:52,59,-,-,-,-'
  ];
  return header + rows.join('\n');
}
