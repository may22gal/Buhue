import { NormalizedCDR, AnalysisFilterState, FrequentContact, CellTowerSummary } from '../types';

export function filterCDRRecords(
  records: NormalizedCDR[],
  filters: AnalysisFilterState,
  includeWarnings: boolean = true
): NormalizedCDR[] {
  return records.filter(record => {
    // Exclude rejected records from judicial calculations
    if (record.status === 'REJECTED') return false;
    if (!includeWarnings && record.status === 'WARNING' && !record.isMirror) return false;

    // Espejos filter (crucial to avoid counting transit legs twice)
    if (filters.mirrorFilter === 'EXCLUDE_MIRRORS' && record.isMirror) {
      return false;
    }
    if (filters.mirrorFilter === 'ONLY_MIRRORS' && !record.isMirror) {
      return false;
    }

    // Target number filter (either targetPhone, source or destination)
    if (filters.targetNumber) {
      const matchTarget = record.targetPhone === filters.targetNumber;
      const isSource = record.sourceNumber === filters.targetNumber;
      const isDest = record.destinationNumber === filters.targetNumber;
      if (!matchTarget && !isSource && !isDest) return false;
    }

    // Specific counterpart contact filter
    if (filters.selectedContact) {
      const matchSrc = record.sourceNumber === filters.selectedContact;
      const matchDst = record.destinationNumber === filters.selectedContact;
      if (!matchSrc && !matchDst) return false;
    }

    // Direction filter relative to targetNumber
    if (filters.targetNumber && filters.direction !== 'TODOS') {
      const isOutgoing = record.sourceNumber === filters.targetNumber;
      if (filters.direction === 'SALIENTE' && !isOutgoing) return false;
      if (filters.direction === 'ENTRANTE' && isOutgoing) return false;
    }

    // Event type filter
    if (filters.eventType === 'LLAMADAS') {
      if (!record.eventType.startsWith('LLAMADA') && !record.isMirror) return false;
    } else if (filters.eventType === 'SMS') {
      if (!record.eventType.startsWith('SMS')) return false;
    } else if (filters.eventType === 'DATOS') {
      if (record.eventType !== 'DATOS') return false;
    } else if (filters.eventType === 'ESPEJOS') {
      if (!record.isMirror) return false;
    }

    // IMEI filter
    if (filters.imeiFilter && filters.imeiFilter !== 'TODOS') {
      if (record.imei !== filters.imeiFilter) return false;
    }

    // Date range filter
    const recDate = new Date(record.timestamp);
    if (filters.startDate) {
      const start = new Date(filters.startDate);
      if (recDate < start) return false;
    }
    if (filters.endDate) {
      const end = new Date(filters.endDate);
      end.setHours(23, 59, 59, 999);
      if (recDate > end) return false;
    }

    // Hourly window filter (e.g. nocturnal 22:00 to 06:00)
    const hour = recDate.getUTCHours(); // or local
    if (filters.startHour <= filters.endHour) {
      if (hour < filters.startHour || hour > filters.endHour) return false;
    } else {
      if (hour < filters.startHour && hour > filters.endHour) return false;
    }

    // Operator filter
    if (filters.operator && filters.operator !== 'TODOS') {
      if (record.operator !== filters.operator) return false;
    }

    // Cell ID filter
    if (filters.cellId && filters.cellId !== 'TODAS') {
      if (record.cellId !== filters.cellId) return false;
    }

    // Min duration filter
    if (filters.minDuration > 0) {
      if (record.durationSeconds < filters.minDuration) return false;
    }

    // Generic search term
    if (filters.searchTerm) {
      const term = filters.searchTerm.toLowerCase();
      const match =
        record.sourceNumber.toLowerCase().includes(term) ||
        record.destinationNumber.toLowerCase().includes(term) ||
        record.cellId.toLowerCase().includes(term) ||
        record.operator.toLowerCase().includes(term) ||
        (record.imei && record.imei.toLowerCase().includes(term)) ||
        (record.tipo2 && record.tipo2.toLowerCase().includes(term));
      if (!match) return false;
    }

    return true;
  });
}

export function computeFrequentContacts(
  records: NormalizedCDR[],
  targetNumber: string,
  phoneTags?: Record<string, import('../types').PhoneTag>
): FrequentContact[] {
  const map = new Map<string, {
    totalEvents: number;
    callCount: number;
    smsCount: number;
    dataCount: number;
    totalDurationSeconds: number;
    incomingCount: number;
    outgoingCount: number;
    firstEvent: string;
    lastEvent: string;
    associatedCells: Set<string>;
    associatedImeis: Set<string>;
  }>();

  for (const r of records) {
    if (r.status === 'REJECTED') continue;

    // Do not count internet APN packets as person contacts unless inspected
    let counterpart = '';
    let isIncoming = false;

    if (targetNumber) {
      if (r.sourceNumber === targetNumber) {
        counterpart = r.destinationNumber;
        isIncoming = false;
      } else if (r.destinationNumber === targetNumber) {
        counterpart = r.sourceNumber;
        isIncoming = true;
      } else {
        counterpart = r.destinationNumber;
        isIncoming = false;
      }
    } else {
      counterpart = r.destinationNumber;
      isIncoming = false;
    }

    if (!counterpart) continue;

    const existing = map.get(counterpart) || {
      totalEvents: 0,
      callCount: 0,
      smsCount: 0,
      dataCount: 0,
      totalDurationSeconds: 0,
      incomingCount: 0,
      outgoingCount: 0,
      firstEvent: r.timestamp,
      lastEvent: r.timestamp,
      associatedCells: new Set<string>(),
      associatedImeis: new Set<string>()
    };

    existing.totalEvents += 1;
    if (r.eventType === 'DATOS') {
      existing.dataCount += 1;
    } else if (r.eventType.startsWith('LLAMADA') || r.isMirror) {
      existing.callCount += 1;
      existing.totalDurationSeconds += r.durationSeconds;
    } else if (r.eventType.startsWith('SMS')) {
      existing.smsCount += 1;
    }

    if (isIncoming) {
      existing.incomingCount += 1;
    } else {
      existing.outgoingCount += 1;
    }

    if (r.cellId && r.cellId !== 'SIN_CELDA') {
      existing.associatedCells.add(r.cellId);
    }
    if (r.imei) {
      existing.associatedImeis.add(r.imei);
    }

    if (new Date(r.timestamp) < new Date(existing.firstEvent)) {
      existing.firstEvent = r.timestamp;
    }
    if (new Date(r.timestamp) > new Date(existing.lastEvent)) {
      existing.lastEvent = r.timestamp;
    }

    map.set(counterpart, existing);
  }

  const result: FrequentContact[] = [];
  map.forEach((val, num) => {
    // Find matching tag if any
    const rawClean = num.replace(/[^0-9]/g, '');
    let tag = phoneTags?.[num] || phoneTags?.[rawClean];
    if (!tag && phoneTags) {
      // Try suffix 10-digit match e.g. 6271134588
      const short10 = rawClean.slice(-10);
      tag = phoneTags[short10];
    }

    result.push({
      phoneNumber: num,
      normalizedNumber: num,
      totalEvents: val.totalEvents,
      callCount: val.callCount,
      smsCount: val.smsCount,
      dataCount: val.dataCount,
      totalDurationSeconds: val.totalDurationSeconds,
      incomingCount: val.incomingCount,
      outgoingCount: val.outgoingCount,
      firstEvent: val.firstEvent,
      lastEvent: val.lastEvent,
      associatedCells: Array.from(val.associatedCells),
      associatedImeis: Array.from(val.associatedImeis),
      alias: tag?.alias,
      category: tag?.category
    });
  });

  return result.sort((a, b) => b.totalEvents - a.totalEvents);
}

export function computeCellTowerSummaries(records: NormalizedCDR[]): CellTowerSummary[] {
  const map = new Map<string, {
    operator: string;
    latitude: number;
    longitude: number;
    azimuth: number | null;
    totalEvents: number;
    firstSeen: string;
    lastSeen: string;
    contacts: Set<string>;
    incomingCount: number;
    outgoingCount: number;
    dataCount: number;
    events: NormalizedCDR[];
  }>();

  for (const r of records) {
    if (r.status === 'REJECTED' || r.latitude === null || r.longitude === null) continue;

    const key = r.cellId || `${r.latitude.toFixed(4)},${r.longitude.toFixed(4)}`;
    const existing = map.get(key) || {
      operator: r.operator,
      latitude: r.latitude,
      longitude: r.longitude,
      azimuth: r.azimuth,
      totalEvents: 0,
      firstSeen: r.timestamp,
      lastSeen: r.timestamp,
      contacts: new Set<string>(),
      incomingCount: 0,
      outgoingCount: 0,
      dataCount: 0,
      events: []
    };

    existing.totalEvents += 1;
    existing.events.push(r);
    existing.contacts.add(r.sourceNumber);
    existing.contacts.add(r.destinationNumber);

    if (r.eventType === 'DATOS') existing.dataCount += 1;
    else if (r.eventType.includes('ENTRANTE')) existing.incomingCount += 1;
    else existing.outgoingCount += 1;

    if (new Date(r.timestamp) < new Date(existing.firstSeen)) existing.firstSeen = r.timestamp;
    if (new Date(r.timestamp) > new Date(existing.lastSeen)) existing.lastSeen = r.timestamp;

    map.set(key, existing);
  }

  const list: CellTowerSummary[] = [];
  map.forEach((val, cellId) => {
    list.push({
      cellId,
      operator: val.operator,
      latitude: val.latitude,
      longitude: val.longitude,
      azimuth: val.azimuth,
      totalEvents: val.totalEvents,
      firstSeen: val.firstSeen,
      lastSeen: val.lastSeen,
      uniqueContacts: val.contacts.size,
      incomingCount: val.incomingCount,
      outgoingCount: val.outgoingCount,
      dataCount: val.dataCount,
      events: val.events
    });
  });

  return list.sort((a, b) => b.totalEvents - a.totalEvents);
}

export function findLastRecordedAntenna(records: NormalizedCDR[]): {
  cellId: string;
  latitude: number | null;
  longitude: number | null;
  azimuth: number | null;
  operator: string;
  timestamp: string;
  event: NormalizedCDR | null;
} | null {
  const validWithCoords = records.filter(r => r.status !== 'REJECTED' && r.latitude !== null && r.longitude !== null);
  if (validWithCoords.length === 0) return null;

  const sorted = [...validWithCoords].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  const latest = sorted[0];

  return {
    cellId: latest.cellId,
    latitude: latest.latitude,
    longitude: latest.longitude,
    azimuth: latest.azimuth,
    operator: latest.operator,
    timestamp: latest.timestamp,
    event: latest
  };
}
