import React, { useState, useEffect } from 'react';
import { Navbar } from './components/layout/Navbar';
import { Sidebar, NavTab } from './components/layout/Sidebar';
import { DashboardView } from './components/dashboard/DashboardView';
import { CasesView } from './components/cases/CasesView';
import { ImportView } from './components/import/ImportView';
import { RecordExplorerView } from './components/explorer/RecordExplorerView';
import { NumberAnalysisView } from './components/analysis/NumberAnalysisView';
import { NetworkLinkDiagramView } from './components/network/NetworkLinkDiagramView';
import { AntennaMapView } from './components/map/AntennaMapView';
import { ReportGeneratorView } from './components/reports/ReportGeneratorView';
import { IntegrationsView } from './components/integrations/IntegrationsView';
import { AuditView } from './components/audit/AuditView';
import { 
  ProsecutionCase, 
  NormalizedCDR, 
  ImportValidationReport, 
  UserProfile,
  PhoneTag
} from './types';
import { 
  INITIAL_SYNTHETIC_CASE, 
  generateSyntheticCDRs 
} from './services/sampleData';
import { logAuditEvent } from './services/auditService';
import { testConnection } from './firebase';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  
  // User profile with initial administrator role (User email from environment)
  const [currentUser, setCurrentUser] = useState<UserProfile>({
    uid: 'user-fiscal-01',
    email: 't3st3r.4pp5@gmail.com',
    displayName: 'Dr. Valenzuela / Analista Pericial',
    role: 'admin',
    department: 'Unidad Fiscal Especializada en Delitos Complejos',
    createdAt: new Date().toISOString()
  });

  // Judicial cases
  const [cases, setCases] = useState<ProsecutionCase[]>([INITIAL_SYNTHETIC_CASE]);
  const [currentCase, setCurrentCase] = useState<ProsecutionCase>(INITIAL_SYNTHETIC_CASE);

  // In-memory CDR records and active import report
  const [records, setRecords] = useState<NormalizedCDR[]>([]);
  const [report, setReport] = useState<ImportValidationReport | null>(null);

  // On first mount: test Firestore connection and load synthetic demo dataset for immediate usability
  useEffect(() => {
    testConnection().catch(console.error);

    // Bootstrap with realistic synthetic dataset for immediate demonstration
    const { records: demoRecords, report: demoReport } = generateSyntheticCDRs();
    setRecords(demoRecords);
    setReport(demoReport);

    logAuditEvent(
      'LOGIN',
      'Acceso inicial a la plataforma forense de análisis de comunicaciones',
      currentUser.email,
      currentUser.uid,
      INITIAL_SYNTHETIC_CASE.id
    );
  }, []);

  const handleLoadSyntheticData = () => {
    const { records: demoRecords, report: demoReport } = generateSyntheticCDRs();
    setRecords(demoRecords);
    setReport(demoReport);
    logAuditEvent(
      'FILE_IMPORT',
      'Carga manual de dataset pericial sintético para pruebas de laboratorio forense',
      currentUser.email,
      currentUser.uid,
      currentCase.id
    );
  };

  const handleImportComplete = (newRecords: NormalizedCDR[], newReport: ImportValidationReport) => {
    setRecords(newRecords);
    setReport(newReport);
    
    // Update target numbers in current case if new targets were detected
    if (newReport.detectedTargets.length > 0) {
      const updatedCase: ProsecutionCase = {
        ...currentCase,
        targetNumbers: Array.from(new Set([...currentCase.targetNumbers, ...newReport.detectedTargets]))
      };
      setCurrentCase(updatedCase);
      setCases(cases.map(c => c.id === updatedCase.id ? updatedCase : c));
    }

    setActiveTab('explorer');
  };

  const handleAddCase = (newCase: ProsecutionCase) => {
    setCases([newCase, ...cases]);
    setCurrentCase(newCase);
  };

  const handleSavePhoneTag = (tag: PhoneTag) => {
    const cleanKey = tag.phoneNumber.replace(/[^0-9]/g, '').slice(-10) || tag.phoneNumber;
    const currentTags = currentCase.phoneTags || {};
    const updatedTags = {
      ...currentTags,
      [cleanKey]: tag,
      [tag.phoneNumber]: tag
    };
    const updatedCase: ProsecutionCase = {
      ...currentCase,
      phoneTags: updatedTags,
      updatedAt: new Date().toISOString()
    };
    setCurrentCase(updatedCase);
    setCases(prevCases => prevCases.map(c => c.id === updatedCase.id ? updatedCase : c));
  };

  const handleDeletePhoneTag = (phoneNumber: string) => {
    const cleanKey = phoneNumber.replace(/[^0-9]/g, '').slice(-10) || phoneNumber;
    const currentTags = { ...(currentCase.phoneTags || {}) };
    delete currentTags[phoneNumber];
    delete currentTags[cleanKey];
    const updatedCase: ProsecutionCase = {
      ...currentCase,
      phoneTags: currentTags,
      updatedAt: new Date().toISOString()
    };
    setCurrentCase(updatedCase);
    setCases(prevCases => prevCases.map(c => c.id === updatedCase.id ? updatedCase : c));
  };

  const handleChangeRole = (role: 'admin' | 'analista' | 'consulta') => {
    setCurrentUser(prev => ({ ...prev, role }));
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Top Institutional Header */}
      <Navbar
        currentCase={currentCase}
        cases={cases}
        onSelectCase={setCurrentCase}
        currentUser={currentUser}
        onChangeRole={handleChangeRole}
        onRefreshData={() => {
          testConnection();
        }}
      />

      <div className="flex flex-1 overflow-hidden">
        {/* Navigation Sidebar */}
        <Sidebar
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          recordCount={records.length}
          caseCount={cases.length}
        />

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 bg-slate-950/60">
          {activeTab === 'dashboard' && (
            <DashboardView
              currentCase={currentCase}
              records={records}
              report={report}
              onNavigate={setActiveTab}
              onLoadSyntheticData={handleLoadSyntheticData}
            />
          )}

          {activeTab === 'cases' && (
            <CasesView
              cases={cases}
              currentCase={currentCase}
              onSelectCase={setCurrentCase}
              onAddCase={handleAddCase}
              currentUser={currentUser}
            />
          )}

          {activeTab === 'import' && (
            <ImportView
              currentCase={currentCase}
              onImportComplete={handleImportComplete}
              currentUser={currentUser}
            />
          )}

          {activeTab === 'explorer' && (
            <RecordExplorerView
              records={records}
              currentUser={currentUser}
              phoneTags={currentCase.phoneTags}
            />
          )}

          {activeTab === 'analysis' && (
            <NumberAnalysisView
              records={records}
              targetNumbers={currentCase.targetNumbers}
              currentUser={currentUser}
              phoneTags={currentCase.phoneTags}
              onSavePhoneTag={handleSavePhoneTag}
              onDeletePhoneTag={handleDeletePhoneTag}
            />
          )}

          {activeTab === 'network' && (
            <NetworkLinkDiagramView
              records={records}
              currentUser={currentUser}
              targetNumberProp={currentCase.targetNumbers[0] || '6271218386'}
              phoneTags={currentCase.phoneTags}
            />
          )}

          {activeTab === 'map' && (
            <AntennaMapView
              records={records}
            />
          )}

          {activeTab === 'reports' && (
            <ReportGeneratorView
              currentCase={currentCase}
              records={records}
              report={report}
              currentUser={currentUser}
              phoneTags={currentCase.phoneTags}
            />
          )}

          {activeTab === 'integrations' && (
            <IntegrationsView
              currentUser={currentUser}
            />
          )}

          {activeTab === 'audit' && (
            <AuditView
              currentUser={currentUser}
              report={report}
            />
          )}
        </main>
      </div>
    </div>
  );
}
